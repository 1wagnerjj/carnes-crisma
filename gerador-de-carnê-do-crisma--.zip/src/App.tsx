import React, { useState, useRef, useEffect } from 'react';
import { CarneConfig, DEFAULT_CONFIG, SavedCarneCopy } from './types';
import { CarnePage } from './components/CarnePage';
import { SingleTicketPreview } from './components/SingleTicketPreview';
import { CapelaBannerPreview } from './components/CapelaBannerPreview';
import { CarneCoverViewer } from './components/CarneCoverViewer';
import { IniciacaoCristaPreview } from './components/IniciacaoCristaPreview';
import { SavedCopiesModal } from './components/SavedCopiesModal';
import { ReligiousEmblem, EMBLEM_OPTIONS } from './components/ReligiousEmblem';
import { downloadEditableHtml } from './utils/exportEditableHtml';
import {
  downloadElementAsImage,
  downloadPagesAsPdf,
  downloadPagesAsZip,
} from './utils/exportImage';
import {
  Printer,
  Download,
  Settings2,
  ChevronLeft,
  ChevronRight,
  Eye,
  Layers,
  Sparkles,
  FileText,
  CreditCard,
  QrCode,
  RotateCcw,
  CheckCircle2,
  Flame,
  BookOpen,
  FileDown,
  FolderArchive,
  Loader2,
  AlertCircle,
  X,
  Copy,
  FileCode,
} from 'lucide-react';

const STORAGE_KEY = 'carne_saved_copies_v2';

function getInitialCopies(): { copies: SavedCarneCopy[]; activeId: string } {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return { copies: parsed, activeId: parsed[0].id };
      }
    }
  } catch (e) {
    console.error('Falha ao ler cópias salvas:', e);
  }
  const defaultCopy: SavedCarneCopy = {
    id: 'copy_default_crisma',
    name: 'Cópia 1 - Padrão Crisma (200 Carnês)',
    createdAt: Date.now(),
    updatedAt: Date.now(),
    config: DEFAULT_CONFIG,
  };
  return { copies: [defaultCopy], activeId: defaultCopy.id };
}

export default function App() {
  const [initialData] = useState(() => getInitialCopies());
  const [savedCopies, setSavedCopies] = useState<SavedCarneCopy[]>(initialData.copies);
  const [activeCopyId, setActiveCopyId] = useState<string>(initialData.activeId);
  const [isCopiesModalOpen, setIsCopiesModalOpen] = useState<boolean>(false);

  const activeCopy = savedCopies.find((c) => c.id === activeCopyId) || savedCopies[0];
  const [config, setConfigState] = useState<CarneConfig>(activeCopy?.config || DEFAULT_CONFIG);

  const setConfig = (newConfig: CarneConfig) => {
    setConfigState(newConfig);
    setSavedCopies((prev) => {
      const updated = prev.map((c) =>
        c.id === activeCopyId ? { ...c, config: newConfig, updatedAt: Date.now() } : c
      );
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      } catch (err) {
        console.error(err);
      }
      return updated;
    });
  };

  const handleSelectCopy = (newConfig: CarneConfig, copyName: string) => {
    setConfigState(newConfig);
    showToast(`Cópia "${copyName}" ativada!`);
  };

  const [currentPage, setCurrentPage] = useState<number>(1);
  const [currentSingleNumber, setCurrentSingleNumber] = useState<number>(1);
  const [activeTab, setActiveTab] = useState<'sheet' | 'all' | 'single' | 'banner' | 'icone'>('sheet');
  const [showSettings, setShowSettings] = useState<boolean>(false);
  const [isExportingPage, setIsExportingPage] = useState<boolean>(false);

  // Batch Export Progress Modal State
  const [exportModal, setExportModal] = useState<{
    isOpen: boolean;
    current: number;
    total: number;
    statusText: string;
    isComplete: boolean;
    error?: string;
  } | null>(null);

  // Status feedback toast
  const [toastMessage, setToastMessage] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  const currentPageRef = useRef<HTMLDivElement>(null);
  const hiddenAllPagesRef = useRef<HTMLDivElement>(null);

  const itemsPerPage = config.itemsPerPage || 7;
  const totalTickets = config.endNumber - config.startNumber + 1;
  const totalPages = Math.ceil(totalTickets / itemsPerPage);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ type, text });
    setTimeout(() => setToastMessage(null), 4500);
  };

  const handlePrintAll = () => {
    setActiveTab('all');
    // Ensure the DOM has rendered all pages before calling window.print
    setTimeout(() => {
      window.print();
    }, 600);
  };

  const handlePrintCurrent = () => {
    setActiveTab('sheet');
    setTimeout(() => {
      window.print();
    }, 300);
  };

  const handleDownloadPageImage = async () => {
    if (!currentPageRef.current) return;
    try {
      setIsExportingPage(true);
      const startNum = (currentPage - 1) * itemsPerPage + config.startNumber;
      const endNum = Math.min(config.endNumber, currentPage * itemsPerPage);
      const filename = `folha-${currentPage}-carnes-${String(startNum).padStart(config.digits, '0')}-a-${String(endNum).padStart(config.digits, '0')}.png`;

      await downloadElementAsImage(currentPageRef.current, filename, 2);
      showToast(`Folha ${currentPage} baixada com sucesso! (${filename})`);
    } catch (e: any) {
      console.error(e);
      showToast(`Falha ao baixar imagem: ${e?.message || 'Erro inesperado'}`, 'error');
    } finally {
      setIsExportingPage(false);
    }
  };

  const handleDownloadAllPdf = async () => {
    try {
      const container = hiddenAllPagesRef.current;
      if (!container) {
        throw new Error('Container com todas as folhas não encontrado.');
      }

      const pageElements = Array.from(
        container.querySelectorAll<HTMLElement>('.hidden-sheet-item')
      );

      if (pageElements.length === 0) {
        throw new Error('Nenhuma página disponível para exportação.');
      }

      setExportModal({
        isOpen: true,
        current: 1,
        total: pageElements.length,
        statusText: 'Iniciando montagem do PDF...',
        isComplete: false,
      });

      const filename = `carnes-iniciacao-crista-${String(config.startNumber).padStart(config.digits, '0')}-a-${String(config.endNumber).padStart(config.digits, '0')}.pdf`;

      await downloadPagesAsPdf(
        pageElements,
        filename,
        (current, total, statusText) => {
          setExportModal((prev) =>
            prev ? { ...prev, current, total, statusText } : null
          );
        }
      );

      setExportModal((prev) =>
        prev
          ? {
              ...prev,
              isComplete: true,
              statusText: 'PDF gerado e baixado com sucesso!',
            }
          : null
      );

      showToast(`PDF completo com todas as ${totalPages} folhas baixado com sucesso!`);
      setTimeout(() => setExportModal(null), 2500);
    } catch (e: any) {
      console.error('Erro ao gerar PDF completo:', e);
      setExportModal((prev) =>
        prev
          ? {
              ...prev,
              error: e?.message || 'Erro ao gerar o arquivo PDF.',
            }
          : null
      );
      showToast(`Erro na exportação do PDF: ${e?.message || 'Falha desconhecida'}`, 'error');
    }
  };

  const handleDownloadAllZip = async () => {
    try {
      const container = hiddenAllPagesRef.current;
      if (!container) {
        throw new Error('Container com todas as folhas não encontrado.');
      }

      const pageElements = Array.from(
        container.querySelectorAll<HTMLElement>('.hidden-sheet-item')
      );

      if (pageElements.length === 0) {
        throw new Error('Nenhuma página disponível para exportação.');
      }

      setExportModal({
        isOpen: true,
        current: 1,
        total: pageElements.length,
        statusText: 'Exportando e compactando imagens em alta resolução...',
        isComplete: false,
      });

      const filename = `carnes-todas-as-${totalPages}-folhas-png.zip`;

      await downloadPagesAsZip(
        pageElements,
        filename,
        'carnes-crisma',
        (current, total, statusText) => {
          setExportModal((prev) =>
            prev ? { ...prev, current, total, statusText } : null
          );
        }
      );

      setExportModal((prev) =>
        prev
          ? {
              ...prev,
              isComplete: true,
              statusText: 'Arquivo ZIP gerado e baixado!',
            }
          : null
      );

      showToast(`Arquivo ZIP com todas as ${totalPages} folhas baixado com sucesso!`);
      setTimeout(() => setExportModal(null), 2500);
    } catch (e: any) {
      console.error('Erro ao gerar ZIP:', e);
      setExportModal((prev) =>
        prev
          ? {
              ...prev,
              error: e?.message || 'Erro ao gerar arquivo ZIP.',
            }
          : null
      );
      showToast(`Erro na exportação do ZIP: ${e?.message || 'Falha desconhecida'}`, 'error');
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans text-slate-800">
      {/* HEADER / NAVIGATION (Hidden when printing) */}
      <header className="no-print bg-white border-b border-slate-200 sticky top-0 z-30 shadow-2xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-col md:flex-row md:items-center justify-between gap-3">
          {/* Logo & Info */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-700 to-sky-600 flex items-center justify-center text-white shadow-sm shrink-0">
              <Sparkles className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-black text-slate-900 tracking-tight">
                  Carnê do Crisma · Iniciação Cristã de Jovens e Adultos
                </h1>
                <span className="bg-blue-50 text-blue-800 border border-blue-200 text-[10px] font-bold px-2 py-0.5 rounded-full">
                  R$ {config.value}
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Numerado de {String(config.startNumber).padStart(config.digits, '0')} até {String(config.endNumber).padStart(config.digits, '0')} · {itemsPerPage} por página ({totalPages} folhas A4)
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            {/* CRIAR COPIA EDITAVEL / GERENCIAR COPIAS BUTTON */}
            <button
              onClick={() => setIsCopiesModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer bg-amber-50 text-amber-900 border-amber-300 hover:bg-amber-100 shadow-2xs"
              title="Criar nova cópia editável, duplicar carnê, salvar versões e editar textos"
            >
              <Copy className="w-3.5 h-3.5 text-amber-700" />
              <span>Criar Cópia Editável</span>
              <span className="hidden sm:inline-block bg-amber-200/80 text-amber-900 text-[10px] px-1.5 py-0.2 rounded-full font-bold max-w-[120px] truncate">
                {activeCopy?.name}
              </span>
            </button>

            {/* MUDAR SÍMBOLO DA CÓPIA BUTTON */}
            <button
              onClick={() => setIsCopiesModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer bg-sky-50 text-blue-950 border-sky-300 hover:bg-sky-100 shadow-2xs"
              title="Trocar o símbolo sacro desta cópia (Iniciação Cristã, Espírito Santo, Medalha Milagrosa, Aparecida, Eucaristia, etc.)"
            >
              <div className="w-4 h-4 shrink-0 flex items-center justify-center">
                <ReligiousEmblem type={config.emblemType} customImageUrl={config.customImageUrl} size={15} isCompact={true} />
              </div>
              <span className="hidden md:inline">Símbolo:</span>
              <span className="font-extrabold truncate max-w-[110px]">
                {EMBLEM_OPTIONS.find((o) => o.id === config.emblemType)?.title?.split(' ')[0] || 'Símbolo'}
              </span>
            </button>

            {/* DOWNLOAD EDITABLE HTML COPIA */}
            <button
              onClick={() => {
                downloadEditableHtml(config, activeCopy?.name || 'Carnê');
                showToast(`Cópia editável baixada com sucesso! Você pode abrir no navegador ou Word.`);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold shadow-2xs transition-colors cursor-pointer"
              title="Baixar arquivo offline HTML 100% editável para alterar qualquer texto no navegador ou Word antes de imprimir"
            >
              <FileCode className="w-3.5 h-3.5" />
              Baixar Cópia (.html)
            </button>

            <button
              onClick={() => setShowSettings(!showSettings)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors cursor-pointer ${
                showSettings
                  ? 'bg-slate-800 text-white border-slate-800'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              <Settings2 className="w-3.5 h-3.5" />
              Editar Dados & PIX
            </button>

            {/* DOWNLOAD ALL SHEETS AS PDF BUTTON */}
            <button
              onClick={handleDownloadAllPdf}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-blue-700 hover:bg-blue-800 text-white rounded-lg text-xs font-bold shadow-xs transition-colors cursor-pointer"
              title={`Baixa um único arquivo PDF pronto para gráfica contendo todas as ${totalPages} folhas`}
            >
              <FileDown className="w-3.5 h-3.5 text-amber-300" />
              Baixar Todas as Folhas (PDF)
            </button>

            {/* DOWNLOAD ALL SHEETS AS ZIP BUTTON */}
            <button
              onClick={handleDownloadAllZip}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 rounded-lg text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
              title="Baixa todas as folhas em imagens PNG compactadas em ZIP"
            >
              <FolderArchive className="w-3.5 h-3.5 text-slate-500" />
              Baixar ZIP ({totalPages} Folhas)
            </button>

            {/* PRINT ALL BUTTON */}
            <button
              onClick={handlePrintAll}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-bold shadow-xs transition-colors cursor-pointer"
              title={`Imprime todas as ${totalPages} páginas (001 até 200) direto no PDF/Impressora`}
            >
              <Printer className="w-3.5 h-3.5 text-amber-300" />
              Imprimir Todas ({totalPages} Folhas)
            </button>
          </div>
        </div>

        {/* View Mode Navigation Tabs */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between border-t border-slate-100 overflow-x-auto gap-4 py-1.5">
          <div className="flex items-center gap-1">
            <button
              onClick={() => setActiveTab('sheet')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                activeTab === 'sheet'
                  ? 'bg-blue-50 text-blue-900 font-bold shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              Folha Atual ({itemsPerPage} Carnês)
            </button>

            <button
              onClick={() => setActiveTab('all')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                activeTab === 'all'
                  ? 'bg-blue-50 text-blue-900 font-bold shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              Ver Todas as {totalPages} Folhas
            </button>

            <button
              onClick={() => setActiveTab('banner')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                activeTab === 'banner'
                  ? 'bg-blue-50 text-blue-900 font-bold shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5 text-blue-700" />
              Capas dos Carnês (Numeração 01 a 29)
            </button>

            <button
              onClick={() => setActiveTab('single')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                activeTab === 'single'
                  ? 'bg-blue-50 text-blue-900 font-bold shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              Carnê Individual (Alta Resolução)
            </button>

            <button
              onClick={() => setActiveTab('icone')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                activeTab === 'icone'
                  ? 'bg-amber-100 text-amber-950 font-bold shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Flame className="w-3.5 h-3.5 text-amber-600" />
              Ícone Iniciação Cristã
            </button>
          </div>

          {/* Quick Pagination for Sheet View */}
          {activeTab === 'sheet' && (
            <div className="flex items-center gap-2 shrink-0">
              <span className="text-xs text-slate-500 font-medium hidden sm:inline">
                Página {currentPage} de {totalPages}
              </span>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  disabled={currentPage <= 1}
                  className="p-1 rounded border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed"
                  title="Folha anterior"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>
                <input
                  type="number"
                  min={1}
                  max={totalPages}
                  value={currentPage}
                  onChange={(e) => {
                    const val = parseInt(e.target.value);
                    if (!isNaN(val) && val >= 1 && val <= totalPages) {
                      setCurrentPage(val);
                    }
                  }}
                  className="w-12 text-center text-xs font-semibold py-1 border border-slate-200 rounded focus:ring-1 focus:ring-blue-500 outline-none"
                />
                <button
                  onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                  disabled={currentPage >= totalPages}
                  className="p-1 rounded border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed"
                  title="Próxima folha"
                >
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <button
                onClick={handleDownloadPageImage}
                disabled={isExportingPage}
                className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-900 text-white rounded text-xs font-medium cursor-pointer"
                title="Baixar esta folha inteira como imagem PNG"
              >
                <Download className="w-3 h-3" />
                {isExportingPage ? 'Exportando...' : 'Baixar Imagem PNG'}
              </button>
            </div>
          )}
        </div>
      </header>

      {/* TOAST FEEDBACK NOTIFICATION */}
      {toastMessage && (
        <div className="no-print fixed bottom-4 right-4 z-50 animate-bounce">
          <div
            className={`flex items-center gap-2 px-4 py-3 rounded-xl shadow-lg text-xs font-semibold ${
              toastMessage.type === 'success'
                ? 'bg-emerald-900 text-white'
                : 'bg-rose-900 text-white'
            }`}
          >
            {toastMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-300" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-300" />
            )}
            <span>{toastMessage.text}</span>
          </div>
        </div>
      )}

      {/* BATCH EXPORT PROGRESS MODAL */}
      {exportModal && (
        <div className="no-print fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 p-6 max-w-md w-full space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <FileDown className="w-5 h-5 text-blue-700" />
                <h3 className="font-bold text-slate-900 text-sm">
                  {exportModal.isComplete
                    ? 'Exportação Concluída!'
                    : exportModal.error
                    ? 'Falha na Exportação'
                    : 'Gerando Todas as Folhas para Impressão'}
                </h3>
              </div>
              <button
                onClick={() => setExportModal(null)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {exportModal.error ? (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-900 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold">Ocorreu um erro:</p>
                  <p>{exportModal.error}</p>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-700">
                  <span className="flex items-center gap-1.5">
                    {!exportModal.isComplete && (
                      <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-600" />
                    )}
                    {exportModal.statusText}
                  </span>
                  <span className="font-mono text-blue-700 font-bold">
                    {Math.round((exportModal.current / exportModal.total) * 100)}%
                  </span>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden border border-slate-200">
                  <div
                    className="bg-gradient-to-r from-blue-600 to-sky-500 h-3 rounded-full transition-all duration-200"
                    style={{
                      width: `${(exportModal.current / exportModal.total) * 100}%`,
                    }}
                  />
                </div>

                <div className="text-[11px] text-slate-500 flex justify-between">
                  <span>
                    Folha {exportModal.current} de {exportModal.total}
                  </span>
                  <span>A4 · Alta Resolução</span>
                </div>
              </div>
            )}

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setExportModal(null)}
                className="px-4 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer"
              >
                {exportModal.isComplete || exportModal.error ? 'Fechar' : 'Ocultar Janela'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SAVED COPIES MODAL */}
      <SavedCopiesModal
        isOpen={isCopiesModalOpen}
        onClose={() => setIsCopiesModalOpen(false)}
        currentConfig={config}
        onSelectConfig={handleSelectCopy}
        activeCopyId={activeCopyId}
        setActiveCopyId={setActiveCopyId}
        savedCopies={savedCopies}
        setSavedCopies={setSavedCopies}
      />

      {/* SETTINGS / CUSTOMIZATION DRAWER (Hidden when printing) */}
      {showSettings && (
        <aside className="no-print bg-white border-b border-slate-200 shadow-md">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Settings2 className="w-4 h-4 text-blue-600" />
                Personalização dos Carnês
              </h2>
              <button
                onClick={() => setConfig(DEFAULT_CONFIG)}
                className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                Restaurar Padrão
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
              {/* Valor e Numeração */}
              <div className="space-y-2">
                <label className="font-semibold text-slate-700 block">
                  Valor do Carnê (R$)
                </label>
                <input
                  type="text"
                  value={config.value}
                  onChange={(e) => setConfig({ ...config, value: e.target.value })}
                  placeholder="65,00"
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md focus:border-blue-500 outline-none font-bold text-slate-900"
                />

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <div>
                    <label className="font-semibold text-slate-700 block text-[11px]">
                      Número Inicial
                    </label>
                    <input
                      type="number"
                      value={config.startNumber}
                      onChange={(e) =>
                        setConfig({ ...config, startNumber: parseInt(e.target.value) || 1 })
                      }
                      className="w-full px-2 py-1 border border-slate-300 rounded-md text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="font-semibold text-slate-700 block text-[11px]">
                      Número Final
                    </label>
                    <input
                      type="number"
                      value={config.endNumber}
                      onChange={(e) =>
                        setConfig({ ...config, endNumber: parseInt(e.target.value) || 200 })
                      }
                      className="w-full px-2 py-1 border border-slate-300 rounded-md text-xs font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Textos da Capela e Evento */}
              <div className="space-y-2">
                <label className="font-semibold text-slate-700 block">
                  Título do Evento / Motivo
                </label>
                <input
                  type="text"
                  value={config.eventName}
                  onChange={(e) => setConfig({ ...config, eventName: e.target.value })}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md focus:border-blue-500 outline-none"
                />

                <label className="font-semibold text-slate-700 block pt-1">
                  Subtítulo / Pastoral
                </label>
                <input
                  type="text"
                  value={config.subtitle || ''}
                  placeholder="Iniciação Cristã de Jovens e Adultos"
                  onChange={(e) => setConfig({ ...config, subtitle: e.target.value })}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md focus:border-blue-500 outline-none"
                />

                <label className="font-semibold text-slate-700 block pt-1">
                  Nome da Paróquia
                </label>
                <input
                  type="text"
                  value={config.parishName}
                  onChange={(e) => setConfig({ ...config, parishName: e.target.value })}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md focus:border-blue-500 outline-none"
                />

                <label className="font-semibold text-slate-700 block pt-1">
                  Nome da Capela (Opcional)
                </label>
                <input
                  type="text"
                  value={config.chapelName}
                  onChange={(e) => setConfig({ ...config, chapelName: e.target.value })}
                  placeholder="Deixe em branco para não exibir"
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md focus:border-blue-500 outline-none"
                />
              </div>

              {/* Informações do PIX */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-semibold text-slate-700 block">
                    Pagamento via PIX
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer text-[11px] text-slate-600">
                    <input
                      type="checkbox"
                      checked={config.showPix}
                      onChange={(e) => setConfig({ ...config, showPix: e.target.checked })}
                      className="rounded border-slate-300 text-blue-600"
                    />
                    <span>Ativar PIX</span>
                  </label>
                </div>

                {config.showPix ? (
                  <>
                    <label className="font-semibold text-slate-700 block text-[11px]">
                      Chave PIX
                    </label>
                    <input
                      type="text"
                      value={config.pixKey}
                      onChange={(e) => setConfig({ ...config, pixKey: e.target.value })}
                      placeholder="Icja.apresentacao@gmail.com"
                      className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md focus:border-blue-500 outline-none font-bold text-slate-900 text-xs"
                    />

                    <label className="font-semibold text-slate-700 block pt-1 text-[11px]">
                      Telefone p/ Envio do Comprovante
                    </label>
                    <input
                      type="text"
                      value={config.phoneContact}
                      onChange={(e) => setConfig({ ...config, phoneContact: e.target.value })}
                      placeholder="(21) 97502-7607"
                      className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md focus:border-blue-500 outline-none font-mono text-xs"
                    />
                  </>
                ) : (
                  <div className="p-2.5 bg-slate-50 border border-dashed border-slate-200 rounded-md text-[11px] text-slate-500 leading-tight">
                    PIX desativado conforme solicitado. O comprovante exibe os campos de pagamento e o ícone religioso sem o QR Code.
                  </div>
                )}
              </div>

              {/* Estilo do Layout */}
              <div className="space-y-2">
                <label className="font-semibold text-slate-700 block">
                  Estilo do Carnê
                </label>
                <select
                  value={config.style}
                  onChange={(e) =>
                    setConfig({
                      ...config,
                      style: e.target.value as 'banner_top' | 'photo_classic',
                    })
                  }
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md focus:border-blue-500 outline-none bg-white font-medium"
                >
                  <option value="photo_classic">
                    Clássico Talão (Fiel à Foto 2)
                  </option>
                  <option value="banner_top">
                    Com Faixa Floral Superior (Fotos 1 + 2)
                  </option>
                </select>

                <div className="flex items-center justify-between pt-1">
                  <label className="font-semibold text-slate-700 block">
                    Selo Religioso desta Cópia
                  </label>
                  <button
                    type="button"
                    onClick={() => setIsCopiesModalOpen(true)}
                    className="text-[11px] text-blue-600 font-bold hover:underline cursor-pointer"
                  >
                    Gerenciar Cópias
                  </button>
                </div>

                <select
                  value={config.emblemType}
                  onChange={(e) =>
                    setConfig({
                      ...config,
                      emblemType: e.target.value as any,
                      customImageUrl: e.target.value === 'custom' ? config.customImageUrl : undefined,
                    })
                  }
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md focus:border-blue-500 outline-none bg-white font-medium text-xs"
                >
                  {EMBLEM_OPTIONS.map((opt) => (
                    <option key={opt.id} value={opt.id}>
                      {opt.title} ({opt.category})
                    </option>
                  ))}
                  {config.customImageUrl && (
                    <option value="custom">Sua Imagem Carregada</option>
                  )}
                </select>

                {/* Visual Preview Card of selected symbol */}
                <div className="p-2 bg-amber-50/70 border border-amber-200 rounded-lg flex items-center gap-2.5">
                  <div className="w-9 h-10 shrink-0 bg-white border border-slate-200 rounded flex items-center justify-center p-0.5">
                    <ReligiousEmblem
                      type={config.emblemType}
                      customImageUrl={config.customImageUrl}
                      size={26}
                      isCompact={true}
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-[11px] text-slate-900 truncate">
                      {EMBLEM_OPTIONS.find((o) => o.id === config.emblemType)?.title || 'Personalizado'}
                    </div>
                    <div className="text-[10px] text-slate-500 truncate">
                      {EMBLEM_OPTIONS.find((o) => o.id === config.emblemType)?.subtitle || 'Selo ativo no carnê'}
                    </div>
                  </div>
                </div>

                <label className="font-semibold text-slate-700 block pt-1">
                  Quantidade por Página A4
                </label>
                <select
                  value={config.itemsPerPage}
                  onChange={(e) =>
                    setConfig({
                      ...config,
                      itemsPerPage: parseInt(e.target.value) || 7,
                    })
                  }
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md focus:border-blue-500 outline-none bg-white font-medium"
                >
                  <option value={7}>7 por folha (29 páginas - Padrão)</option>
                  <option value={5}>5 por folha (40 páginas)</option>
                </select>

                <div className="pt-2">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={config.showCrismandoField}
                      onChange={(e) =>
                        setConfig({ ...config, showCrismandoField: e.target.checked })
                      }
                      className="rounded border-slate-300 text-blue-600"
                    />
                    <span className="text-slate-700">Incluir campo "Crismando(a)"</span>
                  </label>
                </div>
              </div>
            </div>

            {/* Rótulos e Ações da Cópia Editável */}
            <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-700">Cópia Ativa:</span>
                <span className="bg-amber-100 text-amber-900 font-bold px-2 py-0.5 rounded-full text-[11px]">
                  {activeCopy?.name}
                </span>
                <span className="text-slate-500 hidden md:inline">
                  · Todos os textos e números podem ser duplicados e exportados para nova cópia.
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsCopiesModalOpen(true)}
                  className="px-3 py-1 bg-amber-100 hover:bg-amber-200 text-amber-950 font-bold rounded-md flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Copy className="w-3.5 h-3.5 text-amber-700" />
                  Criar / Gerenciar Cópias Editáveis
                </button>
                <button
                  onClick={() => {
                    downloadEditableHtml(config, activeCopy?.name || 'Carnê');
                    showToast('Arquivo HTML com textos editáveis baixado com sucesso!');
                  }}
                  className="px-3 py-1 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-md flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <FileCode className="w-3.5 h-3.5" />
                  Baixar HTML Editável (.html)
                </button>
              </div>
            </div>
          </div>
        </aside>
      )}

      {/* MAIN CONTENT AREA */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6">
        {/* TAB 1: SINGLE SHEET VIEW */}
        {activeTab === 'sheet' && (
          <div className="space-y-4">
            <div className="no-print bg-blue-50/60 border border-blue-200/60 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs text-blue-900">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-blue-700 shrink-0" />
                <span>
                  Folha <strong>{currentPage}</strong> de <strong>{totalPages}</strong> — Exibindo carnês de{' '}
                  <strong className="font-mono">
                    Nº {String((currentPage - 1) * itemsPerPage + config.startNumber).padStart(config.digits, '0')}
                  </strong>{' '}
                  até{' '}
                  <strong className="font-mono">
                    Nº {String(Math.min(config.endNumber, currentPage * itemsPerPage)).padStart(config.digits, '0')}
                  </strong>
                  .
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleDownloadPageImage}
                  disabled={isExportingPage}
                  className="px-3 py-1 bg-white hover:bg-slate-50 border border-blue-300 rounded font-semibold text-blue-900 shadow-2xs cursor-pointer flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5 text-blue-700" />
                  {isExportingPage ? 'Gerando...' : 'Baixar Imagem desta Página (PNG)'}
                </button>
                <button
                  onClick={handleDownloadAllPdf}
                  className="px-3 py-1 bg-blue-700 hover:bg-blue-800 text-white rounded font-bold shadow-2xs cursor-pointer flex items-center gap-1.5"
                >
                  <FileDown className="w-3.5 h-3.5 text-amber-300" />
                  Baixar Todas em PDF
                </button>
                <button
                  onClick={handlePrintCurrent}
                  className="px-3 py-1 bg-slate-800 hover:bg-slate-900 text-white rounded font-semibold shadow-2xs cursor-pointer flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5 text-amber-300" />
                  Imprimir esta Folha
                </button>
              </div>
            </div>

            {/* A4 Sheet Preview Container */}
            <div className="flex justify-center overflow-x-auto pb-8">
              <div
                ref={currentPageRef}
                className="bg-white shadow-xl ring-1 ring-slate-900/5 transition-all"
              >
                <CarnePage
                  pageNumber={currentPage}
                  config={config}
                  itemsPerPage={itemsPerPage}
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: ALL SHEETS VIEW (001 TO 200) */}
        {activeTab === 'all' && (
          <div className="space-y-6">
            <div className="no-print bg-amber-50 border border-amber-200 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-amber-900 shadow-xs">
              <div>
                <p className="font-bold text-amber-950 text-sm flex items-center gap-2">
                  <Layers className="w-4 h-4 text-amber-700" />
                  Todas as {totalPages} Folhas A4 Prontas para Impressão (Nº 001 até Nº 200)
                </p>
                <p className="text-amber-800 mt-1">
                  Você pode baixar o arquivo PDF completo de alta qualidade, baixar o pacote de imagens ZIP ou imprimir direto pelo navegador.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  onClick={handleDownloadAllPdf}
                  className="px-4 py-2 bg-blue-700 hover:bg-blue-800 text-white rounded-lg font-bold shadow-xs cursor-pointer flex items-center gap-2"
                >
                  <FileDown className="w-4 h-4 text-amber-300" />
                  Baixar PDF Completo ({totalPages} Folhas)
                </button>
                <button
                  onClick={handleDownloadAllZip}
                  className="px-3.5 py-2 bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 rounded-lg font-semibold shadow-2xs cursor-pointer flex items-center gap-1.5"
                >
                  <FolderArchive className="w-4 h-4 text-slate-600" />
                  Baixar ZIP (Imagens)
                </button>
                <button
                  onClick={handlePrintAll}
                  className="px-3.5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg font-bold shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <Printer className="w-4 h-4 text-amber-300" />
                  Imprimir Todas
                </button>
              </div>
            </div>

            {/* PRINT CONTAINER WITH BULLETPROOF PAGE-BREAK RULES */}
            <div className="print-container flex flex-col items-center gap-8">
              {Array.from({ length: totalPages }).map((_, idx) => (
                <div
                  key={idx + 1}
                  className="print-page-wrapper bg-white shadow-lg ring-1 ring-slate-900/5 print:shadow-none print:ring-0"
                >
                  <CarnePage
                    pageNumber={idx + 1}
                    config={config}
                    itemsPerPage={itemsPerPage}
                  />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: CARNE COVER ART VIEWER */}
        {activeTab === 'banner' && (
          <div className="space-y-4">
            <CarneCoverViewer config={config} />
          </div>
        )}

        {/* TAB 4: SINGLE TICKET INSPECTION & PNG DOWNLOAD */}
        {activeTab === 'single' && (
          <div className="space-y-4">
            <SingleTicketPreview
              currentNumber={currentSingleNumber}
              config={config}
              onNumberChange={(n) => setCurrentSingleNumber(n)}
            />
          </div>
        )}

        {/* TAB 5: ÍCONE INICIAÇÃO CRISTÃ (OFICIAL) */}
        {activeTab === 'icone' && (
          <div className="space-y-4">
            <IniciacaoCristaPreview
              customImageUrl={config.customImageUrl}
              onCustomImageChange={(url) => setConfig({ ...config, customImageUrl: url })}
              selectedEmblem={config.emblemType}
              onSelectEmblem={(type) => setConfig({ ...config, emblemType: type })}
            />
          </div>
        )}
      </main>

      {/* HIDDEN OFFSCREEN CONTAINER FOR INSTANT MULTI-PAGE PDF & ZIP GENERATION */}
      <div
        ref={hiddenAllPagesRef}
        className="no-print"
        style={{
          position: 'fixed',
          left: '-9999px',
          top: 0,
          width: '210mm',
          opacity: 0,
          pointerEvents: 'none',
        }}
        aria-hidden="true"
      >
        {Array.from({ length: totalPages }).map((_, idx) => (
          <div
            key={idx + 1}
            className="hidden-sheet-item bg-white mb-4"
            style={{ width: '210mm', height: '297mm' }}
          >
            <CarnePage
              pageNumber={idx + 1}
              config={config}
              itemsPerPage={itemsPerPage}
            />
          </div>
        ))}
      </div>

      {/* FOOTER (Hidden when printing) */}
      <footer className="no-print bg-white border-t border-slate-200 py-4 text-center text-xs text-slate-500">
        <p>
          Gerador de Carnês para Crisma · Iniciação Cristã de Jovens e Adultos · Paróquia Nossa Senhora da Apresentação
        </p>
        <p className="text-[11px] text-slate-400 mt-1">
          Configurado para papel A4 portrait · {itemsPerPage} unidades por folha · Numeração de {String(config.startNumber).padStart(config.digits, '0')} até {String(config.endNumber).padStart(config.digits, '0')} ({totalPages} folhas A4)
        </p>
      </footer>
    </div>
  );
}
