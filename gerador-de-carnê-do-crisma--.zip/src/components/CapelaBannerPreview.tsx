import React, { useRef, useState } from 'react';
import { CapelaHeaderBanner } from './ReligiousArt';
import { downloadElementAsImage } from '../utils/exportImage';
import { Download, Sparkles, Check } from 'lucide-react';

interface CapelaBannerPreviewProps {
  chapelName: string;
}

export const CapelaBannerPreview: React.FC<CapelaBannerPreviewProps> = ({ chapelName }) => {
  const bannerRef = useRef<HTMLDivElement>(null);
  const [downloading, setDownloading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleDownload = async () => {
    if (!bannerRef.current) return;
    try {
      setDownloading(true);
      await downloadElementAsImage(
        bannerRef.current,
        `faixa-${chapelName.toLowerCase().replace(/\s+/g, '-')}.png`,
        3
      );
    } catch (e) {
      console.error(e);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div>
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-500" />
            Faixa / Arte da Capela Nossa Senhora das Graças
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Layout fiel à foto enviada: Medalha Milagrosa, Imagem de Nossa Senhora, flores azuis e tipografia clássica.
          </p>
        </div>

        <button
          onClick={handleDownload}
          disabled={downloading}
          className="inline-flex items-center gap-2 px-4 py-2 bg-blue-700 hover:bg-blue-800 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer shrink-0"
        >
          <Download className="w-3.5 h-3.5" />
          {downloading ? 'Gerando PNG...' : 'Baixar Faixa em Alta Resolução (PNG)'}
        </button>
      </div>

      <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 overflow-x-auto flex justify-center">
        <div
          ref={bannerRef}
          className="w-full max-w-2xl bg-white rounded-lg shadow-sm overflow-hidden"
        >
          <CapelaHeaderBanner
            title="Capela"
            subtitle={chapelName.replace('Capela ', '')}
            badgeText="CRISMA · SACRAMENTO DA CONFIRMAÇÃO"
            className="h-28"
          />
        </div>
      </div>
    </div>
  );
};
