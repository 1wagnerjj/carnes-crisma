import React from 'react';
import { CarneConfig } from '../types';
import { IniciacaoCristaIcon } from './IniciacaoCristaIcon';
import {
  MedalhaMilagrosaFrente,
  MedalhaMilagrosaVerso,
  NossaSenhoraFigure,
  BlueFloralBorder,
} from './ReligiousArt';
import { PixQrCode } from './PixQrCode';
import { getBookletLabel } from './CarneCoverTicket';
import { ReligiousEmblem } from './ReligiousEmblem';

export type CoverStyle = 'iniciacao_crista' | 'hibrido_sagrado' | 'capela_mariana';

interface CarneCoverArtProps {
  config: CarneConfig;
  coverStyle?: CoverStyle;
  variant?: 'horizontal_banner' | 'full_a4_page';
  bookletIndex?: number;
  bookletLabel?: string;
  isCompact?: boolean;
  className?: string;
}

export const CarneCoverArt: React.FC<CarneCoverArtProps> = ({
  config,
  coverStyle = 'iniciacao_crista',
  variant = 'horizontal_banner',
  bookletIndex = 1,
  bookletLabel,
  isCompact = false,
  className = '',
}) => {
  // If variant is a FULL A4 COVER PAGE for the booklet (Capa de Bloco/Talão)
  if (variant === 'full_a4_page') {
    return (
      <div
        className={`print-page bg-gradient-to-b from-sky-50 via-white to-amber-50/40 text-slate-900 mx-auto shadow-md print:shadow-none p-8 flex flex-col justify-between border-4 border-double border-amber-600/40 rounded-sm relative select-none ${className}`}
        style={{
          width: '210mm',
          height: '297mm',
          maxHeight: '297mm',
          boxSizing: 'border-box',
        }}
      >
        {/* Decorative corner ornaments */}
        <div className="absolute top-3 left-3 w-12 h-12 border-t-2 border-l-2 border-amber-600" />
        <div className="absolute top-3 right-3 w-12 h-12 border-t-2 border-r-2 border-amber-600" />
        <div className="absolute bottom-3 left-3 w-12 h-12 border-b-2 border-l-2 border-amber-600" />
        <div className="absolute bottom-3 right-3 w-12 h-12 border-b-2 border-r-2 border-amber-600" />

        {/* Top Header */}
        <div className="text-center pt-4">
          <p className="text-xs uppercase font-extrabold tracking-[0.25em] text-blue-900">
            {config.parishName}
          </p>
          <h2 className="font-cinzel text-2xl sm:text-3xl font-black text-blue-950 mt-1.5 uppercase tracking-wide drop-shadow-xs">
            INICIAÇÃO CRISTÃ DE JOVENS E ADULTOS
          </h2>
          <div className="flex items-center justify-center gap-3 my-2">
            <span className="h-[1.5px] w-16 bg-amber-500" />
            <span className="text-[11px] font-black uppercase tracking-widest text-amber-700">
              SACRAMENTO DA CONFIRMAÇÃO · CRISMA
            </span>
            <span className="h-[1.5px] w-16 bg-amber-500" />
          </div>
        </div>

        {/* Central Prominent Art: Ícone da Iniciação Cristã */}
        <div className="flex flex-col items-center justify-center my-auto py-2">
          <div className="relative p-6 rounded-full bg-radial from-amber-100/60 via-transparent to-transparent">
            {coverStyle === 'capela_mariana' ? (
              <div className="flex items-center gap-6">
                <MedalhaMilagrosaFrente size={80} />
                <NossaSenhoraFigure className="w-24 h-48" />
                <MedalhaMilagrosaVerso size={80} />
              </div>
            ) : (
              <ReligiousEmblem
                type={config.emblemType}
                customImageUrl={config.customImageUrl}
                size={160}
                showLabel={false}
              />
            )}
          </div>

          <div className="text-center mt-3">
            <h1 className="font-cinzel text-2xl font-black text-slate-900 tracking-wide uppercase">
              Carnê de Contribuição
            </h1>
            <p className="text-sm font-semibold text-blue-900 mt-0.5">
              Iniciação Cristã de Jovens e Adultos (Crisma)
            </p>
            <div className="mt-2 inline-block bg-amber-100/80 border border-amber-300 px-4 py-1 rounded-md text-amber-950 font-black text-base font-mono">
              VALOR: R$ {config.value}
            </div>
          </div>
        </div>

        {/* Lower Info & Identification Box */}
        <div className="bg-white/90 border border-slate-300 rounded-lg p-5 shadow-2xs mx-4 space-y-3">
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <span className="font-bold text-slate-600 block text-[10px] uppercase">
                Nome do Crismando(a):
              </span>
              <span className="block border-b border-slate-400 h-6 pt-1 text-slate-400">
                __________________________________________________
              </span>
            </div>
            <div>
              <span className="font-bold text-slate-600 block text-[10px] uppercase">
                Catequista / Pastoral:
              </span>
              <span className="block border-b border-slate-400 h-6 pt-1 text-slate-400">
                __________________________________________________
              </span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 text-xs pt-1">
            <div>
              <span className="font-bold text-slate-600 block text-[10px] uppercase">
                Numeração dos Carnês:
              </span>
              <span className="font-mono font-bold text-slate-900">
                Nº {String(config.startNumber).padStart(config.digits, '0')} até Nº {String(config.endNumber).padStart(config.digits, '0')}
              </span>
            </div>
            <div>
              <span className="font-bold text-slate-600 block text-[10px] uppercase">
                Total de Parcelas:
              </span>
              <span className="font-semibold text-slate-800">
                {config.endNumber - config.startNumber + 1} contribuições
              </span>
            </div>
            <div>
              <span className="font-bold text-slate-600 block text-[10px] uppercase">
                Ano de Celebração:
              </span>
              <span className="font-semibold text-slate-800">2026</span>
            </div>
          </div>
        </div>

        {/* Bottom Pix & Footer */}
        <div className="flex items-center justify-between border-t border-slate-200 pt-3 px-4">
          <div className="text-[9.5px] text-slate-600">
            <p className="font-bold text-slate-800 uppercase">
              {config.parishName}
            </p>
            <p className="text-[8.5px] text-slate-500">
              Iniciação Cristã de Jovens e Adultos · Pastoral do Crisma
            </p>
          </div>
          {config.showPix ? (
            <div className="shrink-0 scale-90">
              <PixQrCode
                value={config.pixKey}
                size={54}
                bankName={config.bankName}
                parishName={config.parishName}
                phoneContact={config.phoneContact}
                showDetails={false}
              />
            </div>
          ) : (
            <div className="text-right text-xs text-blue-950 font-bold font-cinzel tracking-wider">
              "Vinde, Espírito Santo!"
            </div>
          )}
        </div>
      </div>
    );
  }

  // HORIZONTAL BANNER COVER (Exatamente a aparência da imagem enviada pelo usuário, com numeração dos talões)
  if (coverStyle === 'iniciacao_crista') {
    const finalLabel =
      bookletLabel ||
      getBookletLabel(
        bookletIndex,
        config.itemsPerPage || 7,
        config.startNumber,
        config.endNumber,
        config.digits
      );

    return (
      <div
        className={`relative overflow-hidden bg-[#FFFDF5] border border-amber-300/90 rounded-xs select-none shadow-xs flex items-center justify-between ${
          isCompact ? 'px-3 py-1.5' : 'px-5 py-2.5'
        } ${className}`}
        style={{
          boxSizing: 'border-box',
        }}
      >
        {/* Subtle background glow */}
        <div className="absolute left-0 top-0 w-28 h-full bg-gradient-to-r from-amber-100/40 to-transparent pointer-events-none" />
        <div className="absolute right-0 top-0 w-32 h-full bg-gradient-to-l from-amber-100/40 to-transparent pointer-events-none" />

        {/* LEFT: Símbolo Sagrado da Cópia / Iniciação Cristã */}
        <div className="shrink-0 flex items-center justify-center pr-3 z-10">
          <ReligiousEmblem
            type={config.emblemType}
            customImageUrl={config.customImageUrl}
            size={isCompact ? 46 : 58}
            isCompact={isCompact}
            showLabel={false}
          />
        </div>

        {/* CENTER: Tipografia em 2 linhas com cores fiéis à foto */}
        <div className="flex-1 text-center px-2 flex flex-col justify-center z-10">
          <span className={`${isCompact ? 'text-[8.5px]' : 'text-[10px]'} uppercase font-extrabold tracking-[0.18em] text-[#92400e]`}>
            {config.eventName || 'CARNÊ DE CONTRIBUIÇÃO PARA O CRISMA'}
          </span>

          <h2 className={`${isCompact ? 'text-sm sm:text-base' : 'text-base sm:text-xl'} font-black text-[#1e1b4b] leading-tight my-0.5 tracking-wide uppercase drop-shadow-2xs`}>
            {config.subtitle ? (
              <span>{config.subtitle}</span>
            ) : (
              <>
                <span>INICIAÇÃO CRISTÃ DE JOVENS E</span>
                <span className="block">ADULTOS</span>
              </>
            )}
          </h2>

          <p className={`${isCompact ? 'text-[7px]' : 'text-[8.5px]'} uppercase font-bold text-slate-600 tracking-wider`}>
            {config.chapelName ? `${config.chapelName} · ${config.parishName}` : config.parishName}
          </p>

          <div className="flex items-center justify-center gap-2 mt-0.5">
            <span className="h-[1.5px] w-8 bg-amber-400" />
            <span className={`${isCompact ? 'text-[7px]' : 'text-[8px]'} font-black tracking-widest text-[#1e1b4b] uppercase`}>
              {config.tagline || 'CRISMA · CONFIRMAÇÃO'}
            </span>
            <span className="h-[1.5px] w-8 bg-amber-400" />
          </div>
        </div>

        {/* RIGHT: Valor Unitário, Chave PIX e Numeração dos Talões bem visível */}
        <div className="shrink-0 flex flex-col items-center justify-center pl-2 sm:pl-3 border-l border-amber-300 z-10 space-y-0.5 sm:space-y-1 max-w-[130px] sm:max-w-[155px]">
          <span className={`${isCompact ? 'text-[6.5px]' : 'text-[7.5px]'} uppercase font-extrabold text-slate-500 tracking-wider whitespace-nowrap`}>
            {config.coverValueLabel || 'VALOR UNITÁRIO'}
          </span>

          {/* Caixa Valor R$ 65,00 */}
          <div className="bg-[#FEF9C3] text-amber-950 border border-amber-400 px-2.5 py-0.5 rounded font-black text-xs sm:text-sm font-mono shadow-2xs whitespace-nowrap">
            R$ {config.value}
          </div>

          {/* Caixa Chave PIX */}
          {config.pixKey && (
            <div className="bg-[#FEF9C3] text-[#991b1b] border border-amber-400 px-1.5 py-0.5 rounded font-black text-[7.5px] sm:text-[9px] font-mono shadow-2xs whitespace-nowrap max-w-full truncate text-center" title={`PIX: ${config.pixKey}`}>
              PIX: {config.pixKey}
            </div>
          )}

          {/* NUMERAÇÃO EM DESTAQUE (001 até 007 - 01, ..., 197 até 200 - 29) */}
          <div className="pt-0.5 flex flex-col items-center w-full">
            <span className="text-[6.5px] uppercase font-bold text-slate-500 tracking-wider whitespace-nowrap">
              {config.coverStubLabel || 'Nº TALÃO'}
            </span>
            <div className="bg-rose-50 border border-rose-300 text-rose-700 px-1.5 py-0.5 rounded font-black text-[9.5px] sm:text-[11px] font-mono shadow-2xs whitespace-nowrap tracking-tight text-center max-w-full">
              {finalLabel}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Style 2: HÍBRIDO SAGRADO (Flores azuis de Nossa Senhora + Ícone da Iniciação Cristã)
  if (coverStyle === 'hibrido_sagrado') {
    return (
      <div
        className={`relative overflow-hidden bg-gradient-to-r from-sky-100 via-white to-sky-100 border border-sky-300 rounded-xs select-none shadow-xs ${className}`}
      >
        <BlueFloralBorder className="absolute -left-6 -top-4 w-28 h-20 opacity-70 pointer-events-none" />
        <BlueFloralBorder className="absolute -right-6 -top-4 w-28 h-20 opacity-70 pointer-events-none" flipped />

        <div className="relative flex items-center justify-between px-4 py-2 z-10 h-full">
          {/* Left: Nossa Senhora das Graças & Medalha */}
          <div className="flex items-center gap-1.5 shrink-0">
            <MedalhaMilagrosaFrente size={36} />
            <NossaSenhoraFigure className="w-8 h-14" />
          </div>

          {/* Center: Title & Chapel */}
          <div className="flex-1 text-center px-2 flex flex-col justify-center">
            <span className="font-script text-2xl leading-none text-blue-900 tracking-wide">
              Capela
            </span>
            <span className="font-script text-xl leading-tight text-blue-950 font-bold -mt-0.5">
              {config.chapelName.replace('Capela ', '')}
            </span>
            <div className="flex items-center justify-center gap-1.5 mt-0.5">
              <span className="h-[1px] w-6 bg-amber-400" />
              <span className="text-[8.5px] font-bold tracking-widest text-amber-800 uppercase">
                INICIAÇÃO CRISTÃ · CRISMA
              </span>
              <span className="h-[1px] w-6 bg-amber-400" />
            </div>
          </div>

          {/* Right: Ícone da Iniciação Cristã */}
          <div className="shrink-0 pl-2 border-l border-sky-200 flex items-center justify-center">
            {config.customImageUrl ? (
              <img
                src={config.customImageUrl}
                alt="Ícone"
                className="h-14 w-auto max-w-[56px] object-contain"
              />
            ) : (
              <IniciacaoCristaIcon size={46} showText={true} />
            )}
          </div>
        </div>
      </div>
    );
  }

  // Style 3: CAPELA MARIANA CLÁSSICA (Fiel à Foto 1)
  return (
    <div
      className={`relative overflow-hidden bg-gradient-to-r from-sky-100 via-blue-50 to-sky-100 border border-sky-200 select-none ${className}`}
    >
      <BlueFloralBorder className="absolute -left-6 -top-4 w-28 h-20 opacity-70 pointer-events-none" />
      <BlueFloralBorder className="absolute -right-6 -top-4 w-28 h-20 opacity-70 pointer-events-none" flipped />

      <div className="relative flex items-center justify-between px-3 py-1.5 z-10 h-full">
        <div className="flex flex-col items-center shrink-0">
          <MedalhaMilagrosaFrente size={36} />
        </div>

        <div className="flex-1 text-center px-2 flex flex-col justify-center">
          <span className="font-script text-2xl leading-none text-blue-900 tracking-wide">
            Capela
          </span>
          <span className="font-script text-xl leading-tight text-blue-950 font-bold -mt-0.5">
            {config.chapelName.replace('Capela ', '')}
          </span>
          <div className="flex items-center justify-center gap-1.5 mt-0.5">
            <span className="h-[1px] w-6 bg-amber-400" />
            <span className="text-[9px] font-bold tracking-widest text-blue-900 uppercase">
              CRISMA
            </span>
            <span className="h-[1px] w-6 bg-amber-400" />
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <NossaSenhoraFigure className="w-8 h-14" />
          <MedalhaMilagrosaVerso size={36} />
        </div>
      </div>
    </div>
  );
};
