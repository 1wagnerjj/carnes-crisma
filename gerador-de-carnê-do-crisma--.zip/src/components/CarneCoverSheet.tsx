import React from 'react';
import { CarneConfig } from '../types';
import { CarneCoverArt } from './CarneCoverArt';

interface CarneCoverSheetProps {
  pageNumber: number; // 1-indexed (1 to 5)
  config: CarneConfig;
  itemsPerPage?: number;
}

export const CarneCoverSheet: React.FC<CarneCoverSheetProps> = ({
  pageNumber,
  config,
  itemsPerPage = 7,
}) => {
  const effectiveItemsPerBooklet = itemsPerPage || config.itemsPerPage || 7;
  const totalBooklets = Math.ceil((config.endNumber - config.startNumber + 1) / effectiveItemsPerBooklet);
  const coversPerPage = 7;
  const totalCoverPages = Math.ceil(totalBooklets / coversPerPage);

  const startBooklet = (pageNumber - 1) * coversPerPage + 1;
  const bookletIndices: number[] = [];

  for (let i = 0; i < coversPerPage; i++) {
    const idx = startBooklet + i;
    if (idx <= totalBooklets) {
      bookletIndices.push(idx);
    }
  }

  return (
    <div
      className="print-page bg-white text-slate-900 mx-auto shadow-md print:shadow-none p-2 print:p-0 flex flex-col justify-between"
      style={{
        width: '210mm',
        height: '297mm',
        maxHeight: '297mm',
        boxSizing: 'border-box',
      }}
    >
      {/* Header (hidden in print) */}
      <div className="no-print flex justify-between items-center text-[8px] text-slate-400 border-b border-slate-200 pb-0.5 mb-1">
        <div className="flex items-center gap-2">
          <span className="font-bold text-slate-600 uppercase">
            FOLHA DE CAPAS DOS CARNÊS
          </span>
          <span>·</span>
          <span>{config.parishName}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="font-mono font-medium text-slate-500">
            Folha de Capas {pageNumber} de {totalCoverPages} (Talões {String(bookletIndices[0] || 1).padStart(2, '0')} a {String(bookletIndices[bookletIndices.length - 1] || 1).padStart(2, '0')})
          </span>
        </div>
      </div>

      {/* 7 Capas de Carnê encaixadas perfeitamente */}
      <div className="flex-1 flex flex-col h-full overflow-hidden border border-slate-300 print:border-none">
        {bookletIndices.map((bIdx, idx) => (
          <div
            key={bIdx}
            className={`flex-1 min-h-0 flex flex-col justify-stretch ${
              idx < bookletIndices.length - 1 ? 'border-b border-dashed border-slate-300' : ''
            }`}
          >
            <CarneCoverArt
              config={config}
              bookletIndex={bIdx}
              isCompact={true}
              className="h-full flex-1 border-none shadow-none rounded-none"
            />
          </div>
        ))}
      </div>

      {/* Footer (hidden in print) */}
      <div className="no-print text-[7.5px] text-slate-400 flex justify-between items-center border-t border-slate-200 pt-0.5 mt-1">
        <span>* Folha de Capas: {bookletIndices.length} capas com numerações de talão correspondentes</span>
        <span className="font-semibold text-slate-600">
          Total de {totalBooklets} talões
        </span>
      </div>
    </div>
  );
};
