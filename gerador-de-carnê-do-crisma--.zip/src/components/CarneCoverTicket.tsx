import React from 'react';
import { CarneConfig } from '../types';
import { IniciacaoCristaIcon } from './IniciacaoCristaIcon';
import {
  MedalhaMilagrosaFrente,
} from './ReligiousArt';
import { ReligiousEmblem } from './ReligiousEmblem';

export interface CarneCoverTicketProps {
  bookletIndex: number; // 1-indexed (1 to 29)
  config: CarneConfig;
  className?: string;
  isSinglePreview?: boolean;
  isCompact?: boolean;
  itemsPerPage?: number;
}

/**
 * Returns the exact string requested:
 * "001 até 007 - 01", "008 até 014 - 02", ..., "197 até 200 - 29"
 */
export function getBookletLabel(
  bookletIndex: number,
  itemsPerBooklet: number = 7,
  startNumber: number = 1,
  endNumber: number = 200,
  digits: number = 3
): string {
  const start = (bookletIndex - 1) * itemsPerBooklet + startNumber;
  const end = Math.min(bookletIndex * itemsPerBooklet, endNumber);
  const startStr = String(start).padStart(digits, '0');
  const endStr = String(end).padStart(digits, '0');
  const bookletStr = String(bookletIndex).padStart(2, '0');
  return `${startStr} até ${endStr} - ${bookletStr}`;
}

export const CarneCoverTicket: React.FC<CarneCoverTicketProps> = ({
  bookletIndex,
  config,
  className = '',
  isSinglePreview = false,
  isCompact = false,
  itemsPerPage = 7,
}) => {
  const bookletLabel = getBookletLabel(
    bookletIndex,
    itemsPerPage || config.itemsPerPage || 7,
    config.startNumber,
    config.endNumber,
    config.digits
  );

  const renderEmblem = (size = 46) => {
    return (
      <ReligiousEmblem
        type={config.emblemType}
        customImageUrl={config.customImageUrl}
        size={size}
        isCompact={isCompact}
        showLabel={!isCompact}
      />
    );
  };

  const renderWatermark = () => {
    return (
      <div className="opacity-15 pointer-events-none scale-125">
        <ReligiousEmblem
          type={config.emblemType}
          customImageUrl={config.customImageUrl}
          size={64}
          isCompact={false}
          showLabel={false}
        />
      </div>
    );
  };

  return (
    <div
      className={`carne-ticket relative bg-white overflow-hidden text-slate-800 flex select-none ${className}`}
      style={{
        height: isSinglePreview ? '56mm' : '100%',
        minHeight: isSinglePreview ? '56mm' : '0',
        boxSizing: 'border-box',
      }}
    >
      {/* LEFT SECTION: CANHOTO DA CAPA (Via de Controle) */}
      <div
        className={`w-[30%] border-r border-dashed border-slate-400 ${
          isCompact ? 'p-1.5' : 'p-2.5'
        } flex flex-col justify-between bg-amber-50/40 relative`}
      >
        <div
          className={`flex items-center justify-between border-b border-slate-200 ${
            isCompact ? 'pb-0.5' : 'pb-1'
          }`}
        >
          <span className="text-[7px] font-bold text-slate-600 uppercase tracking-wider">
            VIA CONTROLE · CAPA
          </span>
          <span
            className={`${
              isCompact ? 'text-[8.5px]' : 'text-[9.5px]'
            } font-black text-rose-700 font-mono tracking-tight`}
          >
            {bookletLabel}
          </span>
        </div>

        <div className={isCompact ? 'my-0.5' : 'my-1'}>
          <div
            className={`${
              isCompact ? 'text-[10.5px]' : 'text-[12px]'
            } font-black tracking-tight text-slate-900`}
          >
            VALOR R$ {config.value}
          </div>
          {config.pixKey && (
            <div className="bg-amber-100/80 border border-amber-300 px-1 py-0.5 rounded mt-0.5">
              <span className="text-[7px] font-black text-slate-700 uppercase">PIX: </span>
              <span className="text-[7.5px] font-black text-rose-700 font-mono tracking-tight">
                {config.pixKey}
              </span>
            </div>
          )}
        </div>

        <div className={`${isCompact ? 'space-y-1 text-[7px]' : 'space-y-1.5 text-[8px]'} text-slate-700`}>
          <div>
            <div className="font-semibold text-slate-600 text-[6.5px] uppercase tracking-wider">
              {config.fieldPaymentDate || 'DATA DO PAGAMENTO'}
            </div>
            <div className="border-b border-slate-400 text-slate-500 tracking-widest pt-0.5 font-mono">
              ____ / ____ / ________
            </div>
          </div>
          <div>
            <div className="font-semibold text-slate-600 text-[6.5px] uppercase tracking-wider">
              {config.fieldReceivedBy || 'RECEBIDO POR'}
            </div>
            <div className={`border-b border-slate-400 ${isCompact ? 'h-2.5' : 'h-3'}`}></div>
          </div>
          {config.showCrismandoField && (
            <div>
              <div className="font-semibold text-slate-600 text-[6.5px] uppercase tracking-wider">
                {config.fieldCandidate || 'CRISMANDO(A)'}
              </div>
              <div className={`border-b border-slate-400 ${isCompact ? 'h-2.5' : 'h-3'}`}></div>
            </div>
          )}
        </div>
      </div>

      {/* PICOTE / PERFORATION INDICATOR */}
      <div className="relative flex flex-col justify-around items-center -ml-[9px] z-10 pointer-events-none">
        <div className="bg-white px-0.5 text-[7px] text-slate-400 transform -rotate-90">
          ✂
        </div>
      </div>

      {/* RIGHT SECTION: FRENTE DA CAPA DO CARNÊ (Mesmo Layout do Comprovante) */}
      <div className={`flex-1 ${isCompact ? 'p-1.5' : 'p-2.5'} flex flex-col justify-between relative bg-white`}>
        {/* Soft watermark */}
        <div className="absolute right-36 top-1/2 -translate-y-1/2 pointer-events-none">
          {renderWatermark()}
        </div>

        {/* Top bar: Title and Number with exact Booklet String */}
        <div
          className={`flex items-start justify-between border-b border-slate-100 ${
            isCompact ? 'pb-0.5' : 'pb-1'
          }`}
        >
          <div className="flex-1 pr-2">
            <div className="flex items-center gap-1.5">
              <span className="bg-blue-900 text-white text-[7px] font-black uppercase px-1.5 py-0.2 rounded-xs tracking-wider">
                CAPA
              </span>
              <h3
                className={`${
                  isCompact ? 'text-[9.5px]' : 'text-[11px]'
                } font-extrabold text-blue-950 uppercase tracking-tight leading-tight`}
              >
                {config.eventName}
              </h3>
            </div>
            <p className={`${isCompact ? 'text-[7.5px]' : 'text-[8.5px]'} font-semibold text-blue-900 uppercase`}>
              {config.chapelName || config.parishName}
            </p>
          </div>

          <div className="text-right shrink-0">
            <span className="text-[6.5px] uppercase font-bold text-slate-400 tracking-wider block">
              TALÃO / NÚMEROS
            </span>
            <div
              className={`inline-block bg-rose-50 border border-rose-300 text-rose-700 ${
                isCompact ? 'px-1.5 py-0.5 text-[10px]' : 'px-2 py-0.5 text-xs'
              } rounded font-black tracking-tight shadow-2xs font-mono whitespace-nowrap`}
            >
              {bookletLabel}
            </div>
          </div>
        </div>

        {/* Middle row: Values, Payment lines, Central Seal */}
        <div className={`flex items-center justify-between ${isCompact ? 'gap-2 my-0.5' : 'gap-3 my-auto'}`}>
          {/* Column 1: Payment info */}
          <div className={`flex-1 ${isCompact ? 'space-y-1' : 'space-y-1.5'}`}>
            <div className="flex items-center justify-between gap-2">
              <div
                className={`${
                  isCompact ? 'text-xs' : 'text-sm'
                } font-black text-slate-900 tracking-tight shrink-0`}
              >
                VALOR R$ {config.value}
              </div>
              {config.pixKey && (
                <div
                  className={`inline-flex items-center gap-1.5 bg-amber-100/90 border border-amber-400 text-slate-900 ${
                    isCompact ? 'px-2 py-0.5' : 'px-2.5 py-1'
                  } rounded shadow-xs`}
                >
                  <span
                    className={`${
                      isCompact ? 'text-[9px]' : 'text-[10px]'
                    } font-black text-slate-800 tracking-wider uppercase`}
                  >
                    PIX:
                  </span>
                  <span
                    className={`${
                      isCompact ? 'text-[10.5px]' : 'text-[12px]'
                    } font-black text-rose-700 tracking-tight font-mono select-all`}
                  >
                    {config.pixKey}
                  </span>
                </div>
              )}
            </div>

            <div className={`grid grid-cols-2 ${isCompact ? 'gap-1.5 text-[7px]' : 'gap-3 text-[8px]'}`}>
              <div>
                <span className="font-semibold text-slate-600 text-[6.5px] uppercase tracking-wider block">
                  {config.fieldPaymentDate || 'DATA DO PAGAMENTO'}
                </span>
                <span className="block border-b border-slate-400 text-slate-500 tracking-widest pt-0.5 font-mono">
                  ____ / ____ / ________
                </span>
              </div>
              <div>
                <span className="font-semibold text-slate-600 text-[6.5px] uppercase tracking-wider block">
                  {config.fieldReceivedBy || 'RECEBIDO POR'}
                </span>
                <span className={`block border-b border-slate-400 ${isCompact ? 'h-2.5' : 'h-3'}`}></span>
              </div>
            </div>

            {config.showCrismandoField && (
              <div className="pt-0.5">
                <span className="font-semibold text-slate-600 text-[6.5px] uppercase tracking-wider block">
                  {config.fieldCandidate || 'CRISMANDO(A)'}
                </span>
                <span className={`block border-b border-slate-400 ${isCompact ? 'h-2.5' : 'h-3'}`}></span>
              </div>
            )}
          </div>

          {/* Column 2: Central Religious Stamp / Emblem */}
          <div
            className={`flex flex-col items-center justify-center ${
              isCompact ? 'px-2 py-0.5' : 'px-3 py-1'
            } border-l border-slate-100 text-center shrink-0`}
          >
            {renderEmblem(isCompact ? 36 : 56)}
          </div>
        </div>

        {/* Bottom footer text */}
        <div
          className={`${
            isCompact ? 'text-[6.5px]' : 'text-[7.5px]'
          } text-slate-500 border-t border-slate-100 pt-0.5 flex justify-between items-center`}
        >
          <span>
            * <strong>CAPA DO CARNÊ</strong> · Guarde este comprovante para a Pastoral do Crisma.{' '}
            {config.pixKey && (
              <>
                · Chave PIX:{' '}
                <strong className="text-slate-900 font-mono font-black text-[8px] bg-amber-50 px-1 py-0.2 rounded border border-amber-200">
                  {config.pixKey}
                </strong>
              </>
            )}
          </span>
          <span className="font-semibold text-blue-900">Paz e Bem!</span>
        </div>
      </div>
    </div>
  );
};
