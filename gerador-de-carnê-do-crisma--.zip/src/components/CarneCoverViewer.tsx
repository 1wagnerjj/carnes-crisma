import React, { useRef, useState } from 'react';
import { CarneConfig } from '../types';
import { CarneCoverTicket, getBookletLabel } from './CarneCoverTicket';
import { CarneCoverArt } from './CarneCoverArt';
import { CarneCoverSheet } from './CarneCoverSheet';
import {
  downloadElementAsImage,
  downloadPagesAsPdf,
  downloadPagesAsZip,
} from '../utils/exportImage';
import {
  Download,
  Printer,
  ChevronLeft,
  ChevronRight,
  BookOpen,
  Layers,
  FileText,
  CheckCircle2,
  AlertCircle,
  Loader2,
  FileDown,
  FolderArchive,
  Sparkles,
} from 'lucide-react';

interface CarneCoverViewerProps {
  config: CarneConfig;
}

export const CarneCoverViewer: React.FC<CarneCoverViewerProps> = ({
  config,
}) => {
  const itemsPerBooklet = config.itemsPerPage || 7;
  const totalBooklets = Math.ceil((config.endNumber - config.startNumber + 1) / itemsPerBooklet);
  const coversPerPage = 7;
  const totalCoverPages = Math.ceil(totalBooklets / coversPerPage);

  const [currentBooklet, setCurrentBooklet] = useState<number>(1);
  const [viewMode, setViewMode] = useState<'single_cover' | 'cover_sheet' | 'all_covers'>('cover_sheet');
  const [currentCoverPage, setCurrentCoverPage] = useState<number>(1);
  const [downloading, setDownloading] = useState(false);
  const [progress, setProgress] = useState<{ current: number; total: number; message: string } | null>(null);
  const [feedback, setFeedback] = useState<{
    type: 'success' | 'error' | 'loading';
    message: string;
  } | null>(null);

  const singleCoverRef = useRef<HTMLDivElement>(null);
  const sheetCoverRef = useRef<HTMLDivElement>(null);
  const allCoversHiddenRef = useRef<HTMLDivElement>(null);

  const currentLabel = getBookletLabel(
    currentBooklet,
    itemsPerBooklet,
    config.startNumber,
    config.endNumber,
    config.digits
  );

  const handleDownloadSingle = async () => {
    try {
      setDownloading(true);
      let target = singleCoverRef.current;
      if (!target) {
        setViewMode('single_cover');
        await new Promise((r) => setTimeout(r, 150));
        target = singleCoverRef.current;
      }
      if (!target) {
        throw new Error('Elemento da capa individual não encontrado na página.');
      }

      const safeLabel = currentLabel.replace(/\s+/g, '-').replace(/[^a-zA-Z0-9-]/g, '');
      const filename = `capa-carne-${safeLabel}.png`;
      setFeedback({ type: 'loading', message: `Gerando imagem em alta resolução da capa ${safeLabel}...` });

      await downloadElementAsImage(target, filename, 3);

      setFeedback({ type: 'success', message: `Capa individual ${safeLabel} baixada com sucesso!` });
      setTimeout(() => setFeedback(null), 4000);
    } catch (e: any) {
      console.error(e);
      setFeedback({
        type: 'error',
        message: `Não foi possível baixar a capa: ${e?.message || 'Erro desconhecido'}`,
      });
      setTimeout(() => setFeedback(null), 5000);
    } finally {
      setDownloading(false);
    }
  };

  const handleDownloadSheet = async () => {
    try {
      setDownloading(true);
      let target = sheetCoverRef.current;
      if (!target) {
        setViewMode('cover_sheet');
        await new Promise((r) => setTimeout(r, 150));
        target = sheetCoverRef.current;
      }
      if (!target) {
        throw new Error('Elemento da folha de capas não encontrado na página.');
      }

      const filename = `folha-capas-${currentCoverPage}-de-${totalCoverPages}.png`;
      setFeedback({
        type: 'loading',
        message: `Gerando imagem PNG da Folha ${currentCoverPage} de ${totalCoverPages} (7 capas)...`,
      });

      await downloadElementAsImage(target, filename, 2);

      setFeedback({
        type: 'success',
        message: `Folha de Capas ${currentCoverPage} baixada com sucesso! (${filename})`,
      });
      setTimeout(() => setFeedback(null), 4500);
    } catch (e: any) {
      console.error('Erro ao baixar folha de capas:', e);
      setFeedback({
        type: 'error',
        message: `Falha ao baixar imagem da folha: ${e?.message || 'Erro durante a exportação'}`,
      });
      setTimeout(() => setFeedback(null), 5000);
    } finally {
      setDownloading(false);
    }
  };

  const handleDownloadAllCoversPdf = async () => {
    try {
      setDownloading(true);
      const container = allCoversHiddenRef.current;
      if (!container) {
        throw new Error('Container com as folhas de capas não encontrado.');
      }

      const pages = Array.from(container.querySelectorAll<HTMLElement>('.hidden-cover-page'));
      if (pages.length === 0) {
        throw new Error('Nenhuma folha de capa disponível para exportação.');
      }

      setProgress({ current: 1, total: pages.length, message: 'Iniciando geração do PDF de capas...' });

      await downloadPagesAsPdf(
        pages,
        `capas-carnes-001-a-${String(config.endNumber).padStart(config.digits, '0')}.pdf`,
        (curr, tot, msg) => {
          setProgress({ current: curr, total: tot, message: msg });
        }
      );

      setFeedback({
        type: 'success',
        message: `PDF completo com todas as ${totalCoverPages} folhas de capas gerado e baixado com sucesso!`,
      });
      setTimeout(() => setFeedback(null), 5000);
    } catch (e: any) {
      console.error(e);
      setFeedback({
        type: 'error',
        message: `Erro ao gerar PDF de capas: ${e?.message || 'Falha na exportação'}`,
      });
    } finally {
      setDownloading(false);
      setProgress(null);
    }
  };

  const handleDownloadAllCoversZip = async () => {
    try {
      setDownloading(true);
      const container = allCoversHiddenRef.current;
      if (!container) {
        throw new Error('Container com as folhas de capas não encontrado.');
      }

      const pages = Array.from(container.querySelectorAll<HTMLElement>('.hidden-cover-page'));
      if (pages.length === 0) {
        throw new Error('Nenhuma folha de capa disponível para exportação.');
      }

      setProgress({ current: 1, total: pages.length, message: 'Compactando imagens das capas...' });

      await downloadPagesAsZip(
        pages,
        `capas-carnes-todas-folhas.zip`,
        'capas-carnes',
        (curr, tot, msg) => {
          setProgress({ current: curr, total: tot, message: msg });
        }
      );

      setFeedback({
        type: 'success',
        message: `Arquivo ZIP com todas as ${totalCoverPages} folhas de capas baixado com sucesso!`,
      });
      setTimeout(() => setFeedback(null), 5000);
    } catch (e: any) {
      console.error(e);
      setFeedback({
        type: 'error',
        message: `Erro ao gerar arquivo ZIP: ${e?.message || 'Falha na exportação'}`,
      });
    } finally {
      setDownloading(false);
      setProgress(null);
    }
  };

  const handlePrintAllCovers = () => {
    setViewMode('all_covers');
    setTimeout(() => {
      window.print();
    }, 500);
  };

  return (
    <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-5 space-y-6">
      {/* Header and Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        <div>
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-blue-700" />
            Capas dos Carnês (Layout Idêntico ao Carnê com Numeração dos Talões)
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Cada capa tem o mesmo formato do carnê e identifica o intervalo exato de cada talão: <strong>001 até 007 - 01</strong>, <strong>008 até 014 - 02</strong>, até <strong>197 até 200 - 29</strong>.
          </p>
        </div>

        {/* Top Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Download ALL Covers as PDF */}
          <button
            onClick={handleDownloadAllCoversPdf}
            disabled={downloading}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-blue-700 hover:bg-blue-800 disabled:bg-blue-400 text-white rounded-lg text-xs font-bold shadow-xs cursor-pointer transition-colors"
            title="Baixar arquivo PDF com todas as 5 folhas de capas prontas para impressão"
          >
            {downloading && progress ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <FileDown className="w-3.5 h-3.5 text-amber-300" />
            )}
            Baixar Todas as Capas em PDF ({totalCoverPages} Folhas)
          </button>

          {/* Download Current Sheet PNG Button */}
          <button
            onClick={handleDownloadSheet}
            disabled={downloading}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 rounded-lg text-xs font-semibold shadow-2xs cursor-pointer transition-colors"
            title="Baixar imagem PNG da folha A4 atual"
          >
            <Download className="w-3.5 h-3.5 text-slate-600" />
            Baixar Imagem da Folha {currentCoverPage} (PNG)
          </button>

          {/* Print All Covers Button */}
          <button
            onClick={handlePrintAllCovers}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-bold shadow-xs cursor-pointer transition-colors"
            title="Imprime todas as 5 folhas A4 contendo as 29 capas"
          >
            <Printer className="w-3.5 h-3.5 text-amber-300" />
            Imprimir Todas as 29 Capas
          </button>
        </div>
      </div>

      {/* Progress banner during batch export */}
      {progress && (
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 space-y-2">
          <div className="flex items-center justify-between text-xs font-semibold text-blue-900">
            <span className="flex items-center gap-2">
              <Loader2 className="w-4 h-4 animate-spin text-blue-700" />
              {progress.message}
            </span>
            <span>
              Folha {progress.current} de {progress.total} ({Math.round((progress.current / progress.total) * 100)}%)
            </span>
          </div>
          <div className="w-full bg-blue-200 rounded-full h-2 overflow-hidden">
            <div
              className="bg-blue-700 h-2 transition-all duration-200"
              style={{ width: `${(progress.current / progress.total) * 100}%` }}
            />
          </div>
        </div>
      )}

      {/* Real-time Feedback notification */}
      {feedback && !progress && (
        <div
          className={`flex items-center gap-2 p-3 rounded-lg text-xs font-medium transition-all ${
            feedback.type === 'loading'
              ? 'bg-blue-50 text-blue-900 border border-blue-200'
              : feedback.type === 'success'
              ? 'bg-emerald-50 text-emerald-900 border border-emerald-200'
              : 'bg-rose-50 text-rose-900 border border-rose-200'
          }`}
        >
          {feedback.type === 'loading' && <Loader2 className="w-4 h-4 animate-spin text-blue-700 shrink-0" />}
          {feedback.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />}
          {feedback.type === 'error' && <AlertCircle className="w-4 h-4 text-rose-700 shrink-0" />}
          <span>{feedback.message}</span>
        </div>
      )}

      {/* Mode Navigation Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 p-2 rounded-lg border border-slate-200">
        <div className="flex items-center gap-1">
          <button
            onClick={() => setViewMode('cover_sheet')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold cursor-pointer transition-colors flex items-center gap-1.5 ${
              viewMode === 'cover_sheet'
                ? 'bg-white text-blue-900 shadow-2xs border border-blue-200 font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            Folha A4 com 7 Capas ({totalCoverPages} folhas para 29 talões)
          </button>

          <button
            onClick={() => setViewMode('single_cover')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold cursor-pointer transition-colors flex items-center gap-1.5 ${
              viewMode === 'single_cover'
                ? 'bg-white text-blue-900 shadow-2xs border border-blue-200 font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            Capa Individual do Talão
          </button>

          <button
            onClick={() => setViewMode('all_covers')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold cursor-pointer transition-colors flex items-center gap-1.5 ${
              viewMode === 'all_covers'
                ? 'bg-white text-blue-900 shadow-2xs border border-blue-200 font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            Ver Todas as {totalCoverPages} Folhas de Capas
          </button>
        </div>

        {/* Dynamic Controls based on view mode */}
        {viewMode === 'cover_sheet' && (
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5">
              <span className="text-xs text-slate-500 font-medium">Folha:</span>
              <button
                onClick={() => setCurrentCoverPage((p) => Math.max(1, p - 1))}
                disabled={currentCoverPage <= 1}
                className="p-1 rounded border border-slate-200 text-slate-600 hover:bg-slate-100 disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed"
                title="Folha anterior"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <span className="text-xs font-bold px-2.5 py-1 bg-white border border-slate-200 rounded text-slate-800">
                {currentCoverPage} de {totalCoverPages}
              </span>
              <button
                onClick={() => setCurrentCoverPage((p) => Math.min(totalCoverPages, p + 1))}
                disabled={currentCoverPage >= totalCoverPages}
                className="p-1 rounded border border-slate-200 text-slate-600 hover:bg-slate-100 disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed"
                title="Próxima folha"
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <button
              onClick={handleDownloadSheet}
              disabled={downloading}
              className="inline-flex items-center gap-1 px-2.5 py-1 bg-blue-50 text-blue-800 hover:bg-blue-100 border border-blue-200 rounded text-xs font-semibold cursor-pointer"
            >
              <Download className="w-3 h-3 text-blue-700" />
              Baixar Pág {currentCoverPage} (PNG)
            </button>
          </div>
        )}

        {viewMode === 'single_cover' && (
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 font-medium">Talão:</span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setCurrentBooklet((b) => Math.max(1, b - 1))}
                disabled={currentBooklet <= 1}
                className="p-1 rounded border border-slate-200 text-slate-600 hover:bg-slate-100 disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed"
                title="Talão anterior"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <select
                value={currentBooklet}
                onChange={(e) => setCurrentBooklet(Number(e.target.value))}
                className="text-xs font-bold py-1 px-2 border border-slate-300 rounded bg-white text-slate-800 outline-none"
              >
                {Array.from({ length: totalBooklets }, (_, i) => i + 1).map((idx) => (
                  <option key={idx} value={idx}>
                    Talão {String(idx).padStart(2, '0')}: {getBookletLabel(idx, itemsPerBooklet, config.startNumber, config.endNumber, config.digits)}
                  </option>
                ))}
              </select>
              <button
                onClick={() => setCurrentBooklet((b) => Math.min(totalBooklets, b + 1))}
                disabled={currentBooklet >= totalBooklets}
                className="p-1 rounded border border-slate-200 text-slate-600 hover:bg-slate-100 disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed"
                title="Próximo talão"
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
            <button
              onClick={handleDownloadSingle}
              disabled={downloading}
              className="inline-flex items-center gap-1 px-2.5 py-1 bg-blue-50 text-blue-800 hover:bg-blue-100 border border-blue-200 rounded text-xs font-semibold cursor-pointer"
            >
              <Download className="w-3 h-3 text-blue-700" />
              Baixar Capa (PNG)
            </button>
          </div>
        )}
      </div>

      {/* Main Preview Container: COVER SHEET VIEW (Default) */}
      {viewMode === 'cover_sheet' && (
        <div className="space-y-3">
          <div className="text-center text-xs text-slate-500">
            Folha de Capas <strong>{currentCoverPage}</strong> de <strong>{totalCoverPages}</strong> (7 capas por folha A4 com as numerações dos talões)
          </div>

          <div className="bg-slate-100 p-6 rounded-xl border border-slate-200 flex justify-center overflow-x-auto">
            <div
              ref={sheetCoverRef}
              className="bg-white shadow-xl ring-1 ring-slate-900/5"
            >
              <CarneCoverSheet
                pageNumber={currentCoverPage}
                config={config}
                itemsPerPage={itemsPerBooklet}
              />
            </div>
          </div>
        </div>
      )}

      {/* SINGLE COVER VIEW */}
      {viewMode === 'single_cover' && (
        <div className="space-y-3">
          <div className="text-center text-xs text-slate-500">
            Exibindo a capa do <strong>Talão {String(currentBooklet).padStart(2, '0')}</strong> — Numeração:{' '}
            <strong className="text-rose-700 font-mono text-sm">{currentLabel}</strong>
          </div>

          <div className="bg-slate-100 p-6 rounded-xl border border-slate-200 flex justify-center overflow-x-auto">
            <div
              ref={singleCoverRef}
              className="bg-white rounded-lg shadow-md border border-amber-300 w-full max-w-4xl overflow-hidden"
            >
              <CarneCoverArt
                config={config}
                bookletIndex={currentBooklet}
                className="w-full"
              />
            </div>
          </div>
        </div>
      )}

      {/* ALL COVERS VIEW (Interactive Scroll + Print ready) */}
      {viewMode === 'all_covers' && (
        <div className="space-y-6">
          <div className="no-print bg-amber-50 border border-amber-200 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-amber-900">
            <div>
              <p className="font-bold text-amber-950">
                Todas as {totalCoverPages} Folhas de Capas dos 29 Talões (001 a 200)
              </p>
              <p className="text-amber-800 mt-0.5">
                Você pode baixar todas as 5 folhas reunidas em um único arquivo PDF ou imprimir diretamente pelo navegador.
              </p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={handleDownloadAllCoversPdf}
                disabled={downloading}
                className="px-3.5 py-2 bg-blue-700 hover:bg-blue-800 text-white rounded-lg font-bold shadow-xs cursor-pointer flex items-center gap-1.5"
              >
                <FileDown className="w-3.5 h-3.5 text-amber-300" />
                Baixar Todas em PDF
              </button>
              <button
                onClick={handleDownloadAllCoversZip}
                disabled={downloading}
                className="px-3 py-2 bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 rounded-lg font-semibold shadow-2xs cursor-pointer flex items-center gap-1.5"
              >
                <FolderArchive className="w-3.5 h-3.5 text-slate-600" />
                Baixar ZIP
              </button>
              <button
                onClick={() => window.print()}
                className="px-3 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg font-bold shadow-xs cursor-pointer flex items-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5 text-amber-300" />
                Imprimir
              </button>
            </div>
          </div>

          <div className="print-container flex flex-col items-center gap-8">
            {Array.from({ length: totalCoverPages }, (_, idx) => (
              <div key={idx + 1} className="print-page-wrapper bg-white shadow-lg ring-1 ring-slate-900/5 print:shadow-none print:ring-0">
                <CarneCoverSheet
                  pageNumber={idx + 1}
                  config={config}
                  itemsPerPage={itemsPerBooklet}
                />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Hidden offscreen container with all 5 cover sheets for fast PDF and ZIP batch generation */}
      <div
        ref={allCoversHiddenRef}
        className="no-print"
        style={{
          position: 'fixed',
          left: '-9999px',
          top: 0,
          width: '210mm',
          opacity: 0,
          pointerEvents: 'none',
        }}
        aria-hidden="true"
      >
        {Array.from({ length: totalCoverPages }, (_, idx) => (
          <div key={idx + 1} className="hidden-cover-page bg-white mb-4" style={{ width: '210mm', height: '297mm' }}>
            <CarneCoverSheet
              pageNumber={idx + 1}
              config={config}
              itemsPerPage={itemsPerBooklet}
            />
          </div>
        ))}
      </div>

      {/* Hidden offscreen container for single cover capture when on cover_sheet view */}
      {viewMode !== 'single_cover' && (
        <div
          className="no-print"
          style={{
            position: 'fixed',
            left: '-9999px',
            top: 0,
            opacity: 0,
            pointerEvents: 'none',
          }}
          aria-hidden="true"
        >
          <div ref={singleCoverRef} className="bg-white w-[800px]">
            <CarneCoverArt
              config={config}
              bookletIndex={currentBooklet}
              className="w-full"
            />
          </div>
        </div>
      )}
    </div>
  );
};
