import React from 'react';
import { CarneConfig } from '../types';
import { CarneTicket } from './CarneTicket';

interface CarnePageProps {
  pageNumber: number;
  config: CarneConfig;
  itemsPerPage?: number;
}

export const CarnePage: React.FC<CarnePageProps> = ({
  pageNumber,
  config,
  itemsPerPage,
}) => {
  const effectiveItemsPerPage = itemsPerPage || config.itemsPerPage || 7;
  // Calculate numbers for this page
  const startNum = (pageNumber - 1) * effectiveItemsPerPage + config.startNumber;
  const numbers: number[] = [];

  for (let i = 0; i < effectiveItemsPerPage; i++) {
    const num = startNum + i;
    if (num <= config.endNumber) {
      numbers.push(num);
    }
  }

  const totalPages = Math.ceil((config.endNumber - config.startNumber + 1) / effectiveItemsPerPage);
  const isCompact = effectiveItemsPerPage >= 7;

  return (
    <div
      className="print-page bg-white text-slate-900 mx-auto shadow-md print:shadow-none p-2 print:p-0 flex flex-col justify-between"
      style={{
        width: '210mm',
        height: '297mm',
        maxHeight: '297mm',
        boxSizing: 'border-box',
      }}
    >
      {/* Informação superior da folha (oculta na impressão para encaixar perfeitamente) */}
      <div className="no-print flex justify-between items-center text-[8px] text-slate-400 border-b border-slate-200 pb-0.5 mb-1">
        <div className="flex items-center gap-2">
          <span className="font-bold text-slate-600 uppercase">
            {config.chapelName || config.parishName}
          </span>
          <span>·</span>
          <span>{config.eventName}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="font-mono font-medium text-slate-500">
            Página {pageNumber} de {totalPages} (Nº {String(numbers[0] || 0).padStart(config.digits, '0')} a Nº {String(numbers[numbers.length - 1] || 0).padStart(config.digits, '0')})
          </span>
        </div>
      </div>

      {/* Carnês encaixados perfeitamente na folha sem linhas de corte intermediárias */}
      <div className="flex-1 flex flex-col h-full overflow-hidden border border-slate-300 print:border-none">
        {numbers.map((num, idx) => (
          <div
            key={num}
            className={`flex-1 min-h-0 flex flex-col justify-stretch ${
              idx < numbers.length - 1 ? 'border-b border-dashed border-slate-300' : ''
            }`}
          >
            <CarneTicket
              number={num}
              config={config}
              isCompact={isCompact}
              className="h-full flex-1 border-none shadow-none rounded-none"
            />
          </div>
        ))}
      </div>

      {/* Rodapé informativo (oculto na impressão para não roubar espaço dos carnês) */}
      <div className="no-print text-[7.5px] text-slate-400 flex justify-between items-center border-t border-slate-200 pt-0.5 mt-1">
        <span>* Layout A4 ajustado: {effectiveItemsPerPage} carnês por folha encaixados sem linhas de corte</span>
        <span className="font-semibold text-slate-600">
          Valor: R$ {config.value} cada
        </span>
      </div>
    </div>
  );
};
