import React from 'react';
import { CarneConfig } from '../types';
import {
  CapelaHeaderBanner,
  MedalhaMilagrosaFrente,
  NossaSenhoraFigure,
  CrismaEspiritoSanto,
  BlueFloralBorder,
} from './ReligiousArt';
import { IniciacaoCristaIcon } from './IniciacaoCristaIcon';
import { CarneCoverArt } from './CarneCoverArt';
import { PixQrCode } from './PixQrCode';
import { ReligiousEmblem } from './ReligiousEmblem';

interface CarneTicketProps {
  number: number;
  config: CarneConfig;
  className?: string;
  isSinglePreview?: boolean;
  isCompact?: boolean;
}

export const CarneTicket: React.FC<CarneTicketProps> = ({
  number,
  config,
  className = '',
  isSinglePreview = false,
  isCompact = false,
}) => {
  const formattedNumber = String(number).padStart(config.digits, '0');

  // Helper to render the religious central emblem
  const renderEmblem = (size = 46) => {
    return (
      <ReligiousEmblem
        type={config.emblemType}
        customImageUrl={config.customImageUrl}
        size={size}
        isCompact={isCompact}
        showLabel={!isCompact}
      />
    );
  };

  // Helper to render the watermark
  const renderWatermark = () => {
    return (
      <div className="opacity-15 pointer-events-none scale-125">
        <ReligiousEmblem
          type={config.emblemType}
          customImageUrl={config.customImageUrl}
          size={64}
          isCompact={false}
          showLabel={false}
        />
      </div>
    );
  };

  // Renders the Photo 1 + Photo 2 banner-topped ticket
  if (config.style === 'banner_top') {
    return (
      <div
        className={`carne-ticket relative bg-white overflow-hidden text-slate-800 flex flex-col justify-between ${className}`}
        style={{
          height: isSinglePreview ? '56mm' : '100%',
          minHeight: isSinglePreview ? '56mm' : '0',
          boxSizing: 'border-box',
        }}
      >
        {/* Top Header Banner matching selected cover art */}
        <CarneCoverArt
          config={config}
          coverStyle={config.coverStyle}
          variant="horizontal_banner"
          className="h-14 shrink-0"
        />

        {/* Bottom Body: Left stub (canhoto) + Right ticket (comprovante) */}
        <div className="flex-1 flex overflow-hidden">
          {/* Canhoto (Stub) */}
          <div className="w-[30%] border-r border-dashed border-slate-400 p-2 flex flex-col justify-between bg-sky-50/30 relative">
            <div className="flex items-center justify-between">
              <span className="text-[7.5px] uppercase font-bold tracking-wider text-slate-600">
                {config.stubLabel || 'Via Capela'}
              </span>
              <span className="text-[10px] font-black text-rose-700 tracking-wider">
                Nº {formattedNumber}
              </span>
            </div>

            <div className="my-0.5">
              <span className="text-[10px] font-black tracking-tight text-slate-900 block">
                VALOR R$ {config.value}
              </span>
            </div>

            <div className="space-y-1 text-[7px] text-slate-700">
              <div>
                <span className="font-semibold block">{config.fieldPaymentDate || 'DATA DO PAGAMENTO'}:</span>
                <span className="block border-b border-slate-400 w-full tracking-widest text-slate-400">
                  ____ / ____ / ________
                </span>
              </div>
              <div>
                <span className="font-semibold block">{config.fieldReceivedBy || 'RECEBIDO POR'}:</span>
                <span className="block border-b border-slate-400 w-full text-transparent select-none">
                  ___________________________
                </span>
              </div>
              {config.showCrismandoField && (
                <div>
                  <span className="font-semibold block">{config.fieldCandidate || 'CRISMANDO(A)'}:</span>
                  <span className="block border-b border-slate-400 w-full text-transparent select-none">
                    ___________________________
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Dotted Tear Line with Scissors icon */}
          <div className="relative flex flex-col justify-center items-center -ml-[9px] z-10 pointer-events-none">
            <span className="text-[8px] text-slate-400 bg-white px-0.5 transform -rotate-90">
              ✂
            </span>
          </div>

          {/* Comprovante do Fiel */}
          <div className="flex-1 p-2 flex items-center justify-between relative bg-white">
            {/* Watermark art */}
            <div className="absolute right-32 top-1 pointer-events-none">
              {renderWatermark()}
            </div>

            {/* Left section of receipt: Details & Payment fields */}
            <div className="flex-1 pr-2 flex flex-col justify-between h-full">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-[9.5px] font-bold text-slate-900 uppercase tracking-tight">
                    {config.eventName}
                  </h4>
                  <p className="text-[8px] font-medium text-blue-900 uppercase">
                    {config.chapelName || config.parishName}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[8px] font-bold uppercase tracking-wider text-slate-500 block">
                    Nº
                  </span>
                  <span className="text-sm font-black text-rose-700 leading-none">
                    {formattedNumber}
                  </span>
                </div>
              </div>

              <div className="my-1 flex items-center justify-between gap-2">
                <span className="text-xs font-black text-slate-900 shrink-0">
                  VALOR R$ {config.value}
                </span>
                {config.pixKey && (
                  <div className="inline-flex items-center gap-1.5 bg-amber-100/90 border border-amber-400 text-slate-900 px-2 py-0.5 rounded shadow-xs">
                    <span className="text-[9px] font-black text-slate-800 tracking-wider uppercase">PIX:</span>
                    <span className="text-[10.5px] font-black text-rose-700 font-mono select-all">
                      {config.pixKey}
                    </span>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2 text-[7.5px] text-slate-700">
                <div>
                  <span className="font-semibold block">DATA DO PAGAMENTO:</span>
                  <span className="block border-b border-slate-400 tracking-widest text-slate-400 pt-0.5">
                    ____ / ____ / ________
                  </span>
                </div>
                <div>
                  <span className="font-semibold block">RECEBIDO POR:</span>
                  <span className="block border-b border-slate-400 pt-0.5 text-transparent select-none">
                    ______________________
                  </span>
                </div>
              </div>
            </div>

            {/* Center: Religious Emblem */}
            <div className="flex flex-col items-center justify-center px-2 border-l border-slate-100">
              {renderEmblem(44)}
            </div>

            {/* Right: Pix QR Code (only if showPix is true) */}
            {config.showPix && (
              <div className="shrink-0 pl-2 border-l border-slate-200">
                <PixQrCode
                  value={config.pixKey}
                  amount={config.value}
                  size={48}
                  bankName={config.bankName}
                  parishName={config.parishName}
                  phoneContact={config.phoneContact}
                />
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Renders Photo 2 exact layout (The authentic talonário / carnê ticket format)
  return (
    <div
      className={`carne-ticket relative bg-white overflow-hidden text-slate-800 flex ${className}`}
      style={{
        height: isSinglePreview ? '56mm' : '100%',
        minHeight: isSinglePreview ? '56mm' : '0',
        boxSizing: 'border-box',
      }}
    >
      {/* LEFT SECTION: CANHOTO / TALÃO (Via da Capela) */}
      <div className={`w-[30%] border-r border-dashed border-slate-400 ${isCompact ? 'p-1.5' : 'p-2.5'} flex flex-col justify-between bg-slate-50/50 relative`}>
        <div className={`flex items-center justify-between border-b border-slate-200 ${isCompact ? 'pb-0.5' : 'pb-1'}`}>
          <span className="text-[7.5px] font-bold text-slate-600 uppercase tracking-wider">
            {config.stubLabel || 'VIA CONTROLE'}
          </span>
          <span className={`${isCompact ? 'text-[10px]' : 'text-[11px]'} font-black text-rose-700 font-mono`}>
            Nº {formattedNumber}
          </span>
        </div>

        <div className={isCompact ? 'my-0.5' : 'my-1'}>
          <div className={`${isCompact ? 'text-[10.5px]' : 'text-[12px]'} font-black tracking-tight text-slate-900`}>
            VALOR R$ {config.value}
          </div>
          {config.pixKey && (
            <div className="bg-amber-50 border border-amber-200 px-1 py-0.5 rounded mt-0.5">
              <span className="text-[7px] font-black text-slate-700 uppercase">PIX: </span>
              <span className="text-[7.5px] font-black text-rose-700 font-mono tracking-tight">{config.pixKey}</span>
            </div>
          )}
        </div>

        <div className={`${isCompact ? 'space-y-1 text-[7px]' : 'space-y-1.5 text-[8px]'} text-slate-700`}>
          <div>
            <div className="font-semibold text-slate-600 text-[6.5px] uppercase tracking-wider">
              {config.fieldPaymentDate || 'DATA DO PAGAMENTO'}
            </div>
            <div className="border-b border-slate-400 text-slate-500 tracking-widest pt-0.5 font-mono">
              ____ / ____ / ________
            </div>
          </div>
          <div>
            <div className="font-semibold text-slate-600 text-[6.5px] uppercase tracking-wider">
              {config.fieldReceivedBy || 'RECEBIDO POR'}
            </div>
            <div className={`border-b border-slate-400 ${isCompact ? 'h-2.5' : 'h-3'}`}></div>
          </div>
          {config.showCrismandoField && (
            <div>
              <div className="font-semibold text-slate-600 text-[6.5px] uppercase tracking-wider">
                {config.fieldCandidate || 'CRISMANDO(A)'}
              </div>
              <div className={`border-b border-slate-400 ${isCompact ? 'h-2.5' : 'h-3'}`}></div>
            </div>
          )}
        </div>
      </div>

      {/* PICOTE / PERFORATION INDICATOR */}
      <div className="relative flex flex-col justify-around items-center -ml-[9px] z-10 pointer-events-none">
        <div className="bg-white px-0.5 text-[7px] text-slate-400 transform -rotate-90">
          ✂
        </div>
      </div>

      {/* RIGHT SECTION: COMPROVANTE (Via do Fiel) */}
      <div className={`flex-1 ${isCompact ? 'p-1.5' : 'p-2.5'} flex flex-col justify-between relative bg-white`}>
        {/* Soft watermark */}
        <div className="absolute right-36 top-1/2 -translate-y-1/2 pointer-events-none">
          {renderWatermark()}
        </div>

        {/* Top bar: Title and Number */}
        <div className={`flex items-start justify-between border-b border-slate-100 ${isCompact ? 'pb-0.5' : 'pb-1'}`}>
          <div className="flex-1 pr-2">
            <h3 className={`${isCompact ? 'text-[9.5px]' : 'text-[11px]'} font-extrabold text-blue-950 uppercase tracking-tight leading-tight`}>
              {config.eventName}
            </h3>
            <p className={`${isCompact ? 'text-[7.5px]' : 'text-[8.5px]'} font-semibold text-blue-900 uppercase`}>
              {config.chapelName || config.parishName}
            </p>
          </div>

          <div className="text-right shrink-0">
            <span className="text-[7px] uppercase font-bold text-slate-400 tracking-widest block">
              NÚMERO
            </span>
            <div className={`inline-block bg-rose-50 border border-rose-200 text-rose-700 ${isCompact ? 'px-1 py-0 text-xs' : 'px-1.5 py-0.2 text-sm'} rounded font-black tracking-wider shadow-2xs font-mono`}>
              Nº {formattedNumber}
            </div>
          </div>
        </div>

        {/* Middle row: Values, Payment lines, Central Seal, and Pix QR (optional) */}
        <div className={`flex items-center justify-between ${isCompact ? 'gap-2 my-0.5' : 'gap-3 my-auto'}`}>
          {/* Column 1: Payment info */}
          <div className={`flex-1 ${isCompact ? 'space-y-1' : 'space-y-1.5'}`}>
            <div className="flex items-center justify-between gap-2">
              <div className={`${isCompact ? 'text-xs' : 'text-sm'} font-black text-slate-900 tracking-tight shrink-0`}>
                VALOR R$ {config.value}
              </div>
              {config.pixKey && (
                <div className={`inline-flex items-center gap-1.5 bg-amber-100/90 border border-amber-400 text-slate-900 ${isCompact ? 'px-2 py-0.5' : 'px-2.5 py-1'} rounded shadow-xs`}>
                  <span className={`${isCompact ? 'text-[9px]' : 'text-[10px]'} font-black text-slate-800 tracking-wider uppercase`}>
                    PIX:
                  </span>
                  <span className={`${isCompact ? 'text-[10.5px]' : 'text-[12px]'} font-black text-rose-700 tracking-tight font-mono select-all`}>
                    {config.pixKey}
                  </span>
                </div>
              )}
            </div>

            <div className={`grid grid-cols-2 ${isCompact ? 'gap-1.5 text-[7px]' : 'gap-3 text-[8px]'}`}>
              <div>
                <span className="font-semibold text-slate-600 text-[6.5px] uppercase tracking-wider block">
                  {config.fieldPaymentDate || 'DATA DO PAGAMENTO'}
                </span>
                <span className="block border-b border-slate-400 text-slate-500 tracking-widest pt-0.5 font-mono">
                  ____ / ____ / ________
                </span>
              </div>
              <div>
                <span className="font-semibold text-slate-600 text-[6.5px] uppercase tracking-wider block">
                  {config.fieldReceivedBy || 'RECEBIDO POR'}
                </span>
                <span className={`block border-b border-slate-400 ${isCompact ? 'h-2.5' : 'h-3'}`}></span>
              </div>
            </div>

            {config.showCrismandoField && (
              <div className="pt-0.5">
                <span className="font-semibold text-slate-600 text-[6.5px] uppercase tracking-wider block">
                  {config.fieldCandidate || 'CRISMANDO(A)'}
                </span>
                <span className={`block border-b border-slate-400 ${isCompact ? 'h-2.5' : 'h-3'}`}></span>
              </div>
            )}
          </div>

          {/* Column 2: Central Religious Stamp / Emblem */}
          <div className={`flex flex-col items-center justify-center ${isCompact ? 'px-2 py-0.5' : 'px-3 py-1'} border-l border-slate-100 text-center shrink-0`}>
            {renderEmblem(isCompact ? 36 : 56)}
          </div>

          {/* Column 3: PIX QR CODE (Only if enabled) */}
          {config.showPix && (
            <div className="shrink-0 flex items-center justify-center pl-1 border-l border-slate-100">
              <PixQrCode
                value={config.pixKey}
                amount={config.value}
                size={isCompact ? 40 : 50}
                bankName={config.bankName}
                parishName={config.parishName}
                phoneContact={config.phoneContact}
              />
            </div>
          )}
        </div>

        {/* Bottom footer text */}
        <div className={`${isCompact ? 'text-[6.5px]' : 'text-[7.5px]'} text-slate-500 border-t border-slate-100 pt-0.5 flex justify-between items-center`}>
          <span>
            {config.footerNotice || '* Guarde este comprovante para a Pastoral do Crisma.'} {config.pixKey && <>· Chave PIX: <strong className="text-slate-900 font-mono font-black text-[8px] bg-amber-50 px-1 py-0.2 rounded border border-amber-200">{config.pixKey}</strong></>}
          </span>
          <span className="font-semibold text-blue-900">{config.footerGreeting || 'Paz e Bem!'}</span>
        </div>
      </div>
    </div>
  );
};
