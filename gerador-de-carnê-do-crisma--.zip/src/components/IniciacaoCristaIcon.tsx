import React from 'react';

interface IniciacaoCristaIconProps {
  className?: string;
  size?: number;
  showText?: boolean;
}

export const IniciacaoCristaIcon: React.FC<IniciacaoCristaIconProps> = ({
  className = '',
  size = 64,
  showText = true,
}) => {
  return (
    <svg
      width={size}
      height={size * 1.25}
      viewBox="0 0 200 250"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`select-none ${className}`}
    >
      <defs>
        {/* Fire Ribbon Gradient 1 */}
        <linearGradient id="flameGradGold" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#fef08a" />
          <stop offset="25%" stopColor="#facc15" />
          <stop offset="60%" stopColor="#d97706" />
          <stop offset="100%" stopColor="#991b1b" />
        </linearGradient>

        {/* Textured Golden Sun Disk */}
        <radialGradient id="sunGrad" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#fef9c3" />
          <stop offset="50%" stopColor="#eab308" />
          <stop offset="85%" stopColor="#ca8a04" />
          <stop offset="100%" stopColor="#92400e" />
        </radialGradient>

        {/* Dove shading */}
        <linearGradient id="doveShade" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="70%" stopColor="#f1f5f9" />
          <stop offset="100%" stopColor="#cbd5e1" />
        </linearGradient>

        {/* Flame border stroke gradient */}
        <linearGradient id="flameBorder" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#7f1d1d" />
          <stop offset="50%" stopColor="#991b1b" />
          <stop offset="100%" stopColor="#450a0a" />
        </linearGradient>
      </defs>

      {/* 1. FLAME OF THE HOLY SPIRIT (Chamas de Pentecostes) */}
      <g id="flames">
        {/* Outer Left Flame Ribbon */}
        <path
          d="M84,15 C70,40 35,75 35,120 C35,160 65,195 80,210 C70,185 52,150 54,120 C56,90 75,50 84,15 Z"
          fill="url(#flameGradGold)"
          stroke="url(#flameBorder)"
          strokeWidth="2.5"
        />

        {/* Outer Right Flame Ribbon */}
        <path
          d="M84,15 C95,45 125,75 125,115 C125,145 110,175 95,195 C112,170 112,130 108,105 C102,70 90,40 84,15 Z"
          fill="url(#flameGradGold)"
          stroke="url(#flameBorder)"
          strokeWidth="2.5"
        />

        {/* Central Rising Flame Tongue */}
        <path
          d="M84,12 C88,35 92,60 90,85 C84,65 80,45 84,12 Z"
          fill="#dc2626"
        />

        {/* Inner Curved Flame Ribbons (Left) */}
        <path
          d="M84,20 C76,55 58,90 60,135 C62,170 75,200 78,215 C68,185 64,150 67,125 C70,95 80,55 84,20 Z"
          fill="url(#flameGradGold)"
          stroke="url(#flameBorder)"
          strokeWidth="1.8"
        />

        {/* Flame Tail descending at bottom */}
        <path
          d="M78,210 C74,225 70,240 68,248 C72,238 78,225 82,212 Z"
          fill="#b91c1c"
        />
        <path
          d="M85,195 C85,215 82,235 80,245 C86,230 89,215 88,198 Z"
          fill="#ea580c"
        />
      </g>

      {/* 2. GOLDEN SUN CIRCLE */}
      <g id="sun">
        <circle cx="86" cy="115" r="35" fill="url(#sunGrad)" opacity="0.95" />
        <circle cx="86" cy="115" r="35" stroke="#854d0e" strokeWidth="1" opacity="0.6" />
        {/* Subtle radial brush texture lines */}
        <circle cx="86" cy="115" r="28" stroke="#fef08a" strokeWidth="0.8" strokeDasharray="3 3" opacity="0.5" />
      </g>

      {/* 3. BLACK LATIN CROSS */}
      <g id="cross">
        {/* Vertical beam */}
        <rect x="83.5" y="55" width="5.5" height="110" rx="0.8" fill="#18181b" />
        {/* Horizontal crossbar */}
        <rect x="52" y="96" width="70" height="5.5" rx="0.8" fill="#18181b" />
      </g>

      {/* 4. DOVE OF THE HOLY SPIRIT (Pomba Branca em voo ascendente) */}
      <g id="dove" transform="translate(10, 8)">
        {/* Dove Body & Underwing Soft Shadow */}
        <path
          d="M45,130 C40,118 45,108 55,102 C65,96 75,98 85,92 C95,86 102,92 108,98 C115,105 108,118 95,122 C82,126 65,138 52,142 C46,144 42,138 45,130 Z"
          fill="#e2e8f0"
        />

        {/* Tail Feathers (Cauda em leque) */}
        <g fill="#ffffff" stroke="#1e293b" strokeWidth="1.2" strokeLinejoin="round">
          <path d="M48,125 C40,122 36,128 35,135 C38,138 45,136 50,132 Z" fill="url(#doveShade)" />
          <path d="M49,128 C42,132 38,140 40,147 C44,146 50,140 52,134 Z" fill="url(#doveShade)" />
          <path d="M51,132 C46,140 44,148 48,154 C52,151 55,144 56,137 Z" fill="url(#doveShade)" />
          <path d="M54,135 C52,145 52,152 56,157 C60,152 61,145 60,138 Z" fill="url(#doveShade)" />
        </g>

        {/* Left Wing (Asa Esquerda / Superior com penas detalhadas) */}
        <g stroke="#1e293b" strokeWidth="1.2" strokeLinejoin="round">
          {/* Main wing blade */}
          <path
            d="M65,105 C60,85 70,60 88,48 C95,45 105,48 102,58 C96,75 88,95 82,112 Z"
            fill="url(#doveShade)"
          />
          {/* Detailed Primary Feathers */}
          <path d="M88,48 C85,55 82,65 80,78" fill="none" strokeWidth="0.8" />
          <path d="M92,50 C89,58 86,68 84,82" fill="none" strokeWidth="0.8" />
          <path d="M96,53 C93,62 90,73 88,86" fill="none" strokeWidth="0.8" />
          <path d="M100,58 C96,68 93,80 91,92" fill="none" strokeWidth="0.8" />
          <path d="M102,66 C98,75 95,86 93,98" fill="none" strokeWidth="0.8" />

          {/* Feather notches on leading edge */}
          <path d="M88,48 L87,54 L85,55 L84,62 L81,64 L80,72 L77,74 L75,85" fill="none" strokeWidth="1" />
        </g>

        {/* Right Wing (Asa Direita / Horizontal aberta para o lado) */}
        <g stroke="#1e293b" strokeWidth="1.2" strokeLinejoin="round">
          <path
            d="M85,115 C95,118 115,120 135,115 C142,114 140,118 132,122 C115,130 95,128 80,122 Z"
            fill="url(#doveShade)"
          />
          {/* Wingtip feather flick */}
          <path d="M135,115 C142,112 144,116 138,120" fill="url(#doveShade)" />
          {/* Feathers ribs */}
          <path d="M100,118 C110,121 122,120 128,118" fill="none" strokeWidth="0.7" />
          <path d="M95,120 C105,124 116,123 122,122" fill="none" strokeWidth="0.7" />
        </g>

        {/* Dove Head, Breast & Beak */}
        <g stroke="#1e293b" strokeWidth="1.2">
          {/* Head & Neck */}
          <path
            d="M82,108 C84,100 92,94 100,94 C108,94 114,99 113,105 C112,110 106,115 98,118 C90,120 84,115 82,108 Z"
            fill="#ffffff"
          />
          {/* Beak (Bico voltado à direita) */}
          <polygon points="113,101 118,103 113,105" fill="#f59e0b" stroke="#78350f" strokeWidth="0.8" />
          {/* Eye */}
          <circle cx="106" cy="100" r="1.4" fill="#0f172a" />
          <circle cx="106.3" cy="99.7" r="0.5" fill="#ffffff" />
        </g>
      </g>

      {/* 5. TEXT: "Iniciação Cristã" (matching the exact typography from the image) */}
      {showText && (
        <g id="text-iniciacao-crista" transform="translate(100, 160)">
          {/* Drop shadow layer */}
          <text
            x="2"
            y="2"
            fontFamily="'Cinzel', 'Playfair Display', Georgia, serif"
            fontSize="15"
            fontWeight="bold"
            fill="#475569"
            letterSpacing="0.5"
          >
            Iniciação
          </text>
          <text
            x="10"
            y="20"
            fontFamily="'Cinzel', 'Playfair Display', Georgia, serif"
            fontSize="15"
            fontWeight="bold"
            fill="#475569"
            letterSpacing="0.5"
          >
            Cristã
          </text>

          {/* Main Gold Inscription */}
          <text
            x="0"
            y="0"
            fontFamily="'Cinzel', 'Playfair Display', Georgia, serif"
            fontSize="15"
            fontWeight="bold"
            fill="#eab308"
            stroke="#a16207"
            strokeWidth="0.6"
            letterSpacing="0.5"
          >
            Iniciação
          </text>
          <text
            x="8"
            y="18"
            fontFamily="'Cinzel', 'Playfair Display', Georgia, serif"
            fontSize="15"
            fontWeight="bold"
            fill="#eab308"
            stroke="#a16207"
            strokeWidth="0.6"
            letterSpacing="0.5"
          >
            Cristã
          </text>
        </g>
      )}
    </svg>
  );
};
