import React, { useRef, useState } from 'react';
import { EmblemType } from '../types';
import { ReligiousEmblem, EMBLEM_OPTIONS } from './ReligiousEmblem';
import { downloadElementAsImage } from '../utils/exportImage';
import { Download, Flame, Upload, Image, Check } from 'lucide-react';

interface IniciacaoCristaPreviewProps {
  customImageUrl?: string;
  onCustomImageChange: (url?: string) => void;
  selectedEmblem: EmblemType;
  onSelectEmblem: (type: EmblemType) => void;
}

export const IniciacaoCristaPreview: React.FC<IniciacaoCristaPreviewProps> = ({
  customImageUrl,
  onCustomImageChange,
  selectedEmblem,
  onSelectEmblem,
}) => {
  const iconRef = useRef<HTMLDivElement>(null);
  const [downloading, setDownloading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDownload = async () => {
    if (!iconRef.current) return;
    try {
      setDownloading(true);
      await downloadElementAsImage(iconRef.current, `simbolo-${selectedEmblem}.png`, 4);
    } catch (e) {
      console.error(e);
    } finally {
      setDownloading(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        onCustomImageChange(result);
        onSelectEmblem('custom');
      };
      reader.readAsDataURL(file);
    }
  };

  const selectedOpt = EMBLEM_OPTIONS.find((o) => o.id === selectedEmblem) || EMBLEM_OPTIONS[0];

  return (
    <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-6 space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        <div>
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Flame className="w-5 h-5 text-amber-500" />
            Galeria de Símbolos Sacros & Emblemas dos Carnês
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Escolha qualquer um dos símbolos litúrgicos abaixo para a sua cópia ou carregue uma imagem/logotipo da sua Paróquia.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept="image/*"
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer transition-colors"
          >
            <Upload className="w-3.5 h-3.5 text-slate-600" />
            Carregar Imagem Própria
          </button>

          <button
            onClick={handleDownload}
            disabled={downloading}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold shadow-xs cursor-pointer transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            {downloading ? 'Gerando...' : 'Baixar Símbolo em Alta Resolução (PNG)'}
          </button>
        </div>
      </div>

      {/* Grid of All Available Emblems */}
      <div className="space-y-2">
        <span className="text-xs font-bold text-slate-700">Selecione o símbolo aplicado nesta cópia:</span>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {EMBLEM_OPTIONS.map((opt) => {
            const isSelected = selectedEmblem === opt.id && !customImageUrl;

            return (
              <button
                key={opt.id}
                onClick={() => {
                  onCustomImageChange(undefined);
                  onSelectEmblem(opt.id);
                }}
                className={`p-2.5 rounded-xl border text-left flex items-center gap-2.5 transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-amber-100/90 border-amber-500 shadow-xs ring-2 ring-amber-400'
                    : 'bg-white border-slate-200 hover:border-amber-300 hover:bg-amber-50/40'
                }`}
              >
                <div className="w-8 h-9 shrink-0 flex items-center justify-center bg-slate-50 rounded border border-slate-100 p-0.5">
                  <ReligiousEmblem type={opt.id} size={24} isCompact={true} />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="font-extrabold text-[11px] text-slate-900 truncate">
                    {opt.title}
                  </div>
                  <div className="text-[9.5px] text-slate-500 truncate">
                    {opt.badge || opt.category}
                  </div>
                </div>
                {isSelected && <Check className="w-3.5 h-3.5 text-amber-700 shrink-0" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Side-by-side Showcase */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
        {/* Vector SVG Emblem Showcase */}
        <div className="bg-radial from-amber-50 to-slate-50 border border-amber-200/60 rounded-xl p-6 flex flex-col items-center justify-center text-center">
          <div ref={iconRef} className="p-4 bg-transparent flex items-center justify-center">
            <ReligiousEmblem
              type={selectedEmblem}
              customImageUrl={customImageUrl}
              size={130}
              showLabel={false}
            />
          </div>
          <h4 className="text-sm font-extrabold text-slate-900 mt-2">
            {customImageUrl ? 'Imagem Personalizada Carregada' : selectedOpt.title}
          </h4>
          <p className="text-xs text-slate-500 max-w-xs mt-0.5">
            {customImageUrl ? 'Exibida nos carnês e capas desta cópia.' : selectedOpt.subtitle}
          </p>
          <span className="text-[10px] font-bold text-amber-800 bg-amber-100 px-2.5 py-0.5 rounded-full mt-2">
            Arte Vetorial Ultra-Nítida para Impressão
          </span>
        </div>

        {/* Upload Custom Image Box */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-6 flex flex-col items-center justify-center text-center space-y-3">
          {customImageUrl ? (
            <div className="space-y-3 flex flex-col items-center">
              <div className="p-3 bg-white rounded-lg shadow-xs border border-slate-200">
                <img
                  src={customImageUrl}
                  alt="Imagem carregada"
                  className="max-h-44 object-contain"
                />
              </div>
              <p className="text-xs text-emerald-700 font-semibold flex items-center gap-1">
                <Check className="w-3.5 h-3.5" />
                Sua imagem está aplicada nos carnês desta cópia!
              </p>
              <button
                onClick={() => onCustomImageChange(undefined)}
                className="text-xs text-rose-600 hover:underline cursor-pointer"
              >
                Remover imagem e voltar aos símbolos oficiais
              </button>
            </div>
          ) : (
            <div className="space-y-2">
              <div className="w-12 h-12 rounded-full bg-slate-200 flex items-center justify-center mx-auto text-slate-500">
                <Image className="w-6 h-6" />
              </div>
              <p className="text-xs font-bold text-slate-700">
                Deseja usar o brasão ou logotipo da sua Paróquia?
              </p>
              <p className="text-[11px] text-slate-500 max-w-xs">
                Você pode carregar qualquer arquivo PNG ou JPG do seu computador para estampar no lugar do selo sacro.
              </p>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="mt-2 inline-flex items-center gap-1 px-3 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-md text-xs font-medium cursor-pointer"
              >
                <Upload className="w-3 h-3" />
                Selecionar arquivo de imagem
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
