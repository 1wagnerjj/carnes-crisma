import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';

interface PixQrCodeProps {
  value?: string; // Chave PIX (ex: email, telefone, cpf) ou payload completo
  amount?: string; // ex: "65,00"
  size?: number;
  bankName?: string;
  parishName?: string;
  phoneContact?: string;
  showDetails?: boolean;
}

/**
 * Generates official BR Code / EMVCo standard PIX payload
 * for direct scanning in any Brazilian banking app.
 */
function createPixPayload(key: string, name: string, city: string, amountStr: string): string {
  // If value is already a full BR Code (starts with 000201), use it directly
  if (key.startsWith('000201')) {
    return key;
  }

  const format = (id: string, val: string) => {
    const len = val.length.toString().padStart(2, '0');
    return `${id}${len}${val}`;
  };

  const cleanKey = key.trim();
  const cleanName = (name || 'PAROQUIA N S APRESENTACAO')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .slice(0, 25)
    .toUpperCase();
  const cleanCity = (city || 'RIO DE JANEIRO')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .slice(0, 15)
    .toUpperCase();

  const numAmount = parseFloat(amountStr.replace(',', '.'));
  const amountFormatted = isNaN(numAmount) || numAmount <= 0 ? '65.00' : numAmount.toFixed(2);

  const merchantAccount = format('00', 'br.gov.bcb.pix') + format('01', cleanKey);
  const additionalData = format('05', 'CRISMA');

  let raw =
    format('00', '01') +
    format('26', merchantAccount) +
    format('52', '0000') +
    format('53', '986') +
    format('54', amountFormatted) +
    format('58', 'BR') +
    format('59', cleanName) +
    format('60', cleanCity) +
    format('62', additionalData) +
    '6304';

  // CRC16-CCITT calculation
  let crc = 0xffff;
  for (let i = 0; i < raw.length; i++) {
    crc ^= raw.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      if ((crc & 0x8000) !== 0) {
        crc = (crc << 1) ^ 0x1021;
      } else {
        crc <<= 1;
      }
      crc &= 0xffff;
    }
  }
  const crcHex = crc.toString(16).toUpperCase().padStart(4, '0');
  return raw + crcHex;
}

export const PixQrCode: React.FC<PixQrCodeProps> = ({
  value = 'Icja.apresentacao@gmail.com',
  amount = '65,00',
  size = 54,
  bankName = 'PIX Bradesco',
  parishName = 'PARÓQUIA N S DA APRESENTAÇÃO',
  phoneContact = '(21) 97502-7607',
  showDetails = true,
}) => {
  const [dataUrl, setDataUrl] = useState<string>('');

  useEffect(() => {
    let isMounted = true;
    const finalPayload = createPixPayload(value, parishName, 'RIO DE JANEIRO', amount);

    QRCode.toDataURL(finalPayload, {
      width: size * 3,
      margin: 1,
      color: {
        dark: '#000000',
        light: '#ffffff',
      },
      errorCorrectionLevel: 'M',
    })
      .then((url) => {
        if (isMounted) setDataUrl(url);
      })
      .catch((err) => {
        console.error('Error generating QR code', err);
      });

    return () => {
      isMounted = false;
    };
  }, [value, amount, size, parishName]);

  return (
    <div className="flex flex-col items-center select-none text-center">
      {/* QR Code Container with subtle frame */}
      <div className="relative inline-block border border-slate-300 bg-white p-0.5 rounded-xs shadow-2xs">
        {dataUrl ? (
          <img
            src={dataUrl}
            alt={`QR Code PIX - ${value}`}
            style={{ width: `${size}px`, height: `${size}px` }}
            className="block aspect-square object-contain"
          />
        ) : (
          <div
            style={{ width: `${size}px`, height: `${size}px` }}
            className="bg-slate-100 flex items-center justify-center text-[8px] text-slate-400"
          >
            PIX
          </div>
        )}
        {/* Tiny center PIX badge badge */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <span className="bg-white/95 px-1 py-0.2 text-[6px] font-black text-rose-700 rounded-xs border border-rose-300 shadow-2xs leading-none">
            PIX
          </span>
        </div>
      </div>

      {showDetails && (
        <div className="mt-0.5 max-w-[155px] leading-tight text-slate-800">
          <p className="text-[7.5px] font-bold text-slate-900 tracking-tight uppercase">
            {bankName}
          </p>
          <p className="text-[6.5px] font-semibold text-slate-700 uppercase tracking-tighter truncate">
            {parishName}
          </p>
          <p className="text-[6.5px] font-black text-rose-800 tracking-tight mt-0.5 font-mono select-all">
            Chave: {value}
          </p>
          <p className="text-[5.8px] text-slate-600 mt-0.5 leading-2 font-medium">
            Caso pague com PIX favor enviar o comprovante para o tel.{' '}
            <strong className="text-slate-900 font-bold whitespace-nowrap">{phoneContact}</strong>
          </p>
        </div>
      )}
    </div>
  );
};
