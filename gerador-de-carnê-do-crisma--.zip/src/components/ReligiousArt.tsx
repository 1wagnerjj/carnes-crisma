import React from 'react';

/**
 * Nossa Senhora das Graças and Crisma Sacred Art Elements (SVG)
 * Exquisite vector art with smooth gradients and fine details.
 */

export const BlueFloralBorder: React.FC<{ className?: string; flipped?: boolean }> = ({ className = '', flipped = false }) => (
  <svg
    viewBox="0 0 200 120"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`${className} ${flipped ? 'scale-x-[-1]' : ''}`}
  >
    <defs>
      <linearGradient id="roseGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#bfdbfe" />
        <stop offset="50%" stopColor="#93c5fd" />
        <stop offset="100%" stopColor="#3b82f6" />
      </linearGradient>
      <linearGradient id="leafGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#99f6e4" stopOpacity="0.8" />
        <stop offset="100%" stopColor="#0d9488" stopOpacity="0.9" />
      </linearGradient>
    </defs>
    {/* Soft floral bouquet */}
    {/* Rose 1 */}
    <g transform="translate(40, 50)">
      <circle cx="0" cy="0" r="28" fill="#dbeafe" opacity="0.6" />
      <path d="M-15,-10 C-5,-25 15,-20 22,-5 C28,10 10,24 -5,22 C-20,20 -25,0 -15,-10 Z" fill="#93c5fd" opacity="0.75" />
      <path d="M-10,-5 C-2,-18 12,-15 16,-3 C20,8 6,17 -3,15 C-12,14 -16,2 -10,-5 Z" fill="#60a5fa" opacity="0.8" />
      <path d="M-6,-2 C-1,-10 8,-8 10,-2 C12,5 4,10 -2,9 C-7,8 -9,2 -6,-2 Z" fill="#2563eb" opacity="0.85" />
      <circle cx="0" cy="1" r="3" fill="#1d4ed8" />
    </g>
    {/* Rose 2 */}
    <g transform="translate(100, 30)">
      <circle cx="0" cy="0" r="20" fill="#e0f2fe" opacity="0.7" />
      <path d="M-10,-6 C-3,-16 10,-12 14,-2 C18,8 6,15 -3,14 C-12,13 -15,0 -10,-6 Z" fill="#7dd3fc" opacity="0.8" />
      <path d="M-5,-3 C0,-9 7,-7 8,-1 C10,5 3,9 -1,8 C-5,7 -7,1 -5,-3 Z" fill="#0284c7" opacity="0.85" />
    </g>
    {/* Rose 3 */}
    <g transform="translate(20, 90)">
      <circle cx="0" cy="0" r="16" fill="#dbeafe" opacity="0.7" />
      <path d="M-8,-5 C-2,-12 8,-9 10,-1 C12,6 3,11 -2,10 C-8,9 -11,0 -8,-5 Z" fill="#93c5fd" opacity="0.8" />
    </g>
    {/* Leaves */}
    <path d="M65,45 Q85,35 90,15 Q80,25 65,45 Z" fill="url(#leafGrad)" />
    <path d="M25,35 Q10,20 5,5 Q18,20 25,35 Z" fill="url(#leafGrad)" />
    <path d="M70,75 Q95,85 110,75 Q90,70 70,75 Z" fill="url(#leafGrad)" />
    <path d="M35,85 Q45,105 60,115 Q45,98 35,85 Z" fill="url(#leafGrad)" />
  </svg>
);

/**
 * Nossa Senhora das Graças full standing figure
 */
export const NossaSenhoraFigure: React.FC<{ className?: string }> = ({ className = 'w-16 h-28' }) => (
  <svg viewBox="0 0 100 160" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <defs>
      <linearGradient id="haloGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#fef08a" stopOpacity="0.9" />
        <stop offset="100%" stopColor="#eab308" stopOpacity="0.4" />
      </linearGradient>
      <linearGradient id="mantleGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#3b82f6" />
        <stop offset="50%" stopColor="#1d4ed8" />
        <stop offset="100%" stopColor="#1e3a8a" />
      </linearGradient>
      <linearGradient id="tunicGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#ffffff" />
        <stop offset="100%" stopColor="#f1f5f9" />
      </linearGradient>
      <linearGradient id="rayGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#ffffff" stopOpacity="0.9" />
        <stop offset="100%" stopColor="#60a5fa" stopOpacity="0" />
      </linearGradient>
    </defs>

    {/* Radiant Rays of Grace coming from hands */}
    <g opacity="0.75">
      {/* Left rays */}
      <polygon points="32,75 5,145 18,155" fill="url(#rayGrad)" />
      <polygon points="32,75 12,130 22,140" fill="url(#rayGrad)" />
      {/* Right rays */}
      <polygon points="68,75 95,145 82,155" fill="url(#rayGrad)" />
      <polygon points="68,75 88,130 78,140" fill="url(#rayGrad)" />
    </g>

    {/* Halo & 12 Stars aura */}
    <circle cx="50" cy="28" r="22" fill="url(#haloGrad)" />
    <circle cx="50" cy="28" r="23" stroke="#eab308" strokeWidth="0.8" strokeDasharray="1.5 2" opacity="0.8" />
    {[...Array(12)].map((_, i) => {
      const angle = (i * 30 * Math.PI) / 180;
      const x = 50 + 20 * Math.cos(angle);
      const y = 28 + 20 * Math.sin(angle);
      return <polygon key={i} points={`${x},${y-1.5} ${x+1},${y+1.5} ${x-1.5},${y-0.5} ${x+1.5},${y-0.5} ${x-1},${y+1.5}`} fill="#ca8a04" />;
    })}

    {/* Mantle / Cloak back */}
    <path d="M36,25 C36,15 64,15 64,25 C68,45 76,85 75,145 C65,148 35,148 25,145 C24,85 32,45 36,25 Z" fill="url(#mantleGrad)" />

    {/* White Veil */}
    <path d="M40,24 C40,16 60,16 60,24 C62,38 61,65 59,75 C57,60 43,60 41,75 C39,65 38,38 40,24 Z" fill="#f8fafc" />

    {/* Face & Head */}
    <ellipse cx="50" cy="28" rx="7" ry="9" fill="#fde68a" />
    <path d="M44,24 Q50,22 56,24 Q53,30 44,24 Z" fill="#b45309" opacity="0.5" />
    {/* Eyes, serene downcast expression */}
    <path d="M46,28 Q48,30 49,29" stroke="#78350f" strokeWidth="0.75" strokeLinecap="round" />
    <path d="M51,29 Q52,30 54,28" stroke="#78350f" strokeWidth="0.75" strokeLinecap="round" />
    {/* Soft lips */}
    <line x1="49" y1="33" x2="51" y2="33" stroke="#b91c1c" strokeWidth="0.6" strokeLinecap="round" />

    {/* White Tunic */}
    <path d="M42,37 C42,37 50,42 58,37 C60,60 62,110 61,146 C55,147 45,147 39,146 C38,110 40,60 42,37 Z" fill="url(#tunicGrad)" />
    {/* Blue Sash / Ribbon at waist */}
    <path d="M43,62 Q50,65 57,62 L56,66 Q50,69 44,66 Z" fill="#2563eb" />
    <path d="M48,65 L47,85 L50,85 L51,66 Z" fill="#1d4ed8" />

    {/* Outstretched Arms & Hands */}
    {/* Left arm */}
    <path d="M41,45 C35,52 30,65 31,73 C33,74 36,73 38,67 C39,58 42,50 42,45 Z" fill="#f8fafc" />
    <ellipse cx="30" cy="74" rx="2.5" ry="3.5" fill="#fde68a" transform="rotate(-25 30 74)" />
    {/* Right arm */}
    <path d="M59,45 C65,52 70,65 69,73 C67,74 64,73 62,67 C61,58 58,50 58,45 Z" fill="#f8fafc" />
    <ellipse cx="70" cy="74" rx="2.5" ry="3.5" fill="#fde68a" transform="rotate(25 70 74)" />

    {/* Earth globe & Snake beneath feet */}
    <ellipse cx="50" cy="148" rx="24" ry="7" fill="#64748b" opacity="0.4" />
    <path d="M38,148 Q50,144 62,148" stroke="#334155" strokeWidth="2.5" strokeLinecap="round" />
  </svg>
);

/**
 * Golden Miraculous Medal - Front
 * "Ó Maria concebida sem pecado, rogai por nós que recorremos a vós"
 */
export const MedalhaMilagrosaFrente: React.FC<{ className?: string; size?: number }> = ({ className = '', size = 52 }) => (
  <svg width={size} height={size * 1.3} viewBox="0 0 100 130" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <defs>
      <linearGradient id="goldRim" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#fef08a" />
        <stop offset="35%" stopColor="#eab308" />
        <stop offset="70%" stopColor="#ca8a04" />
        <stop offset="100%" stopColor="#854d0e" />
      </linearGradient>
      <linearGradient id="goldInner" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#fef9c3" />
        <stop offset="50%" stopColor="#facc15" />
        <stop offset="100%" stopColor="#a16207" />
      </linearGradient>
    </defs>
    {/* Outer oval ring */}
    <ellipse cx="50" cy="65" rx="46" ry="60" fill="url(#goldRim)" stroke="#78350f" strokeWidth="1" />
    <ellipse cx="50" cy="65" rx="42" ry="55" fill="url(#goldInner)" stroke="#ca8a04" strokeWidth="0.8" />
    <ellipse cx="50" cy="65" rx="39" ry="51" fill="none" stroke="#854d0e" strokeWidth="0.6" strokeDasharray="1.5 2" />

    {/* Mary relief silhouette */}
    <g transform="translate(50, 60) scale(0.48) translate(-50, -60)">
      {/* Rays */}
      <line x1="30" y1="65" x2="10" y2="105" stroke="#78350f" strokeWidth="1.2" opacity="0.6" />
      <line x1="33" y1="65" x2="20" y2="108" stroke="#78350f" strokeWidth="1.2" opacity="0.6" />
      <line x1="70" y1="65" x2="90" y2="105" stroke="#78350f" strokeWidth="1.2" opacity="0.6" />
      <line x1="67" y1="65" x2="80" y2="108" stroke="#78350f" strokeWidth="1.2" opacity="0.6" />

      {/* Head & Halo */}
      <circle cx="50" cy="30" r="14" fill="#854d0e" opacity="0.4" />
      <circle cx="50" cy="30" r="7" fill="#78350f" />

      {/* Body */}
      <path d="M41,36 C37,50 34,75 31,105 C42,107 58,107 69,105 C66,75 63,50 59,36 Z" fill="#78350f" />
      {/* Arms */}
      <line x1="42" y1="48" x2="32" y2="65" stroke="#78350f" strokeWidth="3" strokeLinecap="round" />
      <line x1="58" y1="48" x2="68" y2="65" stroke="#78350f" strokeWidth="3" strokeLinecap="round" />
      {/* Globe */}
      <ellipse cx="50" cy="107" rx="18" ry="4" fill="#78350f" />
    </g>

    {/* Latin/Portuguese Inscription Arc around oval */}
    <path id="ovalTextPath" d="M 18,70 A 34 46 0 1 1 82,70" fill="none" />
    <text fontSize="4.2" fill="#713f12" fontWeight="700" letterSpacing="0.4">
      <textPath href="#ovalTextPath" startOffset="50%" textAnchor="middle">
        Ó MARIA CONCEBIDA SEM PECADO
      </textPath>
    </text>

    {/* Year at bottom */}
    <text x="50" y="121" fontSize="4.8" fill="#713f12" fontWeight="700" textAnchor="middle">1830</text>
  </svg>
);

/**
 * Golden Miraculous Medal - Back
 * Cross, M, Two Hearts, 12 Stars
 */
export const MedalhaMilagrosaVerso: React.FC<{ className?: string; size?: number }> = ({ className = '', size = 52 }) => (
  <svg width={size} height={size * 1.3} viewBox="0 0 100 130" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <defs>
      <linearGradient id="goldRimV" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#fef08a" />
        <stop offset="35%" stopColor="#eab308" />
        <stop offset="70%" stopColor="#ca8a04" />
        <stop offset="100%" stopColor="#854d0e" />
      </linearGradient>
      <linearGradient id="goldInnerV" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#fef9c3" />
        <stop offset="50%" stopColor="#facc15" />
        <stop offset="100%" stopColor="#a16207" />
      </linearGradient>
    </defs>
    <ellipse cx="50" cy="65" rx="46" ry="60" fill="url(#goldRimV)" stroke="#78350f" strokeWidth="1" />
    <ellipse cx="50" cy="65" rx="42" ry="55" fill="url(#goldInnerV)" stroke="#ca8a04" strokeWidth="0.8" />

    {/* 12 Stars border */}
    {[...Array(12)].map((_, i) => {
      const angle = (i * 30 * Math.PI) / 180;
      const x = 50 + 35 * Math.cos(angle);
      const y = 65 + 46 * Math.sin(angle);
      return (
        <polygon
          key={i}
          points={`${x},${y-2.5} ${x+1.5},${y+2.5} ${x-2.2},${y-0.8} ${x+2.2},${y-0.8} ${x-1.5},${y+2.5}`}
          fill="#78350f"
        />
      );
    })}

    {/* Cross & Bar */}
    <g fill="#78350f">
      {/* Cross bar horizontal */}
      <rect x="36" y="34" width="28" height="4.5" rx="1" />
      {/* Cross vertical top */}
      <rect x="47.5" y="20" width="5" height="30" rx="1" />
      {/* Pedestal / Bar of M */}
      <rect x="34" y="48" width="32" height="3.5" rx="0.8" />

      {/* Large Letter M */}
      <path
        d="M28,82 L28,52 L36,52 L50,71 L64,52 L72,52 L72,82 L65,82 L65,61 L53,78 L47,78 L35,61 L35,82 Z"
        fill="#78350f"
      />

      {/* Sacred Heart of Jesus (surrounded by thorns & flame) */}
      <g transform="translate(36, 96)">
        {/* Flame */}
        <path d="M-1,-7 Q0,-12 3,-7 Q5,-3 0,0 Q-4,-3 -1,-7 Z" fill="#b91c1c" />
        {/* Heart */}
        <path d="M0,2 C-7,-4 -10,3 -7,7 C-5,10 0,14 0,14 C0,14 5,10 7,7 C10,3 7,-4 0,2 Z" fill="#78350f" />
        <ellipse cx="0" cy="6" rx="6" ry="1.5" fill="none" stroke="#fef08a" strokeWidth="0.8" strokeDasharray="1.2 1" />
      </g>

      {/* Immaculate Heart of Mary (pierced by a sword) */}
      <g transform="translate(64, 96)">
        {/* Heart */}
        <path d="M0,2 C-7,-4 -10,3 -7,7 C-5,10 0,14 0,14 C0,14 5,10 7,7 C10,3 7,-4 0,2 Z" fill="#78350f" />
        {/* Sword piercing */}
        <line x1="-7" y1="1" x2="8" y2="11" stroke="#fef08a" strokeWidth="1.2" strokeLinecap="round" />
      </g>
    </g>
  </svg>
);

/**
 * Crisma Dove (Espírito Santo) with Golden Holy Rays
 * Símbolo tradicional do Crisma / Sacramento da Confirmação
 */
export const CrismaEspiritoSanto: React.FC<{ className?: string; size?: number }> = ({ className = '', size = 48 }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <defs>
      <linearGradient id="doveRayGrad" x1="50" y1="50" x2="100" y2="100" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#fef08a" stopOpacity="0.9" />
        <stop offset="60%" stopColor="#facc15" stopOpacity="0.4" />
        <stop offset="100%" stopColor="#eab308" stopOpacity="0" />
      </linearGradient>
      <linearGradient id="flameGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#ef4444" />
        <stop offset="50%" stopColor="#f97316" />
        <stop offset="100%" stopColor="#eab308" />
      </linearGradient>
    </defs>

    {/* Radiant Glory Rays */}
    <g opacity="0.6">
      {[...Array(16)].map((_, i) => {
        const angle = (i * 22.5 * Math.PI) / 180;
        const x1 = 50 + 12 * Math.cos(angle);
        const y1 = 50 + 12 * Math.sin(angle);
        const x2 = 50 + 44 * Math.cos(angle);
        const y2 = 50 + 44 * Math.sin(angle);
        return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#ca8a04" strokeWidth="1.5" strokeLinecap="round" />;
      })}
    </g>

    {/* Halo Circle */}
    <circle cx="50" cy="50" r="28" stroke="#ca8a04" strokeWidth="1" strokeDasharray="3 2" fill="none" opacity="0.5" />

    {/* Holy Spirit Dove descending with open wings */}
    <g transform="translate(0, 2)">
      {/* Wings */}
      <path
        d="M50,42 C38,30 20,32 14,40 C22,46 34,48 44,48 C40,54 36,66 42,74 C47,67 48,58 50,52 C52,58 53,67 58,74 C64,66 60,54 56,48 C66,48 78,46 86,40 C80,32 62,30 50,42 Z"
        fill="#ffffff"
        stroke="#1e3a8a"
        strokeWidth="1.2"
        strokeLinejoin="round"
      />
      {/* Dove head & body descending downwards */}
      <path
        d="M47,38 C47,32 53,32 53,38 C53,46 54,52 50,56 C46,52 47,46 47,38 Z"
        fill="#ffffff"
        stroke="#1e3a8a"
        strokeWidth="1.2"
      />
      {/* Beak with olive branch or grace */}
      <polygon points="50,30 48,34 52,34" fill="#d97706" />

      {/* Seven Gifts of Holy Spirit flames around */}
      <circle cx="50" cy="24" r="2.2" fill="url(#flameGrad)" />
      <circle cx="34" cy="28" r="1.8" fill="url(#flameGrad)" />
      <circle cx="66" cy="28" r="1.8" fill="url(#flameGrad)" />
      <circle cx="22" cy="38" r="1.8" fill="url(#flameGrad)" />
      <circle cx="78" cy="38" r="1.8" fill="url(#flameGrad)" />
    </g>
  </svg>
);

/**
 * Full Banner reproducing Header from Photo 1
 * "Capela Nossa Senhora das Graças"
 */
export const CapelaHeaderBanner: React.FC<{
  title?: string;
  subtitle?: string;
  badgeText?: string;
  className?: string;
}> = ({
  title = 'Capela',
  subtitle = 'Nossa Senhora das Graças',
  badgeText = 'CRISMA',
  className = '',
}) => {
  return (
    <div
      className={`relative overflow-hidden bg-gradient-to-r from-sky-100 via-blue-50 to-sky-100 border-b border-sky-200 select-none ${className}`}
    >
      {/* Background floral flourishes */}
      <BlueFloralBorder className="absolute -left-6 -top-4 w-28 h-20 opacity-70 pointer-events-none" />
      <BlueFloralBorder className="absolute -right-6 -top-4 w-28 h-20 opacity-70 pointer-events-none" flipped />

      <div className="relative flex items-center justify-between px-3 py-1.5 z-10">
        {/* Left: Medalha Milagrosa Frente */}
        <div className="flex flex-col items-center shrink-0">
          <MedalhaMilagrosaFrente size={36} className="drop-shadow-sm" />
        </div>

        {/* Center: Title & Subtitle */}
        <div className="flex-1 text-center px-2 flex flex-col justify-center">
          <span className="font-script text-2xl leading-none text-blue-900 tracking-wide drop-shadow-sm">
            {title}
          </span>
          <span className="font-script text-xl leading-tight text-blue-950 font-bold -mt-0.5">
            {subtitle}
          </span>
          {badgeText && (
            <div className="flex items-center justify-center gap-1.5 mt-0.5">
              <span className="h-[1px] w-6 bg-amber-400" />
              <span className="text-[9px] font-bold tracking-widest text-blue-900 uppercase">
                {badgeText}
              </span>
              <span className="h-[1px] w-6 bg-amber-400" />
            </div>
          )}
        </div>

        {/* Right side: Nossa Senhora figure + Medalha Milagrosa Verso */}
        <div className="flex items-center gap-1.5 shrink-0">
          <div className="h-14 w-8 flex items-center justify-center">
            <NossaSenhoraFigure className="w-9 h-14" />
          </div>
          <MedalhaMilagrosaVerso size={36} className="drop-shadow-sm" />
        </div>
      </div>
    </div>
  );
};
