import React from 'react';
import { EmblemType } from '../types';
import { IniciacaoCristaIcon } from './IniciacaoCristaIcon';
import {
  MedalhaMilagrosaFrente,
  CrismaEspiritoSanto,
} from './ReligiousArt';

export interface EmblemOption {
  id: EmblemType;
  title: string;
  subtitle: string;
  category: string;
  badge?: string;
}

export const EMBLEM_OPTIONS: EmblemOption[] = [
  {
    id: 'iniciacao_crista',
    title: 'Iniciação Cristã (Oficial)',
    subtitle: 'Sol dourado, chamas de Pentecostes, cruz e pomba',
    category: 'Crisma',
    badge: 'Padrão',
  },
  {
    id: 'espirito_santo',
    title: 'Espírito Santo Radiante',
    subtitle: 'Pomba sagrada com os 7 Dons e raios de glória',
    category: 'Crisma',
    badge: 'Confirmação',
  },
  {
    id: 'medalha_milagrosa',
    title: 'Medalha Milagrosa',
    subtitle: 'Nossa Senhora das Graças com raios e manto celeste',
    category: 'Mariano',
    badge: 'Graças',
  },
  {
    id: 'nossa_senhora_aparecida',
    title: 'Nossa Senhora Aparecida',
    subtitle: 'Padroeira do Brasil com manto bordado e coroa imperial',
    category: 'Mariano',
    badge: 'Padroeira',
  },
  {
    id: 'calice_eucaristia',
    title: 'Cálice & Hóstia Sagrada (JHS)',
    subtitle: 'Pão e Vinho da Eucaristia, trigo dourado e uvas',
    category: 'Eucaristia',
    badge: 'Comunhão',
  },
  {
    id: 'cruz_sagrada',
    title: 'Cruz Sagrada & Ramos da Paz',
    subtitle: 'Cruz de Cristo com coroa de glória e ramos de oliveira',
    category: 'Geral',
    badge: 'Salvação',
  },
  {
    id: 'sagrado_coracao',
    title: 'Sagrado Coração de Jesus',
    subtitle: 'Coração misericordioso em chamas com coroa de espinhos',
    category: 'Devoção',
    badge: 'Misericórdia',
  },
  {
    id: 'biblia_vela',
    title: 'Bíblia Sagrada & Círio Pascal',
    subtitle: 'Palavra de Deus aberta e chama da Luz de Cristo',
    category: 'Pastoral',
    badge: 'Luz da Fé',
  },
];

/**
 * Nossa Senhora Aparecida (Padroeira do Brasil)
 */
export const NossaSenhoraAparecidaIcon: React.FC<{ size?: number; className?: string }> = ({
  size = 46,
  className = '',
}) => (
  <svg
    width={size}
    height={size * 1.25}
    viewBox="0 0 100 125"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`select-none ${className}`}
  >
    <defs>
      <linearGradient id="nsaMantle" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#1e3a8a" />
        <stop offset="60%" stopColor="#0f172a" />
        <stop offset="100%" stopColor="#020617" />
      </linearGradient>
      <linearGradient id="nsaGold" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#fef08a" />
        <stop offset="50%" stopColor="#eab308" />
        <stop offset="100%" stopColor="#ca8a04" />
      </linearGradient>
      <linearGradient id="nsaRays" x1="50" y1="50" x2="100" y2="100" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#fde047" stopOpacity="0.8" />
        <stop offset="100%" stopColor="#ca8a04" stopOpacity="0.1" />
      </linearGradient>
    </defs>

    {/* Radiant Glory Aura */}
    <g opacity="0.6">
      {[...Array(16)].map((_, i) => {
        const angle = (i * 22.5 * Math.PI) / 180;
        const x1 = 50 + 18 * Math.cos(angle);
        const y1 = 50 + 18 * Math.sin(angle);
        const x2 = 50 + 44 * Math.cos(angle);
        const y2 = 50 + 44 * Math.sin(angle);
        return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#eab308" strokeWidth="1.2" strokeLinecap="round" />;
      })}
    </g>

    {/* Triangular Mantle */}
    <path
      d="M50,22 C56,26 80,82 82,106 C72,112 28,112 18,106 C20,82 44,26 50,22 Z"
      fill="url(#nsaMantle)"
      stroke="url(#nsaGold)"
      strokeWidth="2.2"
    />

    {/* Golden Brocade Embroidery along edges */}
    <path
      d="M50,25 L78,104 M50,25 L22,104"
      stroke="#fde047"
      strokeWidth="1.2"
      strokeDasharray="2 3"
      opacity="0.9"
    />

    {/* Brazilian Flag / Cross emblems on mantle */}
    {/* Left Coat of arms/cross */}
    <g transform="translate(32, 68) scale(0.6)">
      <polygon points="10,0 12,8 20,10 12,12 10,20 8,12 0,10 8,8" fill="url(#nsaGold)" />
    </g>
    {/* Right Coat of arms/cross */}
    <g transform="translate(56, 68) scale(0.6)">
      <polygon points="10,0 12,8 20,10 12,12 10,20 8,12 0,10 8,8" fill="url(#nsaGold)" />
    </g>

    {/* Central Cross Brooch */}
    <g transform="translate(50, 48)">
      <rect x="-2" y="-7" width="4" height="14" rx="0.5" fill="url(#nsaGold)" />
      <rect x="-6" y="-3" width="12" height="4" rx="0.5" fill="url(#nsaGold)" />
    </g>

    {/* Gentle Hands clasped in prayer */}
    <ellipse cx="50" cy="58" rx="4" ry="5" fill="#78350f" />
    <path d="M47,56 C49,53 51,53 53,56 C52,60 48,60 47,56 Z" fill="#92400e" />

    {/* Face / Sacred Image (Dark clay tone) */}
    <ellipse cx="50" cy="30" rx="6.5" ry="7.5" fill="#5c381e" />
    {/* Soft features */}
    <circle cx="48" cy="29" r="0.6" fill="#29180c" />
    <circle cx="52" cy="29" r="0.6" fill="#29180c" />
    <path d="M49,34 Q50,35 51,34" stroke="#29180c" strokeWidth="0.6" strokeLinecap="round" />

    {/* Imperial Crown with jewels and top Cross */}
    <g transform="translate(50, 16)">
      {/* Crown base */}
      <path
        d="M-11,2 C-7,-4 0,-7 0,-7 C0,-7 7,-4 11,2 L10,5 L-10,5 Z"
        fill="url(#nsaGold)"
        stroke="#854d0e"
        strokeWidth="0.8"
      />
      {/* Crown jewels */}
      <circle cx="-6" cy="1" r="1.5" fill="#ef4444" />
      <circle cx="0" cy="-2" r="1.8" fill="#3b82f6" />
      <circle cx="6" cy="1" r="1.5" fill="#ef4444" />
      {/* Top Cross */}
      <line x1="0" y1="-8" x2="0" y2="-14" stroke="#eab308" strokeWidth="1.8" strokeLinecap="round" />
      <line x1="-3" y1="-12" x2="3" y2="-12" stroke="#eab308" strokeWidth="1.8" strokeLinecap="round" />
    </g>

    {/* Clouds pedestal base */}
    <ellipse cx="50" cy="112" rx="28" ry="6" fill="#e2e8f0" opacity="0.9" />
    <ellipse cx="40" cy="111" rx="14" ry="5" fill="#f8fafc" />
    <ellipse cx="60" cy="111" rx="14" ry="5" fill="#f8fafc" />
  </svg>
);

/**
 * Cálice & Hóstia Sagrada / Eucaristia (JHS)
 */
export const CaliceEucaristiaIcon: React.FC<{ size?: number; className?: string }> = ({
  size = 46,
  className = '',
}) => (
  <svg
    width={size}
    height={size * 1.25}
    viewBox="0 0 100 125"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`select-none ${className}`}
  >
    <defs>
      <linearGradient id="caliceGold" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#fef08a" />
        <stop offset="35%" stopColor="#facc15" />
        <stop offset="70%" stopColor="#ca8a04" />
        <stop offset="100%" stopColor="#854d0e" />
      </linearGradient>
      <radialGradient id="hostGrad" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#ffffff" />
        <stop offset="75%" stopColor="#fefce8" />
        <stop offset="100%" stopColor="#fef08a" />
      </radialGradient>
      <linearGradient id="hostGlow" x1="50" y1="36" x2="100" y2="86" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#facc15" stopOpacity="0.8" />
        <stop offset="100%" stopColor="#facc15" stopOpacity="0" />
      </linearGradient>
    </defs>

    {/* Radiant Glory behind the Host */}
    <g opacity="0.7">
      {[...Array(16)].map((_, i) => {
        const angle = (i * 22.5 * Math.PI) / 180;
        const x1 = 50 + 16 * Math.cos(angle);
        const y1 = 34 + 16 * Math.sin(angle);
        const x2 = 50 + 38 * Math.cos(angle);
        const y2 = 34 + 38 * Math.sin(angle);
        return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#ca8a04" strokeWidth="1.2" strokeLinecap="round" />;
      })}
    </g>

    {/* The Sacred Host */}
    <circle cx="50" cy="34" r="17" fill="url(#hostGrad)" stroke="#ca8a04" strokeWidth="1.2" />
    <circle cx="50" cy="34" r="14.5" fill="none" stroke="#eab308" strokeWidth="0.6" strokeDasharray="1.5 1.5" />

    {/* JHS engraving and small cross on Host */}
    <text
      x="50"
      y="38"
      fontSize="8.5"
      fontWeight="900"
      fontFamily="serif"
      fill="#854d0e"
      textAnchor="middle"
      letterSpacing="0.8"
    >
      JHS
    </text>
    {/* Small cross atop H */}
    <line x1="50" y1="26" x2="50" y2="30" stroke="#854d0e" strokeWidth="0.8" />
    <line x1="48" y1="27.5" x2="52" y2="27.5" stroke="#854d0e" strokeWidth="0.8" />

    {/* Golden Chalice Cup */}
    <g id="chalice">
      {/* Cup bowl */}
      <path
        d="M30,52 C30,76 43,84 47,85 L47,98 L40,102 C36,104 35,108 35,112 L65,112 C65,108 64,104 60,102 L53,98 L53,85 C57,84 70,76 70,52 Z"
        fill="url(#caliceGold)"
        stroke="#78350f"
        strokeWidth="1.4"
      />

      {/* Chalice Rim */}
      <ellipse cx="50" cy="52" rx="20" ry="4" fill="url(#caliceGold)" stroke="#78350f" strokeWidth="1.2" />
      <ellipse cx="50" cy="52" rx="17" ry="2.5" fill="#991b1b" opacity="0.85" />

      {/* Node / Ring in Stem */}
      <ellipse cx="50" cy="91" rx="6" ry="3.5" fill="#fef08a" stroke="#854d0e" strokeWidth="0.8" />

      {/* Chalice Base decoration */}
      <ellipse cx="50" cy="112" rx="16" ry="3.5" fill="url(#caliceGold)" stroke="#78350f" strokeWidth="1" />
      <path d="M42,108 Q50,106 58,108" stroke="#78350f" strokeWidth="1" />
    </g>

    {/* Wheat ear & grape cluster flourishes */}
    <g transform="translate(18, 70) scale(0.65)" opacity="0.85">
      {/* Grape berries */}
      <circle cx="10" cy="12" r="3" fill="#7c3aed" />
      <circle cx="15" cy="13" r="3" fill="#6d28d9" />
      <circle cx="12" cy="18" r="3" fill="#5b21b6" />
      <circle cx="16" cy="19" r="3" fill="#7c3aed" />
      <circle cx="14" cy="24" r="2.5" fill="#6d28d9" />
      {/* Vine curl */}
      <path d="M8,10 Q14,4 18,8" stroke="#15803d" strokeWidth="1.2" fill="none" />
    </g>

    <g transform="translate(70, 70) scale(0.65)" opacity="0.85">
      {/* Golden Wheat Spike */}
      <path d="M6,24 Q10,12 16,4" stroke="#ca8a04" strokeWidth="1.5" fill="none" />
      <ellipse cx="14" cy="8" rx="2.5" ry="4.5" fill="#facc15" transform="rotate(30 14 8)" />
      <ellipse cx="11" cy="13" rx="2.5" ry="4.5" fill="#facc15" transform="rotate(-30 11 13)" />
      <ellipse cx="10" cy="18" rx="2.5" ry="4.5" fill="#facc15" transform="rotate(25 10 18)" />
    </g>
  </svg>
);

/**
 * Cruz Sagrada & Ramos da Paz / Confirmação
 */
export const CruzSagradaIcon: React.FC<{ size?: number; className?: string }> = ({
  size = 46,
  className = '',
}) => (
  <svg
    width={size}
    height={size * 1.25}
    viewBox="0 0 100 125"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`select-none ${className}`}
  >
    <defs>
      <linearGradient id="crossWood" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#78350f" />
        <stop offset="50%" stopColor="#451a03" />
        <stop offset="100%" stopColor="#1c1917" />
      </linearGradient>
      <linearGradient id="crossGold" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#fef08a" />
        <stop offset="50%" stopColor="#eab308" />
        <stop offset="100%" stopColor="#ca8a04" />
      </linearGradient>
    </defs>

    {/* Radiant Glory Aura */}
    <g opacity="0.6">
      {[...Array(16)].map((_, i) => {
        const angle = (i * 22.5 * Math.PI) / 180;
        const x1 = 50 + 14 * Math.cos(angle);
        const y1 = 44 * Math.sin(angle) + 48;
        const x2 = 50 + 38 * Math.cos(angle);
        const y2 = 48 + 38 * Math.sin(angle);
        return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#eab308" strokeWidth="1.2" strokeLinecap="round" />;
      })}
    </g>

    {/* Olive Branches / Palm of Peace encircling Cross */}
    <g stroke="#15803d" strokeWidth="1.2" fill="#22c55e" opacity="0.85">
      {/* Left branch */}
      <path d="M50,105 C32,95 24,70 28,45" fill="none" strokeWidth="1.5" />
      <ellipse cx="27" cy="48" rx="3" ry="6" transform="rotate(-35 27 48)" />
      <ellipse cx="25" cy="62" rx="3" ry="6" transform="rotate(-40 25 62)" />
      <ellipse cx="30" cy="76" rx="3" ry="6" transform="rotate(-30 30 76)" />
      <ellipse cx="38" cy="90" rx="3" ry="6" transform="rotate(-20 38 90)" />

      {/* Right branch */}
      <path d="M50,105 C68,95 76,70 72,45" fill="none" strokeWidth="1.5" />
      <ellipse cx="73" cy="48" rx="3" ry="6" transform="rotate(35 73 48)" />
      <ellipse cx="75" cy="62" rx="3" ry="6" transform="rotate(40 75 62)" />
      <ellipse cx="70" cy="76" rx="3" ry="6" transform="rotate(30 70 76)" />
      <ellipse cx="62" cy="90" rx="3" ry="6" transform="rotate(20 62 90)" />
    </g>

    {/* Latin Cross */}
    <g id="mainCross">
      {/* Vertical beam */}
      <rect x="45.5" y="14" width="9" height="98" rx="1.5" fill="url(#crossGold)" stroke="#78350f" strokeWidth="1.4" />
      {/* Horizontal beam */}
      <rect x="22" y="38" width="56" height="9" rx="1.5" fill="url(#crossGold)" stroke="#78350f" strokeWidth="1.4" />

      {/* Inner inlay cross */}
      <rect x="47.5" y="16" width="5" height="94" rx="0.8" fill="url(#crossWood)" />
      <rect x="24" y="40" width="52" height="5" rx="0.8" fill="url(#crossWood)" />

      {/* Center rosette / jewel */}
      <circle cx="50" cy="42.5" r="5" fill="#fef08a" stroke="#ca8a04" strokeWidth="1.2" />
      <circle cx="50" cy="42.5" r="2.5" fill="#b91c1c" />
    </g>
  </svg>
);

/**
 * Sagrado Coração de Jesus
 */
export const SagradoCoracaoIcon: React.FC<{ size?: number; className?: string }> = ({
  size = 46,
  className = '',
}) => (
  <svg
    width={size}
    height={size * 1.25}
    viewBox="0 0 100 125"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`select-none ${className}`}
  >
    <defs>
      <linearGradient id="heartRed" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#ef4444" />
        <stop offset="60%" stopColor="#b91c1c" />
        <stop offset="100%" stopColor="#7f1d1d" />
      </linearGradient>
      <linearGradient id="fireGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#fef08a" />
        <stop offset="40%" stopColor="#f97316" />
        <stop offset="100%" stopColor="#dc2626" />
      </linearGradient>
    </defs>

    {/* Radiant Rays of Grace */}
    <g opacity="0.6">
      {[...Array(16)].map((_, i) => {
        const angle = (i * 22.5 * Math.PI) / 180;
        const x1 = 50 + 16 * Math.cos(angle);
        const y1 = 65 + 16 * Math.sin(angle);
        const x2 = 50 + 42 * Math.cos(angle);
        const y2 = 65 + 42 * Math.sin(angle);
        return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#facc15" strokeWidth="1.4" strokeLinecap="round" />;
      })}
    </g>

    {/* Divine Flame bursting from top */}
    <path
      d="M50,15 C45,28 35,36 42,48 C46,42 49,42 50,48 C51,42 54,42 58,48 C65,36 55,28 50,15 Z"
      fill="url(#fireGrad)"
      stroke="#b45309"
      strokeWidth="1"
    />

    {/* Small Golden Cross planted in the flame */}
    <g transform="translate(50, 18)">
      <line x1="0" y1="-8" x2="0" y2="4" stroke="#ca8a04" strokeWidth="2.2" strokeLinecap="round" />
      <line x1="-5" y1="-4" x2="5" y2="-4" stroke="#ca8a04" strokeWidth="2.2" strokeLinecap="round" />
    </g>

    {/* The Sacred Heart */}
    <path
      d="M50,52 C42,42 22,46 22,64 C22,82 44,98 50,108 C56,98 78,82 78,64 C78,46 58,42 50,52 Z"
      fill="url(#heartRed)"
      stroke="#450a0a"
      strokeWidth="1.8"
    />

    {/* Crown of Thorns wrapped around the heart */}
    <g stroke="#78350f" strokeWidth="1.4" strokeLinecap="round">
      <ellipse cx="50" cy="70" rx="27" ry="6" fill="none" stroke="#ca8a04" strokeWidth="1" />
      <path d="M24,70 Q36,65 50,70 Q64,75 76,70" fill="none" />
      <path d="M26,69 L28,64 M34,71 L36,76 M44,69 L42,64 M56,71 L58,76 M66,69 L64,64" />
    </g>

    {/* Wound / Piercing with drops of divine love */}
    <ellipse cx="62" cy="78" rx="2" ry="4" fill="#450a0a" transform="rotate(25 62 78)" />
    <circle cx="63" cy="85" r="1.5" fill="#dc2626" />
  </svg>
);

/**
 * Bíblia Sagrada & Círio Pascal / Palavra de Deus
 */
export const BibliaVelaIcon: React.FC<{ size?: number; className?: string }> = ({
  size = 46,
  className = '',
}) => (
  <svg
    width={size}
    height={size * 1.25}
    viewBox="0 0 100 125"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`select-none ${className}`}
  >
    <defs>
      <linearGradient id="bookCover" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#854d0e" />
        <stop offset="70%" stopColor="#451a03" />
        <stop offset="100%" stopColor="#1c1917" />
      </linearGradient>
      <linearGradient id="pageGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#ffffff" />
        <stop offset="60%" stopColor="#fefce8" />
        <stop offset="100%" stopColor="#fef08a" />
      </linearGradient>
    </defs>

    {/* Light Rays of the Word of God */}
    <g opacity="0.6">
      {[...Array(14)].map((_, i) => {
        const angle = ((i * 25 - 160) * Math.PI) / 180;
        const x1 = 50 + 12 * Math.cos(angle);
        const y1 = 40 + 12 * Math.sin(angle);
        const x2 = 50 + 38 * Math.cos(angle);
        const y2 = 40 + 38 * Math.sin(angle);
        return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#eab308" strokeWidth="1.2" strokeLinecap="round" />;
      })}
    </g>

    {/* Easter Candle (Círio Pascal) */}
    <g id="candle">
      {/* Candle beam */}
      <rect x="46" y="24" width="8" height="34" rx="1" fill="#fef9c3" stroke="#ca8a04" strokeWidth="1" />
      {/* Red cross on candle */}
      <line x1="50" y1="30" x2="50" y2="44" stroke="#dc2626" strokeWidth="1.5" />
      <line x1="47.5" y1="34" x2="52.5" y2="34" stroke="#dc2626" strokeWidth="1.5" />
      {/* Greek letters Alpha & Omega */}
      <text x="50" y="29" fontSize="3" fontWeight="bold" fill="#dc2626" textAnchor="middle">A</text>
      <text x="50" y="49" fontSize="3" fontWeight="bold" fill="#dc2626" textAnchor="middle">Ω</text>

      {/* Wick & Flame */}
      <line x1="50" y1="24" x2="50" y2="20" stroke="#78350f" strokeWidth="1" />
      <path
        d="M50,8 C47,14 45,17 50,21 C55,17 53,14 50,8 Z"
        fill="#f59e0b"
        stroke="#d97706"
        strokeWidth="0.8"
      />
      <ellipse cx="50" cy="16" rx="2" ry="3.5" fill="#fef08a" />
    </g>

    {/* Open Holy Bible Book */}
    <g id="bible">
      {/* Leather cover back */}
      <path
        d="M14,84 C30,78 48,82 50,84 C52,82 70,78 86,84 L88,108 C72,102 52,106 50,108 C48,106 28,102 12,108 Z"
        fill="url(#bookCover)"
        stroke="#ca8a04"
        strokeWidth="1.5"
      />

      {/* Book pages */}
      <path
        d="M16,80 C32,74 48,78 50,80 C52,78 68,74 84,80 L86,104 C70,98 52,102 50,104 C48,102 30,98 14,104 Z"
        fill="url(#pageGrad)"
        stroke="#ca8a04"
        strokeWidth="1.2"
      />

      {/* Center gutter & Ribbon bookmark */}
      <line x1="50" y1="80" x2="50" y2="104" stroke="#a16207" strokeWidth="1.2" />
      <path d="M50,80 Q52,98 54,116 L51,114 L48,116 Q50,98 50,80" fill="#dc2626" />

      {/* Simulated scripture text lines */}
      <g stroke="#94a3b8" strokeWidth="0.8" strokeLinecap="round">
        <line x1="22" y1="84" x2="42" y2="83" />
        <line x1="22" y1="88" x2="40" y2="87" />
        <line x1="22" y1="92" x2="42" y2="91" />
        <line x1="22" y1="96" x2="38" y2="95" />

        <line x1="58" y1="83" x2="78" y2="84" />
        <line x1="60" y1="87" x2="78" y2="88" />
        <line x1="58" y1="91" x2="78" y2="92" />
        <line x1="60" y1="95" x2="76" y2="96" />
      </g>
    </g>
  </svg>
);

/**
 * Universal Religious Emblem Component
 */
interface ReligiousEmblemProps {
  type: EmblemType;
  customImageUrl?: string;
  size?: number;
  isCompact?: boolean;
  showLabel?: boolean;
  className?: string;
}

export const ReligiousEmblem: React.FC<ReligiousEmblemProps> = ({
  type,
  customImageUrl,
  size = 46,
  isCompact = false,
  showLabel = false,
  className = '',
}) => {
  const emblemSize = isCompact ? Math.min(size, 38) : size;

  if (customImageUrl) {
    return (
      <div className={`flex flex-col items-center justify-center ${className}`}>
        <img
          src={customImageUrl}
          alt="Selo Personalizado"
          className={`${isCompact ? 'h-8 max-w-[40px]' : 'h-11 max-w-[54px]'} w-auto object-contain drop-shadow-xs`}
        />
        {showLabel && !isCompact && (
          <span className="text-[6px] font-bold text-slate-700 uppercase tracking-wider mt-0.5">
            Personalizado
          </span>
        )}
      </div>
    );
  }

  switch (type) {
    case 'iniciacao_crista':
      return (
        <div className={`flex flex-col items-center justify-center ${className}`}>
          <IniciacaoCristaIcon size={emblemSize} showText={!isCompact} />
        </div>
      );

    case 'espirito_santo':
      return (
        <div className={`flex flex-col items-center justify-center ${className}`}>
          <CrismaEspiritoSanto size={emblemSize * 1.05} />
          {showLabel && !isCompact && (
            <span className="text-[6px] font-bold text-amber-800 uppercase tracking-wider mt-0.5">
              Espírito Santo
            </span>
          )}
        </div>
      );

    case 'medalha_milagrosa':
      return (
        <div className={`flex flex-col items-center justify-center ${className}`}>
          <MedalhaMilagrosaFrente size={isCompact ? 32 : Math.round(emblemSize * 0.95)} />
          {showLabel && !isCompact && (
            <span className="text-[6px] font-bold text-amber-800 uppercase tracking-wider mt-0.5">
              N. Sra. das Graças
            </span>
          )}
        </div>
      );

    case 'nossa_senhora_aparecida':
      return (
        <div className={`flex flex-col items-center justify-center ${className}`}>
          <NossaSenhoraAparecidaIcon size={isCompact ? 32 : Math.round(emblemSize * 0.95)} />
          {showLabel && !isCompact && (
            <span className="text-[6px] font-bold text-blue-900 uppercase tracking-wider mt-0.5">
              N. Sra. Aparecida
            </span>
          )}
        </div>
      );

    case 'calice_eucaristia':
      return (
        <div className={`flex flex-col items-center justify-center ${className}`}>
          <CaliceEucaristiaIcon size={isCompact ? 32 : Math.round(emblemSize * 0.95)} />
          {showLabel && !isCompact && (
            <span className="text-[6px] font-bold text-amber-900 uppercase tracking-wider mt-0.5">
              Eucaristia (JHS)
            </span>
          )}
        </div>
      );

    case 'cruz_sagrada':
      return (
        <div className={`flex flex-col items-center justify-center ${className}`}>
          <CruzSagradaIcon size={isCompact ? 32 : Math.round(emblemSize * 0.95)} />
          {showLabel && !isCompact && (
            <span className="text-[6px] font-bold text-emerald-800 uppercase tracking-wider mt-0.5">
              Cruz Sagrada
            </span>
          )}
        </div>
      );

    case 'sagrado_coracao':
      return (
        <div className={`flex flex-col items-center justify-center ${className}`}>
          <SagradoCoracaoIcon size={isCompact ? 32 : Math.round(emblemSize * 0.95)} />
          {showLabel && !isCompact && (
            <span className="text-[6px] font-bold text-rose-800 uppercase tracking-wider mt-0.5">
              Sagrado Coração
            </span>
          )}
        </div>
      );

    case 'biblia_vela':
      return (
        <div className={`flex flex-col items-center justify-center ${className}`}>
          <BibliaVelaIcon size={isCompact ? 32 : Math.round(emblemSize * 0.95)} />
          {showLabel && !isCompact && (
            <span className="text-[6px] font-bold text-amber-800 uppercase tracking-wider mt-0.5">
              Palavra de Deus
            </span>
          )}
        </div>
      );

    default:
      return (
        <div className={`flex flex-col items-center justify-center ${className}`}>
          <IniciacaoCristaIcon size={emblemSize} showText={!isCompact} />
        </div>
      );
  }
};
