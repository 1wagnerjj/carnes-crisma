import React, { useState } from 'react';
import { CarneConfig, SavedCarneCopy, DEFAULT_CONFIG, EmblemType } from '../types';
import { downloadEditableHtml } from '../utils/exportEditableHtml';
import {
  ReligiousEmblem,
  EMBLEM_OPTIONS,
  EmblemOption,
} from './ReligiousEmblem';
import {
  Copy,
  Plus,
  Trash2,
  Check,
  Download,
  Upload,
  FileCode,
  FileText,
  Clock,
  Edit3,
  X,
  Sparkles,
  ChevronRight,
  Save,
  Palette,
  Image as ImageIcon,
} from 'lucide-react';

interface SavedCopiesModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentConfig: CarneConfig;
  onSelectConfig: (config: CarneConfig, copyName: string) => void;
  activeCopyId: string;
  setActiveCopyId: (id: string) => void;
  savedCopies: SavedCarneCopy[];
  setSavedCopies: React.Dispatch<React.SetStateAction<SavedCarneCopy[]>>;
}

interface QuickTemplate {
  name: string;
  eventName: string;
  subtitle: string;
  tagline: string;
  emblemType: EmblemType;
  badge: string;
  color: string;
}

const TEMPLATES: QuickTemplate[] = [
  {
    name: 'Crisma - Iniciação Cristã',
    eventName: 'Carnê de contribuição para o Crisma',
    subtitle: 'Iniciação Cristã de Jovens e Adultos',
    tagline: 'CRISMA · CONFIRMAÇÃO',
    emblemType: 'iniciacao_crista',
    badge: 'Crisma Oficial',
    color: 'border-amber-400 bg-amber-50/50',
  },
  {
    name: 'Crisma - Espírito Santo Radiante',
    eventName: 'Carnê da Pastoral da Confirmação',
    subtitle: 'Sacramento do Crisma · Dons do Espírito',
    tagline: 'VINDE, ESPÍRITO SANTO',
    emblemType: 'espirito_santo',
    badge: 'Espírito Santo',
    color: 'border-rose-400 bg-rose-50/50',
  },
  {
    name: 'Primeira Eucaristia / Comunhão',
    eventName: 'Carnê da Primeira Eucaristia',
    subtitle: 'Iniciação à Mesa do Senhor · Comunhão',
    tagline: 'CORPO E SANGUE DE CRISTO',
    emblemType: 'calice_eucaristia',
    badge: 'Eucaristia',
    color: 'border-yellow-400 bg-yellow-50/50',
  },
  {
    name: 'Nossa Senhora Aparecida',
    eventName: 'Carnê da Padroeira do Brasil',
    subtitle: 'Comunidade Nossa Senhora Aparecida',
    tagline: 'ROGAI POR NÓS',
    emblemType: 'nossa_senhora_aparecida',
    badge: 'Mariano',
    color: 'border-blue-400 bg-blue-50/50',
  },
  {
    name: 'Medalha Milagrosa (N. Sra. das Graças)',
    eventName: 'Carnê da Capela N. Sra. das Graças',
    subtitle: 'Pastoral Mariana e Oração',
    tagline: 'MARIA CONCEBIDA SEM PECADO',
    emblemType: 'medalha_milagrosa',
    badge: 'Milagrosa',
    color: 'border-sky-400 bg-sky-50/50',
  },
  {
    name: 'Dízimo & Salvação (Cruz Sagrada)',
    eventName: 'Carnê de Contribuição Fraterna',
    subtitle: 'Pastoral do Dízimo · Manutenção Paroquial',
    tagline: 'CRISTO É NOSSA PAZ',
    emblemType: 'cruz_sagrada',
    badge: 'Dízimo / Cruz',
    color: 'border-emerald-400 bg-emerald-50/50',
  },
  {
    name: 'Sagrado Coração de Jesus',
    eventName: 'Carnê do Sagrado Coração',
    subtitle: 'Apostolado da Oração e Misericórdia',
    tagline: 'MANSO E HUMILDE DE CORAÇÃO',
    emblemType: 'sagrado_coracao',
    badge: 'Devoção',
    color: 'border-red-400 bg-red-50/50',
  },
  {
    name: 'Pastoral da Palavra & Luz',
    eventName: 'Carnê da Pastoral Bíblica-Catequética',
    subtitle: 'Luz de Cristo no Mundo · Sagradas Escrituras',
    tagline: 'TUA PALAVRA É LUZ',
    emblemType: 'biblia_vela',
    badge: 'Bíblia',
    color: 'border-purple-400 bg-purple-50/50',
  },
];

export const SavedCopiesModal: React.FC<SavedCopiesModalProps> = ({
  isOpen,
  onClose,
  currentConfig,
  onSelectConfig,
  activeCopyId,
  setActiveCopyId,
  savedCopies,
  setSavedCopies,
}) => {
  const [newCopyName, setNewCopyName] = useState('');
  const [newCopyEmblem, setNewCopyEmblem] = useState<EmblemType>(currentConfig.emblemType || 'iniciacao_crista');
  const [isCreating, setIsCreating] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState('');
  const [activeTab, setActiveTab] = useState<'list' | 'quick_edit' | 'templates'>('list');
  const [showEmblemQuickChangeId, setShowEmblemQuickChangeId] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCreateNew = (emblemToUse?: EmblemType) => {
    const emblem = emblemToUse || newCopyEmblem;
    const name = newCopyName.trim() || `Cópia Editável ${savedCopies.length + 1}`;
    const newCopy: SavedCarneCopy = {
      id: `copy_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      name,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      config: {
        ...currentConfig,
        emblemType: emblem,
        customImageUrl: undefined,
      },
    };

    const updated = [newCopy, ...savedCopies];
    setSavedCopies(updated);
    setActiveCopyId(newCopy.id);
    onSelectConfig(newCopy.config, newCopy.name);
    setNewCopyName('');
    setIsCreating(false);
  };

  const handleCreateFromTemplate = (template: QuickTemplate) => {
    const newCopy: SavedCarneCopy = {
      id: `copy_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      name: template.name,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      config: {
        ...currentConfig,
        eventName: template.eventName,
        subtitle: template.subtitle,
        tagline: template.tagline,
        emblemType: template.emblemType,
        customImageUrl: undefined,
      },
    };

    const updated = [newCopy, ...savedCopies];
    setSavedCopies(updated);
    setActiveCopyId(newCopy.id);
    onSelectConfig(newCopy.config, newCopy.name);
    setActiveTab('list');
  };

  const handleChangeCopyEmblem = (copyId: string, newEmblem: EmblemType) => {
    const updated = savedCopies.map((c) =>
      c.id === copyId
        ? {
            ...c,
            updatedAt: Date.now(),
            config: { ...c.config, emblemType: newEmblem, customImageUrl: undefined },
          }
        : c
    );
    setSavedCopies(updated);
    if (activeCopyId === copyId) {
      const active = updated.find((c) => c.id === copyId);
      if (active) onSelectConfig(active.config, active.name);
    }
    setShowEmblemQuickChangeId(null);
  };

  const handleDuplicate = (copy: SavedCarneCopy) => {
    const duplicated: SavedCarneCopy = {
      id: `copy_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      name: `Cópia de ${copy.name}`,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      config: JSON.parse(JSON.stringify(copy.config)),
    };

    const updated = [duplicated, ...savedCopies];
    setSavedCopies(updated);
    setActiveCopyId(duplicated.id);
    onSelectConfig(duplicated.config, duplicated.name);
  };

  const handleDelete = (id: string) => {
    if (savedCopies.length <= 1) {
      alert('Você precisa ter pelo menos uma cópia.');
      return;
    }
    const updated = savedCopies.filter((c) => c.id !== id);
    setSavedCopies(updated);
    if (activeCopyId === id) {
      const fallback = updated[0];
      setActiveCopyId(fallback.id);
      onSelectConfig(fallback.config, fallback.name);
    }
  };

  const handleRename = (id: string) => {
    if (!editingName.trim()) {
      setEditingId(null);
      return;
    }
    const updated = savedCopies.map((c) =>
      c.id === id ? { ...c, name: editingName.trim(), updatedAt: Date.now() } : c
    );
    setSavedCopies(updated);
    setEditingId(null);
    setEditingName('');
  };

  const handleExportJson = (copy: SavedCarneCopy) => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(copy, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${copy.name.toLowerCase().replace(/\s+/g, '-')}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.config && parsed.name) {
          const importedCopy: SavedCarneCopy = {
            id: `copy_${Date.now()}`,
            name: `${parsed.name} (Importada)`,
            createdAt: Date.now(),
            updatedAt: Date.now(),
            config: { ...DEFAULT_CONFIG, ...parsed.config },
          };
          const updated = [importedCopy, ...savedCopies];
          setSavedCopies(updated);
          setActiveCopyId(importedCopy.id);
          onSelectConfig(importedCopy.config, importedCopy.name);
        } else if (parsed.eventName) {
          const importedCopy: SavedCarneCopy = {
            id: `copy_${Date.now()}`,
            name: `Cópia Importada ${savedCopies.length + 1}`,
            createdAt: Date.now(),
            updatedAt: Date.now(),
            config: { ...DEFAULT_CONFIG, ...parsed },
          };
          const updated = [importedCopy, ...savedCopies];
          setSavedCopies(updated);
          setActiveCopyId(importedCopy.id);
          onSelectConfig(importedCopy.config, importedCopy.name);
        }
      } catch (err) {
        alert('Arquivo inválido ou corrompido.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleCustomImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const result = ev.target?.result as string;
      onSelectConfig(
        {
          ...currentConfig,
          customImageUrl: result,
          emblemType: 'custom',
        },
        activeCopy.name
      );
    };
    reader.readAsDataURL(file);
  };

  const activeCopy = savedCopies.find((c) => c.id === activeCopyId) || savedCopies[0] || {
    id: 'default',
    name: 'Cópia Principal',
    config: currentConfig,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden">
        {/* MODAL HEADER */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold shadow-2xs">
              <Copy className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900 tracking-tight flex items-center gap-2">
                Gerenciador de Cópias & Símbolos
                <span className="text-[10px] bg-blue-600 text-white font-bold px-2 py-0.5 rounded-full uppercase">
                  {savedCopies.length} {savedCopies.length === 1 ? 'Versão' : 'Versões'}
                </span>
              </h3>
              <p className="text-xs text-slate-500">
                Personalize símbolos sacros, textos, valores e numerações de cada cópia de forma independente.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/50 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* NAVIGATION TABS */}
        <div className="px-5 pt-3 pb-2 border-b border-slate-100 flex flex-wrap items-center justify-between gap-2 bg-white">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setActiveTab('list')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                activeTab === 'list'
                  ? 'bg-blue-600 text-white shadow-2xs font-bold'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              Minhas Cópias ({savedCopies.length})
            </button>
            <button
              onClick={() => setActiveTab('quick_edit')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'quick_edit'
                  ? 'bg-blue-600 text-white shadow-2xs font-bold'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Palette className="w-3.5 h-3.5" />
              Editar Textos & Símbolos
            </button>
            <button
              onClick={() => setActiveTab('templates')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'templates'
                  ? 'bg-blue-600 text-white shadow-2xs font-bold'
                  : 'bg-amber-100 text-amber-900 hover:bg-amber-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              Modelos Rápidos com Símbolos
            </button>
          </div>

          {/* QUICK ACTIONS */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => downloadEditableHtml(currentConfig, activeCopy?.name || 'Carnê')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold transition-colors shadow-2xs cursor-pointer"
              title="Baixar arquivo HTML autônomo com textos editáveis para abrir em qualquer navegador ou Word"
            >
              <FileCode className="w-3.5 h-3.5" />
              Baixar Cópia (.html)
            </button>
          </div>
        </div>

        {/* MODAL BODY */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {activeTab === 'list' ? (
            <>
              {/* ACTION BAR: CREATE NEW COPY / DUPLICATE / IMPORT */}
              <div className="flex flex-wrap items-center justify-between gap-2 bg-blue-50/60 border border-blue-200/70 p-3 rounded-xl">
                <div>
                  <h4 className="text-xs font-bold text-blue-950 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                    Cópia Selecionada: <span className="underline">{activeCopy?.name}</span>
                  </h4>
                  <p className="text-[11px] text-blue-800">
                    Você pode criar quantas cópias editáveis quiser com símbolos, números e valores diferentes.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {!isCreating ? (
                    <button
                      onClick={() => setIsCreating(true)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold cursor-pointer transition-colors shadow-2xs"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Criar Nova Cópia
                    </button>
                  ) : (
                    <div className="flex flex-wrap items-center gap-1.5 bg-white p-1 rounded-lg border border-blue-300">
                      <input
                        type="text"
                        value={newCopyName}
                        onChange={(e) => setNewCopyName(e.target.value)}
                        placeholder="Nome da nova cópia..."
                        className="px-2.5 py-1 text-xs border border-slate-300 rounded-md outline-none focus:ring-1 focus:ring-blue-500 font-medium"
                        autoFocus
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleCreateNew();
                          if (e.key === 'Escape') setIsCreating(false);
                        }}
                      />
                      <select
                        value={newCopyEmblem}
                        onChange={(e) => setNewCopyEmblem(e.target.value as EmblemType)}
                        className="text-[11px] font-semibold border border-slate-300 rounded px-1.5 py-1 bg-white"
                        title="Escolha o símbolo desta nova cópia"
                      >
                        {EMBLEM_OPTIONS.map((opt) => (
                          <option key={opt.id} value={opt.id}>
                            {opt.title}
                          </option>
                        ))}
                      </select>
                      <button
                        onClick={() => handleCreateNew()}
                        className="px-2.5 py-1 bg-blue-600 text-white rounded-md text-xs font-bold hover:bg-blue-700 cursor-pointer"
                      >
                        Salvar
                      </button>
                      <button
                        onClick={() => setIsCreating(false)}
                        className="px-2 py-1 bg-slate-200 text-slate-700 rounded-md text-xs hover:bg-slate-300 cursor-pointer"
                      >
                        Cancelar
                      </button>
                    </div>
                  )}

                  <label className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 cursor-pointer transition-colors shadow-2xs">
                    <Upload className="w-3.5 h-3.5" />
                    Importar (.json)
                    <input
                      type="file"
                      accept=".json"
                      onChange={handleImportJson}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              {/* LIST OF COPIES */}
              <div className="space-y-2.5">
                {savedCopies.map((copy) => {
                  const isActive = copy.id === activeCopyId;
                  const isEditingThis = editingId === copy.id;
                  const emblemType = copy.config.emblemType || 'iniciacao_crista';
                  const emblemInfo = EMBLEM_OPTIONS.find((o) => o.id === emblemType) || EMBLEM_OPTIONS[0];

                  return (
                    <div
                      key={copy.id}
                      className={`p-3.5 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                        isActive
                          ? 'bg-blue-50/50 border-blue-400 shadow-xs ring-1 ring-blue-300'
                          : 'bg-white border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      {/* Copy Info & Symbol Badge */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          {/* Mini Emblem Visual Preview */}
                          <div
                            className="shrink-0 w-8 h-8 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-center p-0.5 cursor-pointer hover:border-blue-400 transition-colors"
                            title={`Símbolo atual: ${emblemInfo.title}. Clique para alterar o símbolo desta cópia.`}
                            onClick={() =>
                              setShowEmblemQuickChangeId(
                                showEmblemQuickChangeId === copy.id ? null : copy.id
                              )
                            }
                          >
                            <ReligiousEmblem
                              type={emblemType}
                              customImageUrl={copy.config.customImageUrl}
                              size={22}
                              isCompact={true}
                              showLabel={false}
                            />
                          </div>

                          {isEditingThis ? (
                            <div className="flex items-center gap-1.5">
                              <input
                                type="text"
                                value={editingName}
                                onChange={(e) => setEditingName(e.target.value)}
                                className="px-2 py-0.5 text-xs font-bold border border-blue-400 rounded outline-none"
                                autoFocus
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') handleRename(copy.id);
                                  if (e.key === 'Escape') setEditingId(null);
                                }}
                              />
                              <button
                                onClick={() => handleRename(copy.id)}
                                className="p-1 bg-blue-600 text-white rounded hover:bg-blue-700 cursor-pointer"
                              >
                                <Check className="w-3 h-3" />
                              </button>
                            </div>
                          ) : (
                            <h3 className="font-bold text-slate-900 text-sm truncate flex items-center gap-2">
                              {copy.name}
                              <button
                                onClick={() => {
                                  setEditingId(copy.id);
                                  setEditingName(copy.name);
                                }}
                                className="text-slate-400 hover:text-slate-600 p-0.5"
                                title="Renomear cópia"
                              >
                                <Edit3 className="w-3 h-3" />
                              </button>
                            </h3>
                          )}

                          {isActive && (
                            <span className="shrink-0 text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-600 text-white">
                              Ativa
                            </span>
                          )}

                          {/* Emblem name pill with quick changer */}
                          <button
                            onClick={() =>
                              setShowEmblemQuickChangeId(
                                showEmblemQuickChangeId === copy.id ? null : copy.id
                              )
                            }
                            className="shrink-0 inline-flex items-center gap-1 text-[10.5px] font-bold px-2 py-0.5 rounded-md bg-amber-50 text-amber-900 border border-amber-300 hover:bg-amber-100 cursor-pointer transition-colors"
                            title="Trocar o símbolo desta cópia"
                          >
                            <span>Símbolo: {emblemInfo.title}</span>
                            <Palette className="w-2.5 h-2.5 text-amber-700" />
                          </button>
                        </div>

                        {/* Quick Emblem Switcher Dropdown (when toggled) */}
                        {showEmblemQuickChangeId === copy.id && (
                          <div className="mt-2.5 p-2.5 bg-amber-50/90 border border-amber-300 rounded-xl animate-in fade-in duration-150">
                            <div className="text-[11px] font-bold text-amber-950 mb-1.5 flex items-center justify-between">
                              <span>Selecione o símbolo para "{copy.name}":</span>
                              <button
                                onClick={() => setShowEmblemQuickChangeId(null)}
                                className="text-amber-800 hover:text-amber-950 font-bold"
                              >
                                ✕
                              </button>
                            </div>
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                              {EMBLEM_OPTIONS.map((opt) => (
                                <button
                                  key={opt.id}
                                  onClick={() => handleChangeCopyEmblem(copy.id, opt.id)}
                                  className={`p-1.5 rounded-lg border text-left flex items-center gap-1.5 transition-all cursor-pointer ${
                                    emblemType === opt.id
                                      ? 'bg-amber-200/90 border-amber-500 font-bold text-amber-950 ring-1 ring-amber-400'
                                      : 'bg-white border-amber-200 hover:bg-amber-100/70 text-slate-800'
                                  }`}
                                >
                                  <div className="w-6 h-6 shrink-0 flex items-center justify-center">
                                    <ReligiousEmblem type={opt.id} size={18} isCompact={true} />
                                  </div>
                                  <span className="text-[10px] truncate leading-tight">{opt.title}</span>
                                </button>
                              ))}
                            </div>
                          </div>
                        )}

                        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500 mt-1">
                          <span className="font-semibold text-slate-700">
                            R$ {copy.config.value}
                          </span>
                          <span>·</span>
                          <span className="font-mono">
                            Nº {String(copy.config.startNumber).padStart(copy.config.digits, '0')} a{' '}
                            {String(copy.config.endNumber).padStart(copy.config.digits, '0')}
                          </span>
                          <span>·</span>
                          <span>{copy.config.itemsPerPage || 7} carnês por folha</span>
                          <span>·</span>
                          <span className="text-[11px] text-slate-400 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {new Date(copy.updatedAt).toLocaleDateString('pt-BR')}
                          </span>
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-1.5 shrink-0">
                        {!isActive ? (
                          <button
                            onClick={() => {
                              setActiveCopyId(copy.id);
                              onSelectConfig(copy.config, copy.name);
                            }}
                            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold rounded-lg cursor-pointer transition-colors"
                          >
                            Carregar Cópia
                          </button>
                        ) : (
                          <button
                            onClick={() => setActiveTab('quick_edit')}
                            className="px-3 py-1.5 bg-blue-100 hover:bg-blue-200 text-blue-900 text-xs font-bold rounded-lg cursor-pointer transition-colors"
                          >
                            Editar Textos & Símbolo
                          </button>
                        )}

                        <button
                          onClick={() => handleDuplicate(copy)}
                          className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg cursor-pointer transition-colors"
                          title="Duplicar cópia"
                        >
                          <Copy className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => downloadEditableHtml(copy.config, copy.name)}
                          className="p-1.5 text-emerald-700 hover:text-emerald-900 hover:bg-emerald-50 rounded-lg cursor-pointer transition-colors"
                          title="Baixar Cópia Editável (.html autônomo)"
                        >
                          <FileCode className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => handleExportJson(copy)}
                          className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg cursor-pointer transition-colors"
                          title="Exportar arquivo (.json)"
                        >
                          <Download className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => handleDelete(copy.id)}
                          disabled={savedCopies.length <= 1}
                          className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                          title="Excluir cópia"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          ) : activeTab === 'quick_edit' ? (
            /* QUICK EDIT OF ACTIVE COPY TEXTS & EMBLEMS */
            <div className="space-y-5">
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-xs text-slate-800 flex items-center gap-1.5">
                    <Edit3 className="w-3.5 h-3.5 text-blue-600" />
                    Personalizando cópia: <span className="text-blue-700 font-extrabold">{activeCopy?.name}</span>
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    Altere o símbolo religioso, títulos, subtítulos, campos e frases para personalizar totalmente o carnê desta cópia.
                  </p>
                </div>
                <button
                  onClick={() => setActiveTab('list')}
                  className="text-xs text-blue-700 font-bold hover:underline cursor-pointer"
                >
                  Voltar para lista
                </button>
              </div>

              {/* SEÇÃO PRINCIPAL: SELEÇÃO DE SÍMBOLO RELIGIOSO */}
              <div className="bg-gradient-to-r from-amber-50/60 via-white to-amber-50/60 border border-amber-300 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-extrabold text-sm text-amber-950 flex items-center gap-1.5">
                      <Palette className="w-4 h-4 text-amber-700" />
                      Símbolo Religioso Desta Cópia
                    </h4>
                    <p className="text-xs text-amber-900/80">
                      Escolha o selo sacro para estampar nos canhotos, comprovantes e capas dos carnês desta cópia:
                    </p>
                  </div>
                  <label className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-700 bg-white border border-slate-300 px-2.5 py-1.5 rounded-lg hover:bg-slate-50 cursor-pointer shadow-2xs">
                    <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
                    Carregar Imagem / Logo
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleCustomImageUpload}
                      className="hidden"
                    />
                  </label>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5 pt-1">
                  {EMBLEM_OPTIONS.map((opt) => {
                    const isSelected =
                      currentConfig.emblemType === opt.id && !currentConfig.customImageUrl;

                    return (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() =>
                          onSelectConfig(
                            {
                              ...currentConfig,
                              emblemType: opt.id,
                              customImageUrl: undefined,
                            },
                            activeCopy.name
                          )
                        }
                        className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer relative ${
                          isSelected
                            ? 'bg-amber-100/90 border-amber-500 shadow-xs ring-2 ring-amber-400'
                            : 'bg-white border-slate-200 hover:border-amber-300 hover:bg-amber-50/40'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <div className="w-12 h-14 shrink-0 flex items-center justify-center bg-slate-50/80 rounded-lg border border-slate-100 p-1">
                            <ReligiousEmblem type={opt.id} size={36} isCompact={true} />
                          </div>
                          <span className="text-[9px] font-black uppercase px-1.5 py-0.5 rounded-full bg-slate-100 text-slate-700">
                            {opt.badge || opt.category}
                          </span>
                        </div>

                        <div>
                          <div className="font-extrabold text-xs text-slate-900 leading-tight">
                            {opt.title}
                          </div>
                          <div className="text-[10px] text-slate-500 line-clamp-2 mt-0.5 leading-tight">
                            {opt.subtitle}
                          </div>
                        </div>

                        {isSelected && (
                          <div className="mt-2 text-[10px] font-bold text-amber-900 flex items-center gap-1">
                            <Check className="w-3 h-3 text-amber-700" />
                            <span>Símbolo Ativo</span>
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* CAMPOS DE TEXTO DA CÓPIA */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                {/* TÍTULO PRINCIPAL */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">
                    Título Principal do Carnê
                  </label>
                  <input
                    type="text"
                    value={currentConfig.eventName}
                    onChange={(e) =>
                      onSelectConfig({ ...currentConfig, eventName: e.target.value }, activeCopy.name)
                    }
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg font-medium outline-none focus:border-blue-500"
                  />
                </div>

                {/* SUBTÍTULO / LINHA 2 */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">
                    Subtítulo / Pastoral (Ex: Iniciação Cristã de Jovens e Adultos)
                  </label>
                  <input
                    type="text"
                    value={currentConfig.subtitle || ''}
                    placeholder="Iniciação Cristã de Jovens e Adultos"
                    onChange={(e) =>
                      onSelectConfig({ ...currentConfig, subtitle: e.target.value }, activeCopy.name)
                    }
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg font-medium outline-none focus:border-blue-500"
                  />
                </div>

                {/* TAGLINE / DETALHE */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">
                    Tagline Central (Ex: CRISMA · CONFIRMAÇÃO)
                  </label>
                  <input
                    type="text"
                    value={currentConfig.tagline || ''}
                    placeholder="CRISMA · CONFIRMAÇÃO"
                    onChange={(e) =>
                      onSelectConfig({ ...currentConfig, tagline: e.target.value }, activeCopy.name)
                    }
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg font-medium outline-none focus:border-blue-500"
                  />
                </div>

                {/* PARÓQUIA */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">
                    Nome da Paróquia
                  </label>
                  <input
                    type="text"
                    value={currentConfig.parishName}
                    onChange={(e) =>
                      onSelectConfig({ ...currentConfig, parishName: e.target.value }, activeCopy.name)
                    }
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg font-medium outline-none focus:border-blue-500"
                  />
                </div>

                {/* CAPELA */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">
                    Nome da Capela / Comunidade
                  </label>
                  <input
                    type="text"
                    value={currentConfig.chapelName || ''}
                    placeholder="Ex: Capela Nossa Senhora das Graças"
                    onChange={(e) =>
                      onSelectConfig({ ...currentConfig, chapelName: e.target.value }, activeCopy.name)
                    }
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg font-medium outline-none focus:border-blue-500"
                  />
                </div>

                {/* VALOR */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">
                    Valor (R$)
                  </label>
                  <input
                    type="text"
                    value={currentConfig.value}
                    onChange={(e) =>
                      onSelectConfig({ ...currentConfig, value: e.target.value }, activeCopy.name)
                    }
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg font-bold outline-none focus:border-blue-500 font-mono"
                  />
                </div>

                {/* CHAVE PIX */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">
                    Chave PIX
                  </label>
                  <input
                    type="text"
                    value={currentConfig.pixKey}
                    onChange={(e) =>
                      onSelectConfig({ ...currentConfig, pixKey: e.target.value }, activeCopy.name)
                    }
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg font-medium outline-none focus:border-blue-500 font-mono"
                  />
                </div>

                {/* RÓTULO DO CANHOTO */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">
                    Rótulo do Canhoto (Padrão: VIA CONTROLE)
                  </label>
                  <input
                    type="text"
                    value={currentConfig.stubLabel || 'VIA CONTROLE'}
                    onChange={(e) =>
                      onSelectConfig({ ...currentConfig, stubLabel: e.target.value }, activeCopy.name)
                    }
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg font-medium outline-none focus:border-blue-500"
                  />
                </div>

                {/* RÓTULO DO CAMPO 1 */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">
                    Rótulo Data (Padrão: DATA DO PAGAMENTO)
                  </label>
                  <input
                    type="text"
                    value={currentConfig.fieldPaymentDate || 'DATA DO PAGAMENTO'}
                    onChange={(e) =>
                      onSelectConfig({ ...currentConfig, fieldPaymentDate: e.target.value }, activeCopy.name)
                    }
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg font-medium outline-none focus:border-blue-500"
                  />
                </div>

                {/* RÓTULO DO CAMPO 2 */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">
                    Rótulo Recebedor (Padrão: RECEBIDO POR)
                  </label>
                  <input
                    type="text"
                    value={currentConfig.fieldReceivedBy || 'RECEBIDO POR'}
                    onChange={(e) =>
                      onSelectConfig({ ...currentConfig, fieldReceivedBy: e.target.value }, activeCopy.name)
                    }
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg font-medium outline-none focus:border-blue-500"
                  />
                </div>

                {/* RÓTULO DO CAMPO 3 */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">
                    Rótulo Aluno/Fiel (Padrão: CRISMANDO(A))
                  </label>
                  <input
                    type="text"
                    value={currentConfig.fieldCandidate || 'CRISMANDO(A)'}
                    onChange={(e) =>
                      onSelectConfig({ ...currentConfig, fieldCandidate: e.target.value }, activeCopy.name)
                    }
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg font-medium outline-none focus:border-blue-500"
                  />
                </div>

                {/* FRASE DE RODAPÉ */}
                <div className="space-y-1 md:col-span-2">
                  <label className="font-bold text-slate-700 block">
                    Aviso de Rodapé
                  </label>
                  <input
                    type="text"
                    value={currentConfig.footerNotice || '* Guarde este comprovante para a Pastoral do Crisma.'}
                    onChange={(e) =>
                      onSelectConfig({ ...currentConfig, footerNotice: e.target.value }, activeCopy.name)
                    }
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg font-medium outline-none focus:border-blue-500"
                  />
                </div>
              </div>
            </div>
          ) : (
            /* TEMPLATES TAB: PRESETS COM SÍMBOLOS DIFERENTES */
            <div className="space-y-4">
              <div className="bg-amber-50/70 border border-amber-200 rounded-xl p-3 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-xs text-amber-950 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                    Modelos Rápidos com Símbolos Litúrgicos
                  </h4>
                  <p className="text-[11px] text-amber-800">
                    Crie uma nova cópia imediatamente com o símbolo sagrado e textos preparados para o sacramento:
                  </p>
                </div>
                <button
                  onClick={() => setActiveTab('list')}
                  className="text-xs text-amber-900 font-bold hover:underline cursor-pointer"
                >
                  Voltar para lista
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {TEMPLATES.map((tmpl, idx) => (
                  <div
                    key={idx}
                    className={`p-4 rounded-xl border ${tmpl.color} flex items-start justify-between gap-3 shadow-2xs hover:shadow-xs transition-all`}
                  >
                    <div className="w-14 h-16 shrink-0 flex items-center justify-center bg-white rounded-lg border border-slate-200 p-1">
                      <ReligiousEmblem type={tmpl.emblemType} size={42} isCompact={true} />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 mb-1">
                        <span className="text-[9px] font-black uppercase px-1.5 py-0.2 rounded-full bg-white text-slate-800 border border-slate-200">
                          {tmpl.badge}
                        </span>
                        <h4 className="font-extrabold text-sm text-slate-900 truncate">
                          {tmpl.name}
                        </h4>
                      </div>
                      <p className="text-xs font-semibold text-slate-700 line-clamp-1">
                        {tmpl.eventName}
                      </p>
                      <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                        {tmpl.subtitle}
                      </p>

                      <button
                        onClick={() => handleCreateFromTemplate(tmpl)}
                        className="mt-3 inline-flex items-center gap-1.5 px-3 py-1 bg-slate-900 hover:bg-black text-white text-xs font-bold rounded-lg cursor-pointer transition-colors shadow-2xs"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        Criar Esta Cópia
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* MODAL FOOTER */}
        <div className="px-5 py-3 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <div className="text-xs text-slate-500">
            Dica: Cada cópia mantém seu próprio símbolo religioso, textos e numeração salvos automaticamente.
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-bold cursor-pointer transition-colors"
          >
            Concluir & Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
