import React, { useRef, useState } from 'react';
import { CarneConfig } from '../types';
import { CarneTicket } from './CarneTicket';
import { downloadElementAsImage } from '../utils/exportImage';
import { Download, ChevronLeft, ChevronRight, Eye, Check } from 'lucide-react';

interface SingleTicketPreviewProps {
  currentNumber: number;
  config: CarneConfig;
  onNumberChange: (n: number) => void;
}

export const SingleTicketPreview: React.FC<SingleTicketPreviewProps> = ({
  currentNumber,
  config,
  onNumberChange,
}) => {
  const ticketRef = useRef<HTMLDivElement>(null);
  const [downloading, setDownloading] = useState(false);

  const handleDownload = async () => {
    if (!ticketRef.current) return;
    try {
      setDownloading(true);
      const formatted = String(currentNumber).padStart(config.digits, '0');
      await downloadElementAsImage(
        ticketRef.current,
        `carne-crisma-n${formatted}-r$${config.value}.png`,
        3
      );
    } catch (err) {
      console.error(err);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-5 border-b border-slate-100 pb-4">
        <div>
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Eye className="w-4 h-4 text-blue-600" />
            Visualização Individual em Alta Definição
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Visualize o canhoto destacável, o comprovante com o PIX, carimbo sagrado e numeração.
          </p>
        </div>

        {/* Number Selector controls */}
        <div className="flex items-center gap-2">
          <div className="flex items-center border border-slate-200 rounded-lg p-1 bg-slate-50">
            <button
              onClick={() => onNumberChange(Math.max(config.startNumber, currentNumber - 1))}
              disabled={currentNumber <= config.startNumber}
              className="p-1.5 hover:bg-white rounded text-slate-700 disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed"
              title="Carnê anterior"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <div className="px-3 text-center">
              <span className="text-[10px] uppercase font-bold text-slate-400 block -mb-0.5">
                Nº
              </span>
              <span className="text-base font-black text-rose-700 font-mono">
                {String(currentNumber).padStart(config.digits, '0')}
              </span>
            </div>

            <button
              onClick={() => onNumberChange(Math.min(config.endNumber, currentNumber + 1))}
              disabled={currentNumber >= config.endNumber}
              className="p-1.5 hover:bg-white rounded text-slate-700 disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed"
              title="Próximo carnê"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={handleDownload}
            disabled={downloading}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            {downloading ? 'Gerando Imagem...' : 'Baixar Imagem deste Carnê (PNG)'}
          </button>
        </div>
      </div>

      {/* Ticket Showcase in crisp size */}
      <div className="bg-slate-100/70 p-6 rounded-xl flex items-center justify-center overflow-x-auto border border-slate-200">
        <div
          ref={ticketRef}
          className="w-[780px] shrink-0 bg-white shadow-md rounded-xs transform transition-transform"
        >
          <CarneTicket number={currentNumber} config={config} isSinglePreview />
        </div>
      </div>

      <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
            Canhoto destacável com picote
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
            QR Code PIX com confirmação
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
            Medalha Milagrosa em alta definição
          </span>
        </div>

        <span className="font-mono text-slate-400">
          Formato: 198mm × 54mm (Proporção 1:5 por página A4)
        </span>
      </div>
    </div>
  );
};
