export type EmblemType =
  | 'iniciacao_crista'
  | 'espirito_santo'
  | 'medalha_milagrosa'
  | 'nossa_senhora_aparecida'
  | 'calice_eucaristia'
  | 'cruz_sagrada'
  | 'sagrado_coracao'
  | 'biblia_vela'
  | 'custom';

export interface CarneConfig {
  eventName: string; // e.g. "Carnê de contribuição para o Crisma"
  subtitle?: string; // e.g. "Iniciação Cristã de Jovens e Adultos"
  tagline?: string; // e.g. "CRISMA · CONFIRMAÇÃO"
  chapelName: string; // e.g. "Capela Nossa Senhora das Graças"
  parishName: string; // e.g. "Paróquia Nossa Senhora da Apresentação"
  value: string; // e.g. "65,00"
  startNumber: number; // e.g. 1
  endNumber: number; // e.g. 200
  digits: number; // 3 -> "001"
  bankName: string; // e.g. "PIX Bradesco"
  phoneContact: string; // e.g. "(21) 97502-7607"
  pixKey: string; // PIX payload or key
  style: 'banner_top' | 'photo_classic' | 'modern_crisma';
  emblemType: EmblemType;
  coverStyle: 'iniciacao_crista' | 'hibrido_sagrado' | 'capela_mariana';
  customImageUrl?: string;
  showCrismandoField: boolean;
  showPix: boolean;
  itemsPerPage: number;
  watermarkOpacity: number;
  // Custom editable field labels for copies
  stubLabel?: string; // default "VIA CONTROLE"
  fieldPaymentDate?: string; // default "DATA DO PAGAMENTO"
  fieldReceivedBy?: string; // default "RECEBIDO POR"
  fieldCandidate?: string; // default "CRISMANDO(A)"
  footerNotice?: string; // default "* Guarde este comprovante para a Pastoral do Crisma."
  footerGreeting?: string; // default "Paz e Bem!"
  coverValueLabel?: string; // default "VALOR UNITÁRIO"
  coverStubLabel?: string; // default "Nº TALÃO"
  // Personalização Exclusiva da Página 1
  page1Override?: Page1Override;
}

export interface Page1TicketOverride {
  value?: string;
  candidateName?: string;
  notes?: string;
}

export interface Page1Override {
  enabled: boolean;
  eventName?: string;
  subtitle?: string;
  tagline?: string;
  chapelName?: string;
  parishName?: string;
  value?: string;
  pixKey?: string;
  bankName?: string;
  phoneContact?: string;
  emblemType?: EmblemType;
  customImageUrl?: string;
  showPix?: boolean;
  stubLabel?: string;
  fieldPaymentDate?: string;
  fieldReceivedBy?: string;
  fieldCandidate?: string;
  footerNotice?: string;
  footerGreeting?: string;
  // Customizações individuais por carnê da página 1 (nº 1 a 7)
  tickets?: Record<number, Page1TicketOverride>;
}

export function getEffectivePageConfig(config: CarneConfig, pageNumber: number): CarneConfig {
  if (pageNumber === 1 && config.page1Override && config.page1Override.enabled) {
    const { enabled, tickets, ...overrides } = config.page1Override;
    const clean: Partial<CarneConfig> = {};
    for (const [key, val] of Object.entries(overrides)) {
      if (val !== undefined && val !== '') {
        (clean as any)[key] = val;
      }
    }
    return {
      ...config,
      ...clean,
    };
  }
  return config;
}

export interface SavedCarneCopy {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  config: CarneConfig;
}

export const DEFAULT_CONFIG: CarneConfig = {
  eventName: 'Carnê de contribuição para o Crisma',
  subtitle: 'Iniciação Cristã de Jovens e Adultos',
  tagline: 'CRISMA · CONFIRMAÇÃO',
  chapelName: '',
  parishName: 'PARÓQUIA N S DA APRESENTAÇÃO',
  value: '65,00',
  startNumber: 1,
  endNumber: 200,
  digits: 3,
  bankName: 'PIX Bradesco',
  phoneContact: '(21) 97502-7607',
  pixKey: 'Icja.apresentacao@gmail.com',
  style: 'photo_classic',
  emblemType: 'iniciacao_crista',
  coverStyle: 'iniciacao_crista',
  showCrismandoField: true,
  showPix: false,
  itemsPerPage: 7,
  watermarkOpacity: 0.12,
  stubLabel: 'VIA CONTROLE',
  fieldPaymentDate: 'DATA DO PAGAMENTO',
  fieldReceivedBy: 'RECEBIDO POR',
  fieldCandidate: 'CRISMANDO(A)',
  footerNotice: '* Guarde este comprovante para a Pastoral do Crisma.',
  footerGreeting: 'Paz e Bem!',
  coverValueLabel: 'VALOR UNITÁRIO',
  coverStubLabel: 'Nº TALÃO',
};
