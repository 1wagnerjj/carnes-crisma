import { CarneConfig } from '../types';

function getEmblemSvg(type?: string): string {
  switch (type) {
    case 'espirito_santo':
      return `<svg width="40" height="40" viewBox="0 0 100 100" fill="none"><circle cx="50" cy="50" r="30" stroke="#ca8a04" stroke-width="1.5" stroke-dasharray="3 2"/><path d="M50,42 C38,30 20,32 14,40 C22,46 34,48 44,48 C40,54 36,66 42,74 C47,67 48,58 50,52 C52,58 53,67 58,74 C64,66 60,54 56,48 C66,48 78,46 86,40 C80,32 62,30 50,42 Z" fill="#ffffff" stroke="#1e3a8a" stroke-width="2"/><path d="M47,38 C47,32 53,32 53,38 C53,46 54,52 50,56 C46,52 47,46 47,38 Z" fill="#ffffff" stroke="#1e3a8a" stroke-width="2"/></svg>`;
    case 'medalha_milagrosa':
      return `<svg width="34" height="44" viewBox="0 0 100 130" fill="none"><ellipse cx="50" cy="65" rx="42" ry="55" fill="#fef08a" stroke="#ca8a04" stroke-width="3"/><circle cx="50" cy="30" r="8" fill="#78350f"/><path d="M41,36 C37,50 34,75 31,105 C42,107 58,107 69,105 C66,75 63,50 59,36 Z" fill="#78350f"/></svg>`;
    case 'nossa_senhora_aparecida':
      return `<svg width="36" height="45" viewBox="0 0 100 125" fill="none"><path d="M50,22 C56,26 80,82 82,106 C72,112 28,112 18,106 C20,82 44,26 50,22 Z" fill="#1e3a8a" stroke="#eab308" stroke-width="3"/><ellipse cx="50" cy="30" rx="7" ry="8" fill="#5c381e"/></svg>`;
    case 'calice_eucaristia':
      return `<svg width="36" height="45" viewBox="0 0 100 125" fill="none"><circle cx="50" cy="34" r="17" fill="#ffffff" stroke="#ca8a04" stroke-width="2"/><text x="50" y="38" font-size="8" font-weight="bold" fill="#854d0e" text-anchor="middle">JHS</text><path d="M30,52 C30,76 43,84 47,85 L47,98 L40,102 C36,104 35,108 35,112 L65,112 C65,108 64,104 60,102 L53,98 L53,85 C57,84 70,76 70,52 Z" fill="#facc15" stroke="#78350f" stroke-width="2"/></svg>`;
    case 'cruz_sagrada':
      return `<svg width="36" height="45" viewBox="0 0 100 125" fill="none"><rect x="45" y="14" width="10" height="98" rx="2" fill="#eab308" stroke="#78350f" stroke-width="2"/><rect x="22" y="38" width="56" height="10" rx="2" fill="#eab308" stroke="#78350f" stroke-width="2"/></svg>`;
    case 'sagrado_coracao':
      return `<svg width="36" height="45" viewBox="0 0 100 125" fill="none"><path d="M50,52 C42,42 22,46 22,64 C22,82 44,98 50,108 C56,98 78,82 78,64 C78,46 58,42 50,52 Z" fill="#ef4444" stroke="#7f1d1d" stroke-width="2.5"/><ellipse cx="50" cy="70" rx="25" ry="6" fill="none" stroke="#78350f" stroke-width="2"/></svg>`;
    case 'biblia_vela':
      return `<svg width="38" height="45" viewBox="0 0 100 125" fill="none"><path d="M16,80 C32,74 48,78 50,80 C52,78 68,74 84,80 L86,104 C70,98 52,102 50,104 C48,102 30,98 14,104 Z" fill="#fef9c3" stroke="#ca8a04" stroke-width="2"/><rect x="46" y="30" width="8" height="30" rx="1" fill="#fef9c3" stroke="#ca8a04" stroke-width="1.5"/><ellipse cx="50" cy="20" rx="3" ry="6" fill="#f59e0b"/></svg>`;
    default:
      return `<svg width="36" height="45" viewBox="0 0 200 250" fill="none"><circle cx="86" cy="115" r="35" fill="#facc15"/><rect x="83.5" y="55" width="5.5" height="110" rx="0.8" fill="#18181b"/><rect x="52" y="96" width="70" height="5.5" rx="0.8" fill="#18181b"/><path d="M65,105 C60,85 70,60 88,48 C95,45 105,48 102,58 C96,75 88,95 82,112 Z" fill="#ffffff" stroke="#1e293b" stroke-width="2"/><path d="M84,15 C70,40 35,75 35,120 C35,160 65,195 80,210 C70,185 52,150 54,120 C56,90 75,50 84,15 Z" fill="#f59e0b"/></svg>`;
  }
}

/**
 * Generates and downloads a complete standalone, offline-ready HTML document
 * where every single text field has `contenteditable="true"`.
 * This enables the user to open the file in any browser or Microsoft Word,
 * click anywhere, edit values, names, dates, numbers, and print directly.
 */
export function downloadEditableHtml(config: CarneConfig, copyTitle = 'Cópia Editável'): void {
  const itemsPerPage = config.itemsPerPage || 7;
  const totalTickets = config.endNumber - config.startNumber + 1;
  const totalPages = Math.ceil(totalTickets / itemsPerPage);

  const eventName = config.eventName || 'Carnê de contribuição para o Crisma';
  const subtitle = config.subtitle || 'Iniciação Cristã de Jovens e Adultos';
  const parishName = config.parishName || 'PARÓQUIA N S DA APRESENTAÇÃO';
  const value = config.value || '65,00';
  const pixKey = config.pixKey || 'Icja.apresentacao@gmail.com';
  const stubLabel = config.stubLabel || 'VIA CONTROLE';
  const fieldDate = config.fieldPaymentDate || 'DATA DO PAGAMENTO';
  const fieldReceived = config.fieldReceivedBy || 'RECEBIDO POR';
  const fieldCandidate = config.fieldCandidate || 'CRISMANDO(A)';
  const footerNotice = config.footerNotice || '* Guarde este comprovante para a Pastoral do Crisma.';
  const footerGreeting = config.footerGreeting || 'Paz e Bem!';

  let pagesHtml = '';

  for (let page = 1; page <= totalPages; page++) {
    const startNum = (page - 1) * itemsPerPage + config.startNumber;
    const endNum = Math.min(config.endNumber, page * itemsPerPage);

    let ticketsHtml = '';
    for (let num = startNum; num <= endNum; num++) {
      const formattedNum = String(num).padStart(config.digits, '0');

      ticketsHtml += `
      <div class="ticket">
        <!-- CANHOTO (STUB) -->
        <div class="stub">
          <div class="stub-header">
            <span class="label" contenteditable="true">${stubLabel}</span>
            <span class="num" contenteditable="true">Nº ${formattedNum}</span>
          </div>
          <div class="stub-value" contenteditable="true">VALOR R$ ${value}</div>
          ${
            pixKey
              ? `<div class="stub-pix"><span class="pix-tag">PIX:</span> <span contenteditable="true">${pixKey}</span></div>`
              : ''
          }
          <div class="stub-fields">
            <div>
              <div class="field-label" contenteditable="true">${fieldDate}</div>
              <div class="field-line" contenteditable="true">____ / ____ / ________</div>
            </div>
            <div>
              <div class="field-label" contenteditable="true">${fieldReceived}</div>
              <div class="field-line" contenteditable="true">&nbsp;</div>
            </div>
            ${
              config.showCrismandoField
                ? `<div>
              <div class="field-label" contenteditable="true">${fieldCandidate}</div>
              <div class="field-line" contenteditable="true">&nbsp;</div>
            </div>`
                : ''
            }
          </div>
        </div>

        <!-- PICOTE -->
        <div class="tear-line">
          <span>✂</span>
        </div>

        <!-- COMPROVANTE -->
        <div class="receipt">
          <div class="receipt-header">
            <div class="receipt-titles">
              <div class="event-title" contenteditable="true">${eventName}</div>
              <div class="parish-title" contenteditable="true">${parishName}</div>
            </div>
            <div class="receipt-num-box">
              <span class="num-label" contenteditable="true">NÚMERO</span>
              <div class="num-val" contenteditable="true">Nº ${formattedNum}</div>
            </div>
          </div>

          <div class="receipt-body">
            <div class="receipt-details">
              <div class="receipt-val-pix">
                <span class="value-highlight" contenteditable="true">VALOR R$ ${value}</span>
                ${
                  pixKey
                    ? `<div class="pix-badge">
                  <span>PIX:</span>
                  <span class="pix-code" contenteditable="true">${pixKey}</span>
                </div>`
                    : ''
                }
              </div>

              <div class="receipt-grid">
                <div>
                  <span class="field-label" contenteditable="true">${fieldDate}</span>
                  <span class="field-line" contenteditable="true">____ / ____ / ________</span>
                </div>
                <div>
                  <span class="field-label" contenteditable="true">${fieldReceived}</span>
                  <span class="field-line" contenteditable="true">&nbsp;</span>
                </div>
              </div>

              ${
                config.showCrismandoField
                  ? `<div>
                <span class="field-label" contenteditable="true">${fieldCandidate}</span>
                <span class="field-line" contenteditable="true">&nbsp;</span>
              </div>`
                  : ''
              }
            </div>

            <!-- EMBLEMA RELIGIOSO -->
            <div class="emblem-box">
              <div class="emblem-icon">${getEmblemSvg(config.emblemType)}</div>
              <div class="emblem-text" contenteditable="true">${subtitle}</div>
            </div>
          </div>

          <div class="receipt-footer">
            <span contenteditable="true">${footerNotice}</span>
            <span class="greeting" contenteditable="true">${footerGreeting}</span>
          </div>
        </div>
      </div>
      `;
    }

    pagesHtml += `
    <div class="page" id="page-${page}">
      <div class="page-meta no-print">
        <span contenteditable="true">${parishName} · ${eventName}</span>
        <span>Folha ${page} de ${totalPages} (Nº ${String(startNum).padStart(config.digits, '0')} a Nº ${String(endNum).padStart(config.digits, '0')})</span>
      </div>
      <div class="page-tickets">
        ${ticketsHtml}
      </div>
    </div>
    `;
  }

  const htmlContent = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>${copyTitle} - Carnês do Crisma</title>
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    body {
      background-color: #f1f5f9;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      color: #1e293b;
      line-height: 1.3;
    }

    /* BARRA DE FERRAMENTAS FIXA */
    .toolbar {
      position: sticky;
      top: 0;
      z-index: 999;
      background: #0f172a;
      color: #fff;
      padding: 12px 20px;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    .toolbar-title {
      font-weight: 700;
      font-size: 14px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .toolbar-actions {
      display: flex;
      gap: 10px;
      align-items: center;
    }
    .btn {
      cursor: pointer;
      border: none;
      padding: 8px 16px;
      border-radius: 6px;
      font-weight: 600;
      font-size: 13px;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      transition: background 0.2s;
    }
    .btn-print {
      background: #2563eb;
      color: #fff;
    }
    .btn-print:hover {
      background: #1d4ed8;
    }
    .btn-save {
      background: #059669;
      color: #fff;
    }
    .btn-save:hover {
      background: #047857;
    }
    .info-tip {
      font-size: 12px;
      color: #94a3b8;
    }

    /* FOLHAS A4 */
    .pages-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 24px;
      padding: 24px 0;
    }
    .page {
      background: #ffffff;
      width: 210mm;
      min-height: 297mm;
      height: 297mm;
      padding: 6mm;
      box-shadow: 0 4px 14px rgba(0,0,0,0.08);
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      position: relative;
    }
    .page-meta {
      font-size: 10px;
      color: #64748b;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 4px;
      margin-bottom: 4px;
    }
    .page-tickets {
      flex: 1;
      display: flex;
      flex-direction: column;
      border: 1px solid #cbd5e1;
      height: 100%;
    }

    /* CARNÊ INDIVIDUAL */
    .ticket {
      flex: 1;
      display: flex;
      border-bottom: 1px dashed #94a3b8;
      background: #ffffff;
      position: relative;
    }
    .ticket:last-child {
      border-bottom: none;
    }

    /* CANHOTO */
    .stub {
      width: 30%;
      background: #f8fafc;
      border-right: 1px dashed #94a3b8;
      padding: 6px 8px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      font-size: 9px;
    }
    .stub-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 2px;
    }
    .stub-header .label {
      font-weight: 800;
      color: #475569;
      font-size: 8px;
      text-transform: uppercase;
    }
    .stub-header .num {
      font-weight: 900;
      color: #be123c;
      font-family: monospace;
      font-size: 11px;
    }
    .stub-value {
      font-weight: 900;
      color: #0f172a;
      font-size: 11px;
      margin: 2px 0;
    }
    .stub-pix {
      background: #fef3c7;
      border: 1px solid #fde68a;
      padding: 2px 4px;
      border-radius: 4px;
      font-size: 8px;
      font-weight: 700;
      color: #92400e;
      word-break: break-all;
    }
    .stub-pix .pix-tag {
      color: #1e293b;
      font-weight: 900;
    }
    .stub-fields {
      display: flex;
      flex-direction: column;
      gap: 3px;
    }
    .field-label {
      font-size: 7px;
      font-weight: 700;
      color: #64748b;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .field-line {
      border-bottom: 1px solid #94a3b8;
      font-size: 8px;
      color: #64748b;
      min-height: 10px;
    }

    /* PICOTE */
    .tear-line {
      display: flex;
      align-items: center;
      justify-content: center;
      margin-left: -8px;
      z-index: 2;
    }
    .tear-line span {
      background: #fff;
      padding: 0 2px;
      font-size: 8px;
      color: #94a3b8;
      transform: rotate(-90deg);
    }

    /* COMPROVANTE */
    .receipt {
      flex: 1;
      padding: 6px 10px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }
    .receipt-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      border-bottom: 1px solid #f1f5f9;
      padding-bottom: 3px;
    }
    .event-title {
      font-weight: 900;
      font-size: 10px;
      color: #172554;
      text-transform: uppercase;
      letter-spacing: -0.2px;
    }
    .parish-title {
      font-weight: 700;
      font-size: 8px;
      color: #1e3a8a;
      text-transform: uppercase;
    }
    .receipt-num-box {
      text-align: right;
    }
    .num-label {
      font-size: 7px;
      font-weight: 800;
      color: #94a3b8;
      text-transform: uppercase;
    }
    .num-val {
      background: #fff1f2;
      border: 1px solid #fecdd3;
      color: #be123c;
      padding: 1px 6px;
      border-radius: 4px;
      font-weight: 900;
      font-family: monospace;
      font-size: 12px;
    }

    .receipt-body {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 12px;
      margin: 2px 0;
    }
    .receipt-details {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 4px;
    }
    .receipt-val-pix {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
    }
    .value-highlight {
      font-weight: 900;
      font-size: 12px;
      color: #0f172a;
    }
    .pix-badge {
      background: #fef3c7;
      border: 1px solid #f59e0b;
      padding: 2px 6px;
      border-radius: 4px;
      font-size: 9px;
      font-weight: 900;
      color: #1e293b;
      display: inline-flex;
      gap: 4px;
    }
    .pix-code {
      color: #be123c;
      font-family: monospace;
    }
    .receipt-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
    }

    .emblem-box {
      border-left: 1px solid #e2e8f0;
      padding-left: 8px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      min-width: 70px;
    }
    .cross {
      font-size: 22px;
      color: #92400e;
      line-height: 1;
    }
    .emblem-text {
      font-size: 6.5px;
      font-weight: 800;
      color: #78350f;
      text-transform: uppercase;
      margin-top: 2px;
    }

    .receipt-footer {
      font-size: 7px;
      color: #64748b;
      border-top: 1px solid #f1f5f9;
      padding-top: 2px;
      display: flex;
      justify-content: space-between;
    }
    .greeting {
      font-weight: 700;
      color: #1e3a8a;
    }

    /* DESTAQUE DE TEXTO EDITÁVEL AO PASSAR O MOUSE */
    [contenteditable="true"]:hover {
      outline: 1px dashed #3b82f6;
      background-color: #eff6ff;
      border-radius: 2px;
      cursor: text;
    }
    [contenteditable="true"]:focus {
      outline: 2px solid #2563eb;
      background-color: #dbeafe;
      border-radius: 2px;
    }

    /* REGRAS DE IMPRESSÃO */
    @media print {
      body {
        background: #fff;
      }
      .no-print, .toolbar {
        display: none !important;
      }
      .pages-container {
        padding: 0;
        gap: 0;
      }
      .page {
        box-shadow: none;
        padding: 0;
        margin: 0;
        width: 210mm;
        height: 297mm;
        page-break-after: always;
        break-after: page;
      }
      [contenteditable="true"]:hover, [contenteditable="true"]:focus {
        outline: none !important;
        background: transparent !important;
      }
      @page {
        size: A4 portrait;
        margin: 0;
      }
    }
  </style>
</head>
<body>
  <!-- BARRA DE CONTROLE SUPERIOR -->
  <header class="toolbar no-print">
    <div class="toolbar-title">
      <span>✏️ Cópia Editável: <strong>${copyTitle}</strong></span>
      <span class="info-tip">· Clique em qualquer texto para editar livremente</span>
    </div>
    <div class="toolbar-actions">
      <button class="btn btn-save" onclick="saveEditedHtml()">
        💾 Salvar Alterações (.html)
      </button>
      <button class="btn btn-print" onclick="window.print()">
        🖨️ Imprimir Carnês (Ctrl + P)
      </button>
    </div>
  </header>

  <main class="pages-container">
    ${pagesHtml}
  </main>

  <script>
    function saveEditedHtml() {
      // Clones the document, cleans up focus and triggers download of the updated file
      const docHtml = '<!DOCTYPE html>\\n' + document.documentElement.outerHTML;
      const blob = new Blob([docHtml], { type: 'text/html;charset=utf-8' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = '${copyTitle.toLowerCase().replace(/\\s+/g, '-')}-editado.html';
      document.body.appendChild(a);
      a.click();
      setTimeout(() => document.body.removeChild(a), 300);
    }
  </script>
</body>
</html>`;

  const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `carne-${copyTitle.toLowerCase().replace(/\s+/g, '-')}.html`;
  document.body.appendChild(link);
  link.click();
  setTimeout(() => {
    if (document.body.contains(link)) {
      document.body.removeChild(link);
    }
    URL.revokeObjectURL(url);
  }, 300);
}
