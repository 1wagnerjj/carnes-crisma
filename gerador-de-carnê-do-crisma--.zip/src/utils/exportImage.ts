import { toPng } from 'html-to-image';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import JSZip from 'jszip';

/**
 * Captures a DOM element as a high-quality PNG data URL with fallback mechanisms.
 */
export async function captureElementToDataUrl(
  element: HTMLElement,
  pixelRatio = 2
): Promise<string> {
  if (!element) {
    throw new Error('Elemento não encontrado para captura.');
  }

  // Small delay to ensure any layout updates are painted
  await new Promise((resolve) => setTimeout(resolve, 60));

  let dataUrl: string | null = null;
  let lastError: unknown = null;

  // STRATEGY 1: html-to-image with skipFonts
  try {
    const width = element.scrollWidth || element.offsetWidth || undefined;
    const height = element.scrollHeight || element.offsetHeight || undefined;

    dataUrl = await toPng(element, {
      quality: 0.98,
      pixelRatio,
      backgroundColor: '#ffffff',
      cacheBust: true,
      skipFonts: true, // Prevents CORS crashes on web fonts
      fontEmbedCSS: '',
      width,
      height,
    });
  } catch (err) {
    console.warn('html-to-image toPng falhou, tentando fallback com html2canvas...', err);
    lastError = err;
  }

  // STRATEGY 2: html2canvas fallback
  if (!dataUrl || dataUrl.length < 100 || dataUrl === 'data:,') {
    try {
      const canvas = await html2canvas(element, {
        scale: Math.min(pixelRatio, 2),
        backgroundColor: '#ffffff',
        useCORS: true,
        allowTaint: true,
        logging: false,
        scrollX: 0,
        scrollY: 0,
        windowWidth: element.scrollWidth || document.documentElement.scrollWidth,
        windowHeight: element.scrollHeight || document.documentElement.scrollHeight,
      });

      dataUrl = canvas.toDataURL('image/png', 0.98);
    } catch (h2cErr) {
      console.error('html2canvas falhou:', h2cErr);
      throw lastError || h2cErr;
    }
  }

  if (!dataUrl || dataUrl.length < 100 || dataUrl === 'data:,') {
    throw new Error('Não foi possível gerar a imagem da folha.');
  }

  return dataUrl;
}

/**
 * Downloads a single DOM element as PNG.
 */
export async function downloadElementAsImage(
  element: HTMLElement,
  filename: string,
  pixelRatio = 2
): Promise<void> {
  const dataUrl = await captureElementToDataUrl(element, pixelRatio);

  const link = document.createElement('a');
  link.download = filename;
  link.href = dataUrl;
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  setTimeout(() => {
    if (document.body.contains(link)) {
      document.body.removeChild(link);
    }
  }, 250);
}

/**
 * Captures multiple DOM elements and combines them into a single multi-page A4 PDF file.
 */
export async function downloadPagesAsPdf(
  elements: HTMLElement[],
  filename: string,
  onProgress?: (current: number, total: number, statusText: string) => void
): Promise<void> {
  if (!elements || elements.length === 0) {
    throw new Error('Nenhuma página fornecida para exportação em PDF.');
  }

  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
    compress: true,
  });

  const total = elements.length;

  for (let i = 0; i < total; i++) {
    onProgress?.(i + 1, total, `Renderizando folha ${i + 1} de ${total}...`);
    
    // Add page if beyond first page
    if (i > 0) {
      pdf.addPage('a4', 'portrait');
    }

    const el = elements[i];
    // Use scale 1.8 for balanced resolution and fast export
    const dataUrl = await captureElementToDataUrl(el, 1.8);

    // Standard A4 dimensions: 210mm x 297mm
    pdf.addImage(dataUrl, 'PNG', 0, 0, 210, 297, undefined, 'FAST');
  }

  onProgress?.(total, total, 'Salvando arquivo PDF...');
  pdf.save(filename);
}

/**
 * Captures multiple DOM elements and compresses them into a single ZIP file containing PNG images.
 */
export async function downloadPagesAsZip(
  elements: HTMLElement[],
  zipFilename: string,
  filePrefix: string,
  onProgress?: (current: number, total: number, statusText: string) => void
): Promise<void> {
  if (!elements || elements.length === 0) {
    throw new Error('Nenhuma folha fornecida para exportação em ZIP.');
  }

  const zip = new JSZip();
  const total = elements.length;

  for (let i = 0; i < total; i++) {
    onProgress?.(i + 1, total, `Exportando imagem da folha ${i + 1} de ${total}...`);
    const el = elements[i];
    const dataUrl = await captureElementToDataUrl(el, 2);
    // Remove base64 header
    const base64Data = dataUrl.replace(/^data:image\/png;base64,/, '');
    const pageNumStr = String(i + 1).padStart(2, '0');
    zip.file(`${filePrefix}-folha-${pageNumStr}.png`, base64Data, { base64: true });
  }

  onProgress?.(total, total, 'Compactando arquivo ZIP...');
  const content = await zip.generateAsync({ type: 'blob' });

  // Trigger download of zip blob
  const url = URL.createObjectURL(content);
  const link = document.createElement('a');
  link.download = zipFilename;
  link.href = url;
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  setTimeout(() => {
    URL.revokeObjectURL(url);
    if (document.body.contains(link)) {
      document.body.removeChild(link);
    }
  }, 500);
}
